# BookMyGlobal

One-stop travel platform: International Driving Permits, flights, hotels, tours, cruises, bus tickets, MEA/embassy attestation, visa assistance, yoga retreats and a traveller community. Built on the same stack and admin panel as the IDP platform.

See **SETUP.md** to get running.

```bash
pnpm install && pnpm prisma generate && pnpm dev
```
