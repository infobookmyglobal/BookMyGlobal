import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ProductType = 'DIGITAL' | 'NFC_KIT';
export type ValidityYears = 1 | 2 | 3;

interface CartState {
  productType: ProductType | null;
  validity: ValidityYears | null;
  couponCode: string | null;
  discount: number;
  baseAmount: number;
  finalAmount: number;
  currency: string;
  // Actions
  setProduct: (type: ProductType) => void;
  setValidity: (v: ValidityYears) => void;
  setCoupon: (code: string | null, discount: number) => void;
  setAmounts: (base: number, final: number, currency: string) => void;
  reset: () => void;
}

const initialState = {
  productType: null,
  validity: null,
  couponCode: null,
  discount: 0,
  baseAmount: 0,
  finalAmount: 0,
  currency: 'USD',
};

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      ...initialState,
      setProduct: (type) => set({ productType: type }),
      setValidity: (v) => set({ validity: v }),
      setCoupon: (code, discount) => set({ couponCode: code, discount }),
      setAmounts: (base, final, currency) => set({ baseAmount: base, finalAmount: final, currency }),
      reset: () => set(initialState),
    }),
    { name: 'idp-cart' }
  )
);
