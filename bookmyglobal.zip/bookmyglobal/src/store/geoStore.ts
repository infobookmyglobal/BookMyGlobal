'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ExchangeRates } from '@/lib/currency';

interface GeoState {
  country: string;
  countryName: string;
  currency: string;
  symbol: string;
  language: string;
  nativeCurrency: string | null;
  nativeSymbol: string | null;
  exchangeRates: ExchangeRates | null;
  fetchedAt: number | null;
  setGeo: (geo: {
    country?: string;
    countryName?: string;
    currency?: string;
    symbol?: string;
    language?: string;
    nativeCurrency?: string | null;
    nativeSymbol?: string | null;
    fetchedAt?: number | null;
  }) => void;
  setRates: (rates: ExchangeRates) => void;
}

export const useGeoStore = create<GeoState>()(
  persist(
    (set) => ({
      country: 'US',
      countryName: 'United States',
      currency: 'USD',
      symbol: '$',
      language: 'en',
      nativeCurrency: null,
      nativeSymbol: null,
      exchangeRates: null,
      fetchedAt: null,
      setGeo: (geo) => set((state) => ({ ...state, ...geo })),
      setRates: (rates) => set({ exchangeRates: rates }),
    }),
    { name: 'idp-geo' }
  )
);
