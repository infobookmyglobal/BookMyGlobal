export const BASE_PRICES = {
  DIGITAL: { 1: 21, 2: 26, 3: 32 },
  NFC_KIT: { 1: 32, 2: 37, 3: 42 },
} as const;

export const INR_PRICES = {
  DIGITAL: { 1: 1999, 2: 2499, 3: 2999 },
  NFC_KIT: { 1: 2999, 2: 3499, 3: 3999 },
} as const;

export type ProductType = 'DIGITAL' | 'NFC_KIT';
export type ValidityYears = 1 | 2 | 3;

export function getPrice(product: ProductType, validity: ValidityYears): number {
  return BASE_PRICES[product][validity];
}

export const PRODUCT_LABELS = {
  DIGITAL: 'Digital IDP',
  NFC_KIT: 'NFC Smart Kit',
};

export const PRODUCT_DESCRIPTIONS = {
  DIGITAL: 'PDF sent to your email within 2–4 hours. Accepted in most countries.',
  NFC_KIT: 'Physical booklet + NFC card shipped to your door. Accepted everywhere.',
};
