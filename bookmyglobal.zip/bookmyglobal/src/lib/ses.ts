import { WHATSAPP_URL } from "@/lib/contact";
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY || "re_dummyKeyForBuildTime");

const FROM_EMAIL = process.env.EMAIL_FROM || process.env.SES_FROM_EMAIL || 'info@bookmyglobal.com';
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
const BRAND_NAVY = '#001A66';
const BRAND_BLUE = '#0033CC';
const BRAND_GOLD = '#FFD700';
const BRAND_GREEN = '#22c55e';

function stripHtmlToText(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function sendEmail(
  to: string,
  subject: string,
  html: string
): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.warn("RESEND_API_KEY is not defined. Simulating email sending.");
    console.log(`[SIMULATION] Email to: ${to}`);
    console.log(`[SIMULATION] Subject: ${subject}`);
    return;
  }

  const recipients = to.split(',').map((email) => email.trim()).filter(Boolean);
  const plainText = stripHtmlToText(html);

  const { error } = await resend.emails.send({
    from: `BookMyGlobal <${FROM_EMAIL}>`,
    to: recipients,
    replyTo: FROM_EMAIL,
    subject: subject,
    html: html,
    text: plainText,
  });

  if (error) {
    console.error("Resend email sending failed:", error);
    throw new Error(`Email sending failed: ${error.message}`);
  }
}

function baseTemplate(content: string, title: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>${title}</title>
</head>
<body style="margin:0;padding:0;background:#f2f4f8;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f2f4f8;padding:32px 16px;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
      <!-- Header -->
      <tr><td style="background:${BRAND_NAVY};border-radius:16px 16px 0 0;padding:28px 32px;text-align:center;">
        <div style="color:${BRAND_GOLD};font-size:11px;font-weight:900;letter-spacing:3px;text-transform:uppercase;margin-bottom:6px;">BookMyGlobal</div>
        <div style="color:#fff;font-size:20px;font-weight:900;">Your journey, sorted.</div>
      </td></tr>
      <!-- Body -->
      <tr><td style="background:#fff;padding:32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0;">
        ${content}
      </td></tr>
      <!-- Footer -->
      <tr><td style="background:${BRAND_NAVY};border-radius:0 0 16px 16px;padding:20px 32px;text-align:center;">
        <p style="color:rgba(255,255,255,.45);font-size:11px;margin:0;">
          © ${new Date().getFullYear()} BookMyGlobal. All rights reserved.<br/>
          <a href="${APP_URL}" style="color:rgba(255,255,255,.45);">${APP_URL}</a>
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>`;
}

function ctaButton(href: string, text: string, color = BRAND_BLUE): string {
  return `<a href="${href}" style="display:inline-block;background:${color};color:#fff;font-weight:900;font-size:15px;padding:14px 32px;border-radius:10px;text-decoration:none;margin:16px 0;">${text}</a>`;
}

// ── 1. Application Confirmation ──────────────────────────────────────────────
type ApplicationData = {
  id: string;
  productType: string;
  validity: number;
  finalAmount: number;
  currency: string;
  fullName: string;
  email: string;
  idpNumber?: string | null;
  pdfBookletUrl?: string | null;
  pdfIdCardUrl?: string | null;
  rejectionReason?: string | null;
  phone?: string | null;
  password?: string | null;
  country?: string | null;
  couponCode?: string | null;
};

export function applicationConfirmationEmail(app: ApplicationData): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Payment Confirmed! ✅</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, your IDP application has been received and your payment is confirmed.</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:#64748b;font-size:13px;">Application ID</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">#${app.id.slice(-8).toUpperCase()}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Product</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.productType === 'NFC_KIT' ? 'NFC Smart Kit' : 'Digital IDP'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Validity</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.validity} Year${app.validity > 1 ? 's' : ''}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Amount Paid</td><td style="font-weight:900;color:${BRAND_BLUE};text-align:right;font-size:16px;">${app.currency} ${app.finalAmount}</td></tr>
        </table>
      </td></tr>
    </table>

    ${app.password ? `
    <h3 style="color:${BRAND_NAVY};font-size:16px;font-weight:900;margin:24px 0 8px;">Your Account Credentials 🔑</h3>
    <p style="color:#64748b;font-size:13px;margin:0 0 12px;">We've automatically created an account for you. Use these credentials to sign in, track your status, and download your permit once ready.</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:#64748b;font-size:13px;">Login Email</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.email}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Temporary Password</td><td style="font-weight:900;color:${BRAND_BLUE};text-align:right;font-size:14px;letter-spacing:1px;"><code>${app.password}</code></td></tr>
        </table>
      </td></tr>
    </table>
    ` : ''}

    <p style="color:#374151;font-size:14px;">Your next step is to upload your documents so we can process your IDP.</p>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/dashboard/upload`, 'Upload Your Documents Now →', BRAND_GREEN)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">If you have questions, <a href="${WHATSAPP_URL}" style="color:${BRAND_BLUE};">chat with us on WhatsApp</a>.</p>
  `;
  return baseTemplate(content, 'IDP Application Confirmed');
}

// ── 2. Documents Received ────────────────────────────────────────────────────
export function documentReceivedEmail(app: ApplicationData): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Documents Received 📋</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, we've received your documents for Application #${app.id.slice(-8).toUpperCase()}.</p>
    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:20px 24px;margin-bottom:24px;">
      <p style="color:#15803d;font-weight:700;font-size:14px;margin:0 0 8px;">✅ What happens next?</p>
      <p style="color:#166534;font-size:13px;margin:0;">Our team will review and process your application within <strong>24 hours</strong>. You'll receive an email with your IDP download links once approved.</p>
    </div>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/dashboard/applications`, 'Track Your Application →')}</div>
  `;
  return baseTemplate(content, 'IDP Documents Received');
}

// ── 3. Application Approved ──────────────────────────────────────────────────
export function applicationApprovedEmail(
  app: ApplicationData & { idpNumber: string },
  bookletUrl: string,
  idCardUrl: string
): string {
  const expiryYear = new Date().getFullYear() + app.validity;
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Your IDP is Ready! 🎉</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, your International Driving Permit has been approved and is ready for download.</p>
    <div style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;padding:20px 24px;margin-bottom:24px;">
      <p style="color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:1px;font-weight:700;margin:0 0 4px;">IDP Number</p>
      <p style="color:${BRAND_NAVY};font-size:24px;font-weight:900;margin:0 0 12px;letter-spacing:2px;">${app.idpNumber}</p>
      <p style="color:#64748b;font-size:13px;margin:0;">Valid until <strong>${expiryYear}</strong> · ${app.validity} year${app.validity > 1 ? 's' : ''}</p>
    </div>
    <div style="text-align:center;margin-bottom:12px;">${ctaButton(bookletUrl, '📄 Download IDP Booklet', BRAND_NAVY)}</div>
    <div style="text-align:center;margin-bottom:24px;">${ctaButton(idCardUrl, '🪪 Download ID Card', BRAND_BLUE)}</div>
    <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:16px;font-size:12px;color:#78350f;">
      🔒 Verify this IDP online: <a href="${APP_URL}/verify/${app.id}" style="color:${BRAND_BLUE};font-weight:700;">${APP_URL}/verify/${app.id}</a>
    </div>
    ${app.productType === 'NFC_KIT' ? `<p style="color:#64748b;font-size:13px;margin-top:16px;">📦 Your physical NFC Smart Kit will be dispatched within 7–15 working days.</p>` : ''}
  `;
  return baseTemplate(content, 'Your IDP is Ready');
}

export async function sendApplicationApprovedEmail(
  app: any,
  cardUrl: string,
  bookletUrl: string
): Promise<void> {
  const html = applicationApprovedEmail(
    {
      id: app.id,
      fullName: app.fullName,
      email: app.email,
      phone: app.phone,
      productType: app.productType,
      validity: app.validity,
      finalAmount: app.finalAmount,
      currency: app.currency,
      idpNumber: app.idpNumber || '',
    },
    bookletUrl,
    cardUrl
  );
  await sendEmail(app.email, 'Your IDP is Ready — Download Now 🎉', html);
}


// ── 4. Application Rejected ──────────────────────────────────────────────────
export function applicationRejectedEmail(app: ApplicationData): string {
  const content = `
    <h2 style="color:#dc2626;font-size:22px;font-weight:900;margin:0 0 8px;">Application Update</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, we're sorry to inform you that your IDP application #${app.id.slice(-8).toUpperCase()} could not be processed at this time.</p>
    <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:20px 24px;margin-bottom:24px;">
      <p style="color:#dc2626;font-weight:700;font-size:14px;margin:0 0 8px;">Reason for Rejection:</p>
      <p style="color:#7f1d1d;font-size:13px;margin:0;">${app.rejectionReason || 'Please contact support for more information.'}</p>
    </div>
    <p style="color:#374151;font-size:14px;">Please contact our support team on WhatsApp for assistance. We're happy to help resolve any issues.</p>
    <div style="text-align:center;">${ctaButton(WHATSAPP_URL, '💬 Contact Support on WhatsApp', BRAND_GREEN)}</div>
  `;
  return baseTemplate(content, 'IDP Application Update');
}

// ── 5. Shipping Dispatched ───────────────────────────────────────────────────
type ShipmentData = {
  awbNumber?: string | null;
  trackingUrl?: string | null;
  recipientName: string;
};

export function shippingDispatchedEmail(
  app: ApplicationData,
  shipment: ShipmentData
): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Your IDP Kit is on the Way! 📦</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, your NFC Smart Kit has been dispatched and is on its way to you.</p>
    <div style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;padding:20px 24px;margin-bottom:24px;">
      <table width="100%" cellpadding="6" cellspacing="0">
        <tr><td style="color:#64748b;font-size:13px;">AWB / Tracking No</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${shipment.awbNumber || 'Pending'}</td></tr>
        <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Estimated Delivery</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">7–15 Working Days</td></tr>
        <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Ship To</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${shipment.recipientName}</td></tr>
      </table>
    </div>
    ${shipment.trackingUrl ? `<div style="text-align:center;">${ctaButton(shipment.trackingUrl, '📍 Track Your Shipment')}</div>` : ''}
  `;
  return baseTemplate(content, 'IDP Kit Dispatched');
}

// ── 6. Partner Welcome ───────────────────────────────────────────────────────
type PartnerData = {
  referralCode: string;
  commissionRate: number;
};
type UserData = {
  name?: string | null;
  email: string;
};

export function partnerWelcomeEmail(
  partner: PartnerData,
  user: UserData & { password?: string }
): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Welcome to the Partner Program! 🤝</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${user.name || 'Partner'}, congratulations! You've been approved as an official BookMyGlobal partner.</p>
    
    <div style="background:${BRAND_NAVY};border-radius:16px;padding:32px;text-align:center;margin-bottom:24px;">
      <p style="color:rgba(255,255,255,.6);font-size:11px;font-weight:900;letter-spacing:3px;text-transform:uppercase;margin:0 0 8px;">Your Referral Code</p>
      <p style="color:${BRAND_GOLD};font-size:40px;font-weight:900;letter-spacing:8px;margin:0 0 12px;">${partner.referralCode}</p>
      <p style="color:rgba(255,255,255,.7);font-size:13px;margin:0;">Commission Rate: <strong style="color:#fff;">${partner.commissionRate}%</strong> per successful referral</p>
    </div>

    ${user.password ? `
    <h3 style="color:${BRAND_NAVY};font-size:16px;font-weight:900;margin:24px 0 8px;">Your Partner Account Credentials 🔑</h3>
    <p style="color:#64748b;font-size:13px;margin:0 0 12px;">We've created an account for you. Use these credentials to sign in to your Partner Dashboard.</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:#64748b;font-size:13px;">Login Email</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.email}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Temporary Password</td><td style="font-weight:900;color:${BRAND_BLUE};text-align:right;font-size:14px;letter-spacing:1px;"><code>${user.password}</code></td></tr>
        </table>
      </td></tr>
    </table>
    ` : ''}

    <div style="text-align:center;">${ctaButton(`${APP_URL}/partner`, 'Visit Partner Dashboard →', BRAND_BLUE)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">Share your referral code with customers. You'll earn commissions automatically on every approved IDP application.</p>
  `;
  return baseTemplate(content, 'Welcome to the Partner Program');
}

export async function sendPartnerWelcomeEmail(
  partner: any,
  user: any,
  password?: string
): Promise<void> {
  const html = partnerWelcomeEmail(
    {
      referralCode: partner.referralCode,
      commissionRate: partner.commissionRate,
    },
    {
      name: user.name,
      email: user.email,
      password: password,
    }
  );
  await sendEmail(user.email, 'Welcome to the Partner Program — Account Approved! 🤝', html);
}


// ── 7. User Credentials Email ───────────────────────────────────────────────
export function userCredentialsEmail(email: string, password: string): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Your Account Credentials 🔑</h2>
    <p style="color:#64748b;margin:0 0 24px;">Thank you for applying for an International Driving Permit. We have automatically created an account for you. You can use these credentials to log in, track your application, and download your permit once it's ready.</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:#64748b;font-size:13px;">Login Email</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${email}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Temporary Password</td><td style="font-weight:900;color:${BRAND_BLUE};text-align:right;font-size:14px;letter-spacing:1px;"><code>${password}</code></td></tr>
        </table>
      </td></tr>
    </table>
    <p style="color:#374151;font-size:14px;">Please sign in and change your password from your account settings.</p>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/sign-in`, 'Sign In to Your Dashboard →', BRAND_BLUE)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">If you have any questions, feel free to reply to this email or chat with us on WhatsApp.</p>
  `;
  return baseTemplate(content, 'Your Account Credentials');
}

// ── 8. Documents Re-upload Request Email ─────────────────────────────────────
export function reuploadRequestEmail(app: ApplicationData, docs: string[], notes?: string): string {
  const docListHtml = docs.map(doc => `<li><strong>${doc}</strong></li>`).join('');
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Documents Re-upload Required 📸</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, we reviewed your application #${app.id.slice(-8).toUpperCase()} but need you to re-upload the following document(s) before we can complete verification:</p>
    <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:20px 24px;margin-bottom:24px;">
      <p style="color:#b45309;font-weight:700;font-size:14px;margin:0 0 8px;">Required Document(s):</p>
      <ul style="color:#78350f;font-size:13px;margin:0 0 16px;padding-left:20px;">
        ${docListHtml}
      </ul>
      ${notes ? `
        <p style="color:#b45309;font-weight:700;font-size:13px;margin:12px 0 4px;">Notes from Verification Team:</p>
        <p style="color:#78350f;font-size:13px;margin:0;font-style:italic;">"${notes}"</p>
      ` : ''}
    </div>
    <p style="color:#374151;font-size:14px;">Please click the link below to access your secure upload portal and submit the correct document(s):</p>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/dashboard/upload`, 'Re-upload Documents Now →', BRAND_BLUE)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">If you have questions, reply to this email or contact support on WhatsApp.</p>
  `;
  return baseTemplate(content, 'Action Required: Re-upload documents');
}

export async function sendReuploadRequestEmail(
  app: any,
  docs: string[],
  notes?: string
): Promise<void> {
  const html = reuploadRequestEmail(
    {
      id: app.id,
      fullName: app.fullName,
      email: app.email,
      phone: app.phone,
      productType: app.productType,
      validity: app.validity,
      finalAmount: app.finalAmount,
      currency: app.currency,
    },
    docs,
    notes
  );
  await sendEmail(app.email, 'Action Required: Re-upload documents for your IDP application 📸', html);
}

// ── 9. Form Edit Request Email ─────────────────────────────────────
export function formEditRequestEmail(app: ApplicationData, notes: string): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Application Edit Required ✏️</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${app.fullName}, we reviewed your application #${app.id.slice(-8).toUpperCase()} but need you to correct some of the details you submitted before we can complete verification:</p>
    <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:20px 24px;margin-bottom:24px;">
      <p style="color:#b45309;font-weight:700;font-size:14px;margin:0 0 8px;">Notes from Verification Team:</p>
      <p style="color:#78350f;font-size:13px;margin:0;font-style:italic;">"${notes}"</p>
    </div>
    <p style="color:#374151;font-size:14px;">Please click the link below to access your application and update the incorrect details:</p>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/dashboard/applications/${app.id}/edit`, 'Edit Application Now →', BRAND_BLUE)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">If you have questions, reply to this email or contact support on WhatsApp.</p>
  `;
  return baseTemplate(content, 'Action Required: Edit Application Details');
}

export async function sendFormEditRequestEmail(
  app: any,
  notes: string
): Promise<void> {
  const html = formEditRequestEmail(
    {
      id: app.id,
      fullName: app.fullName,
      email: app.email,
      phone: app.phone,
      productType: app.productType,
      validity: app.validity,
      finalAmount: app.finalAmount,
      currency: app.currency,
    },
    notes
  );
  await sendEmail(app.email, 'Action Required: Update your IDP application details ✏️', html);
}

// ── 10. Admin Notification: New Application Submitted ───────────────────────
export function adminNewApplicationNotificationEmail(app: ApplicationData & { paymentProvider: string }): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">New IDP Application Received 📦</h2>
    <p style="color:#64748b;margin:0 0 24px;">A new International Driving Permit application has been submitted and payment is confirmed.</p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:${BRAND_NAVY};font-size:13px;font-weight:700;">Customer Details</td><td></td></tr>
          <tr><td style="color:#64748b;font-size:13px;">Full Name</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.fullName}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Email Address</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;"><a href="mailto:${app.email}" style="color:${BRAND_BLUE};">${app.email}</a></td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Phone</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.phone || 'N/A'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Country of License</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.country || 'N/A'}</td></tr>
          
          <tr><td style="padding-top:15px;color:${BRAND_NAVY};font-size:13px;font-weight:700;">Application Details</td><td></td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Application ID</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">#${app.id.slice(-8).toUpperCase()}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Product Type</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.productType === 'NFC_KIT' ? 'NFC Smart Kit' : 'Digital IDP'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Validity</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.validity} Year${app.validity > 1 ? 's' : ''}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Coupon / Partner Code</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.couponCode || 'None'}</td></tr>
          
          <tr><td style="padding-top:15px;color:${BRAND_NAVY};font-size:13px;font-weight:700;">Payment Details</td><td></td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Provider</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${app.paymentProvider}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Amount Paid</td><td style="font-weight:900;color:${BRAND_BLUE};text-align:right;font-size:16px;">${app.currency} ${app.finalAmount}</td></tr>
        </table>
      </td></tr>
    </table>
    
    <div style="text-align:center;">${ctaButton(`${APP_URL}/admin/applications/${app.id}`, 'View in Admin Panel →', BRAND_NAVY)}</div>
  `;
  return baseTemplate(content, 'New IDP Application Received');
}

export async function sendAdminNewApplicationNotificationEmail(
  app: any,
  paymentProvider: string
): Promise<void> {
  // Supports comma-separated emails e.g. "admin@example.com,manager@example.com"
  const adminEmailEnv = process.env.ADMIN_EMAIL || 'info@bookmyglobal.com';
  const adminEmails = adminEmailEnv.split(',').map((e) => e.trim()).filter(Boolean);

  console.log(`[Admin Notification] Sending new application alert to: ${adminEmails.join(', ')}`);

  const html = adminNewApplicationNotificationEmail({
    id: app.id,
    fullName: app.fullName,
    email: app.email,
    phone: app.phone,
    country: app.country,
    productType: app.productType,
    validity: app.validity,
    finalAmount: app.finalAmount,
    currency: app.currency,
    couponCode: app.couponCode,
    paymentProvider,
  });

  const subject = `[ADMIN Alert] New IDP Application #${app.id.slice(-8).toUpperCase()} - ${app.fullName} ✅`;

  // Send to all admin emails
  const results = await Promise.allSettled(
    adminEmails.map((email) => sendEmail(email, subject, html))
  );

  results.forEach((result, i) => {
    if (result.status === 'fulfilled') {
      console.log(`[Admin Notification] ✅ Email sent successfully to ${adminEmails[i]}`);
    } else {
      console.error(`[Admin Notification] ❌ Failed to send to ${adminEmails[i]}:`, result.reason);
    }
  });
}

// ── 11. Admin Notification: Permission Requested for Multiple IDP ───────────────────
export function adminPermissionRequestNotificationEmail(user: { name?: string | null; email: string; id: string }): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Multiple IDP Permission Requested 🔒</h2>
    <p style="color:#64748b;margin:0 0 24px;">A user has requested permission to create multiple International Driving Permits (IDPs).</p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:${BRAND_NAVY};font-size:13px;font-weight:700;">User Details</td><td></td></tr>
          <tr><td style="color:#64748b;font-size:13px;">Full Name</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.name || 'N/A'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Email Address</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;"><a href="mailto:${user.email}" style="color:${BRAND_BLUE};">${user.email}</a></td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">User ID</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.id}</td></tr>
        </table>
      </td></tr>
    </table>
    
    <div style="text-align:center;">${ctaButton(`${APP_URL}/admin`, 'Review Request in Admin Panel →', BRAND_NAVY)}</div>
  `;
  return baseTemplate(content, 'Multiple IDP Permission Requested');
}

export async function sendAdminPermissionRequestNotificationEmail(
  user: { name?: string | null; email: string; id: string }
): Promise<void> {
  const adminEmail = process.env.ADMIN_EMAIL || 'info@bookmyglobal.com';
  const html = adminPermissionRequestNotificationEmail(user);
  
  await sendEmail(
    adminEmail,
    `[ADMIN Alert] Multiple IDP Permission Requested - ${user.name || user.email} ⏳`,
    html
  );
}

// ── 12. User Notification: Permission Request Submitted ───────────────────────
export function userPermissionRequestedEmail(user: { name?: string | null }): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">Permission Request Received ⏳</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${user.name || 'User'},</p>
    <p style="color:#374151;font-size:14px;line-height:1.6;">We have received your request to apply for an additional International Driving Permit (IDP).</p>
    <p style="color:#374151;font-size:14px;line-height:1.6;">Our verification team is reviewing your request. You will receive an email update as soon as a decision is made.</p>
    <div style="text-align:center;">${ctaButton(`${APP_URL}/dashboard`, 'Go to Dashboard', BRAND_BLUE)}</div>
    <p style="color:#94a3b8;font-size:12px;margin-top:24px;">If you have any questions in the meantime, feel free to contact us on WhatsApp.</p>
  `;
  return baseTemplate(content, 'Multiple IDP Permission Request Submitted');
}

export async function sendUserPermissionRequestedEmail(
  user: { name?: string | null; email: string }
): Promise<void> {
  const html = userPermissionRequestedEmail(user);
  await sendEmail(
    user.email,
    'We received your request to apply for an additional IDP ⏳',
    html
  );
}

// ── 13. User Notification: Permission Decision ──────────────────────────────
export function userPermissionDecisionEmail(
  user: { name?: string | null },
  approved: boolean
): string {
  const heading = approved ? 'Permission Granted! ✅' : 'Permission Request Update';
  const color = approved ? BRAND_NAVY : '#dc2626';
  const message = approved
    ? 'Congratulations! Your request to create an additional International Driving Permit has been approved.'
    : 'Thank you for your interest. Unfortunately, your request to create an additional International Driving Permit could not be approved at this time.';
  
  const content = `
    <h2 style="color:${color};font-size:22px;font-weight:900;margin:0 0 8px;">${heading}</h2>
    <p style="color:#64748b;margin:0 0 24px;">Hi ${user.name || 'User'},</p>
    <p style="color:#374151;font-size:14px;line-height:1.6;">${message}</p>
    ${approved ? `
      <p style="color:#374151;font-size:14px;line-height:1.6;">You can now proceed to create your new IDP application immediately.</p>
      <div style="text-align:center;">${ctaButton(`${APP_URL}/apply`, 'Apply for New IDP Now →', BRAND_GREEN)}</div>
    ` : `
      <p style="color:#374151;font-size:14px;line-height:1.6;">Please contact our support team on WhatsApp for further assistance or if you believe this was an error.</p>
      <div style="text-align:center;">${ctaButton(WHATSAPP_URL, '💬 Contact Support on WhatsApp', BRAND_GREEN)}</div>
    `}
  `;
  return baseTemplate(content, approved ? 'Multiple IDP Permission Granted' : 'Multiple IDP Permission Denied');
}

export async function sendUserPermissionDecisionEmail(
  user: { name?: string | null; email: string },
  approved: boolean
): Promise<void> {
  const subject = approved
    ? 'Approved: You can now apply for another IDP! 🎉'
    : 'Update on your IDP permission request';
  const html = userPermissionDecisionEmail(user, approved);
  await sendEmail(user.email, subject, html);
}

// ── 14. Admin Notification: New User Registered ───────────────────────
export function adminNewUserRegistrationNotificationEmail(user: { name?: string | null; email: string; phone?: string | null; country?: string | null }): string {
  const content = `
    <h2 style="color:${BRAND_NAVY};font-size:22px;font-weight:900;margin:0 0 8px;">New User Registered 👥</h2>
    <p style="color:#64748b;margin:0 0 24px;">A new user account has been registered on the platform.</p>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;margin-bottom:24px;">
      <tr><td style="padding:20px 24px;">
        <table width="100%" cellpadding="6" cellspacing="0">
          <tr><td style="color:${BRAND_NAVY};font-size:13px;font-weight:700;">User Details</td><td></td></tr>
          <tr><td style="color:#64748b;font-size:13px;">Full Name</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.name || 'N/A'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Email Address</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;"><a href="mailto:${user.email}" style="color:${BRAND_BLUE};">${user.email}</a></td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Phone</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.phone || 'N/A'}</td></tr>
          <tr style="border-top:1px solid #e2e8f0;"><td style="color:#64748b;font-size:13px;">Country</td><td style="font-weight:700;color:#0a1628;text-align:right;font-size:13px;">${user.country || 'N/A'}</td></tr>
        </table>
      </td></tr>
    </table>
    
    <div style="text-align:center;">${ctaButton(`${APP_URL}/admin`, 'View Users in Admin Panel →', BRAND_NAVY)}</div>
  `;
  return baseTemplate(content, 'New User Registered');
}

export async function sendAdminNewUserRegistrationNotificationEmail(
  user: { name?: string | null; email: string; phone?: string | null; country?: string | null }
): Promise<void> {
  const adminEmail = process.env.ADMIN_EMAIL || 'info@bookmyglobal.com';
  const html = adminNewUserRegistrationNotificationEmail(user);
  
  await sendEmail(
    adminEmail,
    `[ADMIN Alert] New User Registered - ${user.name || user.email} 👤`,
    html
  );
}
