import { randomBytes } from "crypto";
import { clerkClient } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { sendEmail, userCredentialsEmail, sendAdminNewUserRegistrationNotificationEmail } from "@/lib/ses";

// Generate a random 12-character password (crypto-secure) (excluding ambiguous characters)
export function generateRandomPassword(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const bytes = randomBytes(12);
  let pwd = "";
  for (let i = 0; i < 12; i++) {
    pwd += chars.charAt(bytes[i] % chars.length);
  }
  return pwd;
}

interface CreateGuestUserResult {
  userId: string;
  clerkId: string;
  generatedPassword?: string | null;
}

export async function getOrCreateGuestUser(applicationData: {
  email: string;
  fullName: string;
  phone: string;
  country: string;
}): Promise<CreateGuestUserResult> {
  const { email, fullName, phone, country } = applicationData;

  console.log(`[userCreation] Processing guest user for: ${email}`);

  // 1. Existing local user: nothing to create. (Credentials are only ever emailed once,
  //    at creation time; we never store passwords.)
  let dbUser = await prisma.user.findUnique({ where: { email } });
  if (dbUser) {
    console.log(`[userCreation] Existing user found in DB: ${dbUser.id}`);
    return { userId: dbUser.id, clerkId: dbUser.clerkId, generatedPassword: null };
  }

  let clerkId = "";
  let generatedPassword = "";

  if (!process.env.CLERK_SECRET_KEY) {
    throw new Error("CLERK_SECRET_KEY is not configured");
  }

  // 2. Check if user already exists in Clerk
  const client = await clerkClient();
  const list = await client.users.getUserList({ emailAddress: [email] });

  if (list.data && list.data.length > 0) {
    clerkId = list.data[0].id;
    console.log(`[userCreation] Found existing Clerk user: ${clerkId}`);
  } else {
    // 3. Create user programmatically in Clerk
    generatedPassword = generateRandomPassword();
    const nameParts = fullName.trim().split(/\s+/);
    const firstName = nameParts[0] || "User";
    const lastName = nameParts.slice(1).join(" ") || undefined;

    const newClerkUser = await client.users.createUser({
      emailAddress: [email],
      password: generatedPassword,
      firstName,
      lastName,
      publicMetadata: { role: "user" },
    });
    clerkId = newClerkUser.id;
    console.log(`[userCreation] Created Clerk user: ${clerkId}`);
  }

  // 4. Create User record in Prisma
  dbUser = await prisma.user.create({
    data: {
      clerkId,
      email,
      name: fullName,
      phone,
      country,
    },
  });
  console.log(`[userCreation] Created DB user: ${dbUser.id}`);

  // 5. Send credentials email if we generated a password
  if (generatedPassword) {
    try {
      await sendEmail(
        email,
        "Your Account Credentials 🔑 | BookMyGlobal",
        userCredentialsEmail(email, generatedPassword)
      );
      console.log(`[userCreation] Credentials email sent to ${email}`);
    } catch (emailErr) {
      console.error("[userCreation] Failed to send credentials email:", emailErr);
    }
  } else {
    console.warn(`[userCreation] No password generated — credentials email skipped for ${email}`);
  }

  // 6. Notify admin about the new user registration
  try {
    await sendAdminNewUserRegistrationNotificationEmail({
      name: fullName,
      email,
      phone,
      country,
    });
    console.log(`[userCreation] Admin notified of new user registration: ${email}`);
  } catch (adminEmailErr) {
    console.error("[userCreation] Failed to send admin registration email:", adminEmailErr);
  }

  return { userId: dbUser.id, clerkId, generatedPassword: generatedPassword || null };
}
