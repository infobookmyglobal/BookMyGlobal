import { Metadata } from "next";
import { prisma } from "@/lib/prisma";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://bookmyglobal.com";

export const DEFAULT_METADATA: Record<string, { title: string; description: string }> = {
  home: {
    title: "BookMyGlobal — Visas, Flights, Hotels, Tours & IDP in One Place",
    description: "One account for your International Driving Permit, flights, hotels, tours, cruises, bus tickets, MEA & embassy attestation, visa assistance and yoga retreats.",
  },
  about: {
    title: "About Us — BookMyGlobal",
    description: "BookMyGlobal is a private international organisation dedicated to making global driving accessibility a reality.",
  },
  pricing: {
    title: "Simple, Fair Pricing — BookMyGlobal",
    description: "No hidden fees. No renewal subscriptions. Pay once, drive internationally.",
  },
  faqs: {
    title: "FAQs — BookMyGlobal",
    description: "Complete FAQ guide for International Driving Permit (IDP). 20 expert answers covering Dubai, USA, Thailand, application process, pricing, documents, and more.",
  },
  contact: {
    title: "Contact Us — BookMyGlobal",
    description: "Questions about a service, an application or a booking? Send us a message and our team will get back to you.",
  },
  terms: {
    title: "Terms & Conditions — BookMyGlobal",
    description: "BookMyGlobal's terms of service and membership rules.",
  },
  privacy: {
    title: "Privacy Policy — BookMyGlobal",
    description: "BookMyGlobal's privacy and personal data protection policy.",
  },
  refunds: {
    title: "Refund Policy & Guarantees — BookMyGlobal",
    description: "BookMyGlobal's refund policy, support rules, and service guarantees.",
  },
};

export async function getSeoMetadata(pageKey: string): Promise<Metadata> {
  const defaults = DEFAULT_METADATA[pageKey] || DEFAULT_METADATA.home;
  
  try {
    const seo = await prisma.seoMeta.findUnique({
      where: { pageKey },
    });

    if (seo) {
      const title = seo.title || defaults.title;
      const description = seo.description || defaults.description;
      const ogTitle = seo.ogTitle || title;
      const ogDescription = seo.ogDescription || description;
      const ogImg = seo.ogImage || `${APP_URL}/og-home.jpg`;
      const canonical = seo.canonicalUrl || `${APP_URL}/${pageKey === "home" ? "" : pageKey}`;

      return {
        title: {
          absolute: title,
        },
        description,
        alternates: {
          canonical,
        },
        openGraph: {
          type: "website",
          title: ogTitle,
          description: ogDescription,
          url: canonical,
          siteName: "BookMyGlobal",
          images: [{ url: ogImg, width: 1200, height: 630 }],
        },
        twitter: {
          card: (seo.twitterCard || "summary_large_image") as any,
          title: ogTitle,
          description: ogDescription,
          images: [ogImg],
        },
      };
    }
  } catch (err) {
    console.error(`Failed to fetch SEO metadata for ${pageKey}:`, err);
  }

  // Fallback metadata
  const canonical = `${APP_URL}/${pageKey === "home" ? "" : pageKey}`;
  return {
    title: {
      absolute: defaults.title,
    },
    description: defaults.description,
    alternates: {
      canonical,
    },
    openGraph: {
      type: "website",
      title: defaults.title,
      description: defaults.description,
      url: canonical,
      siteName: "BookMyGlobal",
      images: [{ url: `${APP_URL}/og-home.jpg`, width: 1200, height: 630 }],
    },
    twitter: {
      card: "summary_large_image",
      title: defaults.title,
      description: defaults.description,
      images: [`${APP_URL}/og-home.jpg`],
    },
  };
}
