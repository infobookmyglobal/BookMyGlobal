import { prisma } from "@/lib/prisma";

export async function getDbPrices() {
  try {
    const settings = await prisma.setting.findMany();
    const digitalPriceSetting = settings.find(s => s.key === "digitalPrice")?.value;
    const physicalKitPriceSetting = settings.find(s => s.key === "physicalKitPrice")?.value;

    const digitalBase = digitalPriceSetting ? parseFloat(digitalPriceSetting) : 21;
    const physicalBase = physicalKitPriceSetting ? parseFloat(physicalKitPriceSetting) : 32;

    const usdPrices = {
      DIGITAL: {
        1: digitalBase,
        2: digitalBase + 5,
        3: digitalBase + 11
      },
      NFC_KIT: {
        1: physicalBase,
        2: physicalBase + 5,
        3: physicalBase + 10
      }
    };

    const inrPrices = {
      DIGITAL: {
        1: Math.round(usdPrices.DIGITAL[1] * 95.19),
        2: Math.round(usdPrices.DIGITAL[2] * 96.11),
        3: Math.round(usdPrices.DIGITAL[3] * 93.71),
      },
      NFC_KIT: {
        1: Math.round(usdPrices.NFC_KIT[1] * 93.71),
        2: Math.round(usdPrices.NFC_KIT[2] * 94.56),
        3: Math.round(usdPrices.NFC_KIT[3] * 95.21),
      },
    };

    return { usdPrices, inrPrices };
  } catch (error) {
    console.error("Failed to fetch DB prices, falling back:", error);
    const usdPrices = {
      DIGITAL: { 1: 21, 2: 26, 3: 32 },
      NFC_KIT: { 1: 32, 2: 37, 3: 42 }
    };
    const inrPrices = {
      DIGITAL: { 1: 1999, 2: 2499, 3: 2999 },
      NFC_KIT: { 1: 2999, 2: 3499, 3: 3999 }
    };
    return { usdPrices, inrPrices };
  }
}
