// Contact details come from env so no phone number is ever hard-coded.
export const WHATSAPP_NUMBER = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "").replace(/\D/g, "");
export const WHATSAPP_URL = WHATSAPP_NUMBER ? `https://wa.me/${WHATSAPP_NUMBER}` : `${process.env.NEXT_PUBLIC_APP_URL || ""}/contact`;
export const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || "info@bookmyglobal.com";
export const SUPPORT_PHONE = process.env.NEXT_PUBLIC_SUPPORT_PHONE || (WHATSAPP_NUMBER ? `+${WHATSAPP_NUMBER}` : "");
