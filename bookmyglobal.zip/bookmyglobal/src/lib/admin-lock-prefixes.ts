// Client-safe list (no server-only imports). Sections that stay open without the unlock password.
export const OPEN_ADMIN_PREFIXES = [
  "/admin/blogs",
  "/admin/pages",
  "/admin/faqs",
  "/admin/destinations",
  "/admin/site-edit",
  "/admin/redirects",
  "/admin/seo",
  "/admin/sitemap",
];
