import type { Application } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { generateQRCode } from "@/lib/qr";
import { generateIDPBooklet, generateIDPCard } from "@/lib/pdf";
import { uploadFile, deleteObject, getPresignedDownloadUrl } from "@/lib/s3";
import { generateIDPNumber } from "@/lib/utils";
import type { ApplicationForPDF } from "@/types";

export interface IssuedPermit {
  idpNumber: string;
  qrCodeDataUrl: string;
  bookletKey: string;
  idCardKey: string;
}

/** Generates a unique IDP number, retrying on the (unlikely) collision. */
async function uniqueIdpNumber(): Promise<string> {
  for (let i = 0; i < 10; i++) {
    const candidate = generateIDPNumber();
    const clash = await prisma.application.findUnique({ where: { idpNumber: candidate } });
    if (!clash) return candidate;
  }
  throw new Error("Could not allocate a unique IDP number");
}

/**
 * Builds the QR code, booklet and ID card PDFs for an application, uploads them to S3
 * (replacing any previous files) and returns the keys. The caller persists them.
 */
export async function issuePermitForApplication(app: Application): Promise<IssuedPermit> {
  const idpNumber = app.idpNumber || (await uniqueIdpNumber());

  const qrBytes = await generateQRCode(app.id);
  const qrCodeDataUrl = `data:image/png;base64,${qrBytes.toString("base64")}`;

  let profilePhotoBytes: Buffer | null = null;
  if (app.profilePhotoUrl) {
    try {
      const url = await getPresignedDownloadUrl(app.profilePhotoUrl, 300);
      const res = await fetch(url);
      if (res.ok) profilePhotoBytes = Buffer.from(await res.arrayBuffer());
    } catch (err) {
      console.error("[issuePermit] Could not fetch profile photo:", err);
    }
  }

  const issueDate = new Date();
  const expiryDate = new Date(issueDate);
  expiryDate.setFullYear(issueDate.getFullYear() + app.validity);

  const pdfInput: ApplicationForPDF = {
    id: app.id,
    idpNumber,
    fullName: app.fullName,
    address: app.address || "",
    country: app.country,
    countryOfBirth: app.countryOfBirth || app.country,
    countryOfResidence: app.countryOfResidence || app.country,
    dob: app.dob || new Date(),
    gender: app.gender || "MALE",
    licenseNumber: app.licenseNumber || "",
    licenseClass: app.licenseClass || "B",
    parentName: app.parentName || "",
    profilePhotoUrl: app.profilePhotoUrl || "",
    issueDate,
    expiryDate,
    validity: app.validity,
    destinationCountry: app.destinationCountry || "",
  };

  const [booklet, idCard] = await Promise.all([
    generateIDPBooklet(pdfInput, qrBytes, profilePhotoBytes),
    generateIDPCard(pdfInput, qrBytes, profilePhotoBytes),
  ]);

  // Remove superseded files
  for (const old of [app.pdfBookletUrl, app.pdfIdCardUrl]) {
    if (old) await deleteObject(old).catch((e) => console.error("[issuePermit] delete old failed:", e));
  }

  const ts = Date.now();
  const bookletKey = `idps/${app.id}/booklet_${ts}.pdf`;
  const idCardKey = `idps/${app.id}/idcard_${ts}.pdf`;
  await uploadFile(bookletKey, Buffer.from(booklet), "application/pdf");
  await uploadFile(idCardKey, Buffer.from(idCard), "application/pdf");

  return { idpNumber, qrCodeDataUrl, bookletKey, idCardKey };
}
