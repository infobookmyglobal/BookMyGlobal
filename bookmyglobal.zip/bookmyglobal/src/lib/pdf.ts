import { PDFDocument, rgb, StandardFonts, PDFPage, PDFFont } from 'pdf-lib';
import { format } from 'date-fns';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { ApplicationForPDF } from '../types';

const formatDate = (date?: Date | null) =>
  date ? format(new Date(date), 'dd-MM-yyyy') : '';

function toTitleCase(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

async function loadAsset(filename: string): Promise<Buffer> {
  return fs.readFileSync(path.join(process.cwd(), 'public', 'images', filename));
}

function wrapText(text: string, maxWidth: number, font: PDFFont, size: number): string[] {
  const lines: string[] = [];
  for (const para of text.split(/\r?\n/)) {
    const words = para.split(' ');
    let current = '';
    for (const word of words) {
      const test = current ? `${current} ${word}` : word;
      if (font.widthOfTextAtSize(test, size) > maxWidth) {
        if (current) lines.push(current);
        current = word;
      } else {
        current = test;
      }
    }
    if (current) lines.push(current);
  }
  return lines;
}

function drawBottomNo(page: PDFPage, font: PDFFont, idpNumber: string) {
  // Template "No." footer: label baseline at x=311.7, y=45.06, size=12pt.
  // Place number after "No." with a gap; match baseline y=45.
  page.drawText(idpNumber.toUpperCase(), { x: 348, y: 45, size: 9, font, color: rgb(0, 0, 0) });
}

// ─── IDP CARD ─────────────────────────────────────────────────────────────────
// Uses card-front-template.jpeg and card-back-template.jpeg as full-page backgrounds.
// Only the dynamic values (name, dates, photo, QR) are drawn on top.
export async function generateIDPCard(
  application: ApplicationForPDF,
  qrBytes: Buffer,
  profilePhotoBytes: Buffer | null
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();

  // Load JPEG template backgrounds
  const frontJpeg = await loadAsset('card-front-template.jpeg');
  const backJpeg  = await loadAsset('card-back-template.jpeg');
  const frontBg   = await pdfDoc.embedJpg(frontJpeg);
  const backBg    = await pdfDoc.embedJpg(backJpeg);

  // Load overlay assets
  const sigBuffer = await loadAsset('signature.png').catch(() => null);
  const sigImg    = sigBuffer ? await pdfDoc.embedPng(sigBuffer) : null;
  const qrImg     = qrBytes   ? await pdfDoc.embedPng(qrBytes)   : null;

  let profileImg = null;
  if (profilePhotoBytes) {
    try {
      const normalizedJpgBytes = await sharp(profilePhotoBytes)
        .rotate()
        .jpeg({ quality: 95 })
        .toBuffer();
      profileImg = await pdfDoc.embedJpg(normalizedJpgBytes);
    } catch (err) {
      console.error("Failed to normalize profile photo with sharp in ID Card, attempting raw embed:", err);
      try       { profileImg = await pdfDoc.embedJpg(profilePhotoBytes); }
      catch (_) { try { profileImg = await pdfDoc.embedPng(profilePhotoBytes); } catch { /* skip */ } }
    }
  }

  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  // Page dimensions match the JPEG templates exactly (1016 × 638 px → pt)
  const CW = 1016;
  const CH = 638;

  // ── FRONT PAGE ──────────────────────────────────────────────────────────────
  const front = pdfDoc.addPage([CW, CH]);

  // Full-page template background
  front.drawImage(frontBg, { x: 0, y: 0, width: CW, height: CH });

  // Profile photo — fits inside the white rectangle placeholder (pixel x=35-292, y=211-517)
  if (profileImg) {
    front.drawImage(profileImg, { x: 35, y: 121, width: 257, height: 306 });
  }

  const black = rgb(0, 0, 0);

  // All colons in the template are vertically aligned at x≈530-536.
  // Every value must start at x=550 (after the colon).

  // FULL NAME
  front.drawText(application.fullName.toUpperCase(), {
    x: 550, y: 340, size: 21, font: bold, color: black,
  });

  // ADDRESS — colon at x≈534; value starts at x=550
  const addrLines = wrapText((application.address || '').toUpperCase(), 400, regular, 18);
  front.drawText(addrLines[0] || '', { x: 550, y: 298, size: 18, font: regular, color: black });
  if (addrLines[1]) {
    front.drawText(addrLines[1], { x: 550, y: 278, size: 18, font: regular, color: black });
  }

  // COUNTRY OF BIRTH (actual birth country)
  front.drawText((application.countryOfBirth || application.country).toUpperCase(), {
    x: 550, y: 220, size: 21, font: bold, color: black,
  });

  // DOB — colon at x≈532; value starts at x=550
  front.drawText(formatDate(application.dob), {
    x: 550, y: 180, size: 21, font: regular, color: black,
  });

  // SEX — colon at x≈531; value starts at x=550
  front.drawText((application.gender || 'MALE').toUpperCase(), {
    x: 550, y: 142, size: 21, font: regular, color: black,
  });

  // CATEGORY — colon at x≈529; value starts at x=550
  front.drawText((application.licenseClass || 'B').toUpperCase(), {
    x: 550, y: 99, size: 21, font: regular, color: black,
  });

  // NOTE: Signature is already embedded in card-front-template.jpeg — do NOT draw again.

  // Footer dates — white text after "ISSUED:" (ends x≈141) and "EXPIRES:" (ends x≈799)
  const white = rgb(1, 1, 1);
  front.drawText(formatDate(application.issueDate), {
    x: 154, y: 19, size: 19, font: bold, color: white,
  });
  front.drawText(formatDate(application.expiryDate), {
    x: 818, y: 19, size: 19, font: bold, color: white,
  });

  // ── BACK PAGE ───────────────────────────────────────────────────────────────
  const back = pdfDoc.addPage([CW, CH]);

  // Full-page template background
  back.drawImage(backBg, { x: 0, y: 0, width: CW, height: CH });

  // IDP Number — after "NO:" label (pixel_y≈210, "NO:" colon ends at x≈628)
  back.drawText(application.idpNumber, {
    x: 640, y: 419, size: 20, font: bold, color: black,
  });

  // License-issuing country centered below the IDP number
  const countryText = (application.countryOfResidence || application.country).toUpperCase();
  const countryWidth = bold.widthOfTextAtSize(countryText, 20);
  const countryX = 670 - countryWidth / 2;
  back.drawText(countryText, {
    x: countryX, y: 385, size: 20, font: bold, color: black,
  });

  // QR code — inside the white rectangle placeholder (template x=568-771, pixel_y=374-565)
  if (qrImg) {
    back.drawImage(qrImg, { x: 572, y: 76, width: 195, height: 183 });
  }

  return await pdfDoc.save();
}

// ─── IDP BOOKLET (11 A4 pages, blank template) ────────────────────────────────
// Loads booklet-template-blank.pdf and overlays user data at field positions.
export async function generateIDPBooklet(
  application: ApplicationForPDF,
  qrBytes: Buffer,
  profilePhotoBytes: Buffer | null
): Promise<Uint8Array> {
  const bookletBytes = fs.readFileSync(path.join(process.cwd(), 'booklet-template-blank.pdf'));
  const pdfDoc = await PDFDocument.load(bookletBytes);

  const stampBuffer = await loadAsset('stamp.png').catch(() => null);
  const sigBuffer   = await loadAsset('signature.png').catch(() => null);
  const stampImg    = stampBuffer ? await pdfDoc.embedPng(stampBuffer) : null;
  const sigImg      = sigBuffer   ? await pdfDoc.embedPng(sigBuffer)   : null;
  const qrImg       = qrBytes     ? await pdfDoc.embedPng(qrBytes)     : null;

  let profileImg = null;
  if (profilePhotoBytes) {
    try {
      const normalizedJpgBytes = await sharp(profilePhotoBytes)
        .rotate()
        .jpeg({ quality: 95 })
        .toBuffer();
      profileImg = await pdfDoc.embedJpg(normalizedJpgBytes);
    } catch (err) {
      console.error("Failed to normalize profile photo with sharp in Booklet, attempting raw embed:", err);
      try       { profileImg = await pdfDoc.embedJpg(profilePhotoBytes); }
      catch (_) { try { profileImg = await pdfDoc.embedPng(profilePhotoBytes); } catch { /* skip */ } }
    }
  }

  const reg  = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pages  = pdfDoc.getPages();
  const W      = 595.28;
  const MARGIN = 50;
  const black  = rgb(0, 0, 0);

  // Helper to draw left-aligned values in the booklet (at x=270, size=11)
  const drawVal = (page: PDFPage, value: string, y: number) => {
    page.drawText(value.toUpperCase(), { x: 270, y, size: 11, font: bold, color: black });
  };

  // ── PAGE 1 · COVER ──────────────────────────────────────────────────────────
  const p1 = pages[0];

  // IDP number — centered on the page width (W = 595.28) and raised slightly above dots
  const idpUpper = application.idpNumber.toUpperCase();
  const idpWidth = bold.widthOfTextAtSize(idpUpper, 13);
  const idpX = 297.64 - idpWidth / 2;
  p1.drawText(idpUpper, { x: idpX, y: 651, size: 13, font: bold, color: black });

  // Dates & License — placed in the dotted-line area, raised by 4 points to sit neatly above the dots
  p1.drawText(formatDate(application.expiryDate).toUpperCase(), { x: 265, y: 476, size: 12, font: bold, color: black });
  p1.drawText(formatDate(application.issueDate).toUpperCase(),  { x: 265, y: 442, size: 12, font: bold, color: black });
  p1.drawText((application.licenseNumber || '').toUpperCase(),    { x: 265, y: 408, size: 12, font: bold, color: black });

  // Draw stamp on the left side of the Authorized Signatory section
  if (stampImg) {
    // Cover the pre-printed black circle and "Seal or Stamp" text completely
    p1.drawRectangle({
      x: 35,
      y: 65,
      width: 150,
      height: 150,
      color: rgb(1, 1, 1),
    });

    // Draw the stamp centered over that area (x-center=110, y-center=140, size=130x130, no transparent padding)
    p1.drawImage(stampImg, { x: 45, y: 75, width: 130, height: 130, opacity: 0.85 });
  }

  // NOTE: Template already has a signature embedded — do NOT draw sigImg again.

  // ── PAGE 4 · PARTICULAR CONCERNING THE DRIVER (English) ─────────────────────
  const p4 = pages[3];

  drawVal(p4, application.fullName.toUpperCase(),                                      755);
  drawVal(p4, (application.parentName || '').toUpperCase(),                              731);
  drawVal(p4, (application.countryOfBirth || application.country).toUpperCase(),      706);
  drawVal(p4, formatDate(application.dob).toUpperCase(),                                682);

  // Address wraps at a narrower width (240 pt) to avoid overlapping the pre-printed index numbers, using size 8 to fit in 2 lines
  const addrEn = wrapText((application.address || '').toUpperCase(), 240, bold, 8);
  addrEn.slice(0, 3).forEach((line, index) => {
    p4.drawText(line, { x: 270, y: 657 - index * 10, size: 8, font: bold, color: black });
  });

  // ── PAGE 5 · VEHICLE CATEGORIES + PHOTO (English) ───────────────────────────
  const p5 = pages[4];

  // Cover the pre-printed "Seal or Stamp" oval completely (border + text) under the photo
  p5.drawRectangle({
    x: 346,
    y: 470,
    width: 110,
    height: 70,
    color: rgb(1, 1, 1),
  });

  if (profileImg) {
    // Fits the black frame perfectly (x=308, y=498, width=186, height=186)
    p5.drawImage(profileImg, { x: 308, y: 498, width: 186, height: 186 });
  }

  if (stampImg) {
    // Centered at the bottom edge of the photo frame (x-center=401, y-center=498, size=100x100, no padding)
    p5.drawImage(stampImg, { x: 351, y: 448, width: 100, height: 100, opacity: 0.75 });
  }

  // Draw category stamp next to selected categories
  const selectedCategories = (application.licenseClass || '')
    .split(',')
    .map(s => s.trim().toUpperCase())
    .filter(Boolean);

  const categoryYMap: Record<string, number> = {
    A: 650,
    B: 590,
    C: 530,
    D: 470,
    E: 410,
  };

  selectedCategories.forEach(cat => {
    const yCenter = categoryYMap[cat];
    if (yCenter && stampImg) {
      // Draw the stamp centered in the Column 1 blank rectangle (x=75, size=50x50, no padding, shifted up)
      p5.drawImage(stampImg, {
        x: 75,
        y: yCenter - 18,
        width: 50,
        height: 50,
        opacity: 0.75,
      });
    }
  });

  // ── PAGE 6 · INDICATIONS RELATIVES AU CONDUCTEUR (French) ───────────────────
  const p6 = pages[5];

  drawVal(p6, application.fullName.toUpperCase(),                                      746);
  drawVal(p6, (application.parentName || '').toUpperCase(),                              722);
  drawVal(p6, (application.countryOfBirth || application.country).toUpperCase(),      697);
  drawVal(p6, formatDate(application.dob).toUpperCase(),                                673);

  const addrFr = wrapText((application.address || '').toUpperCase(), 240, bold, 8);
  addrFr.slice(0, 3).forEach((line, index) => {
    p6.drawText(line, { x: 270, y: 648 - index * 10, size: 8, font: bold, color: black });
  });

  // ── PAGE 7 · VEHICLE CATEGORIES + PHOTO (French) ────────────────────────────
  const p7 = pages[6];

  // Cover the pre-printed "Seal or Stamp" oval completely (border + text) under the photo
  p7.drawRectangle({
    x: 346,
    y: 470,
    width: 110,
    height: 70,
    color: rgb(1, 1, 1),
  });

  if (profileImg) {
    p7.drawImage(profileImg, { x: 308, y: 498, width: 186, height: 186 });
  }

  if (stampImg) {
    // Centered at the bottom edge of the photo frame (x-center=401, y-center=498, size=100x100, no padding)
    p7.drawImage(stampImg, { x: 351, y: 448, width: 100, height: 100, opacity: 0.75 });
  }

  selectedCategories.forEach(cat => {
    const yCenter = categoryYMap[cat];
    if (yCenter && stampImg) {
      // Draw the stamp centered in the Column 1 blank rectangle (x=75, size=50x50, no padding, shifted up)
      p7.drawImage(stampImg, {
        x: 75,
        y: yCenter - 18,
        width: 50,
        height: 50,
        opacity: 0.75,
      });
    }
  });

  // ── PAGE 11 · BACK COVER ─────────────────────────────────────────────────────
  const p11 = pages[10];
  if (qrImg) {
    p11.drawImage(qrImg, { x: (W - 110) / 2, y: 65, width: 110, height: 110 });
  }

  // IDP number footer on pages 2-10 (cover has its own prominent field, skip it)
  pages.slice(1, 10).forEach(p => drawBottomNo(p, reg, application.idpNumber));

  return await pdfDoc.save();
}

const dummyRazorpay = {} as any;
export default dummyRazorpay;
