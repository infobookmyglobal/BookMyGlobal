// ─── lib/geo.ts ───────────────────────────────────────────────────────────────

const CURRENCY_MAP: Record<string, { code: string; symbol: string }> = {
  IN: { code: 'INR', symbol: '₹' },
  US: { code: 'USD', symbol: '$' },
  CA: { code: 'CAD', symbol: 'CA$' },
  GB: { code: 'GBP', symbol: '£' },
  AU: { code: 'AUD', symbol: 'A$' },
  NZ: { code: 'NZD', symbol: 'NZ$' },
  SG: { code: 'SGD', symbol: 'S$' },
  MY: { code: 'MYR', symbol: 'RM' },
  TH: { code: 'THB', symbol: '฿' },
  JP: { code: 'JPY', symbol: '¥' },
  CN: { code: 'CNY', symbol: '¥' },
  AE: { code: 'AED', symbol: 'AED' },
  SA: { code: 'SAR', symbol: '﷼' },
  KW: { code: 'KWD', symbol: 'KD' },
  QA: { code: 'QAR', symbol: 'QR' },
  BH: { code: 'BHD', symbol: 'BD' },
  OM: { code: 'OMR', symbol: 'OMR' },
  ZA: { code: 'ZAR', symbol: 'R' },
  NG: { code: 'NGN', symbol: '₦' },
  KE: { code: 'KES', symbol: 'KSh' },
  GH: { code: 'GHS', symbol: '₵' },
  // EU Countries
  DE: { code: 'EUR', symbol: '€' },
  FR: { code: 'EUR', symbol: '€' },
  IT: { code: 'EUR', symbol: '€' },
  ES: { code: 'EUR', symbol: '€' },
  NL: { code: 'EUR', symbol: '€' },
  BE: { code: 'EUR', symbol: '€' },
  AT: { code: 'EUR', symbol: '€' },
  PT: { code: 'EUR', symbol: '€' },
  GR: { code: 'EUR', symbol: '€' },
  FI: { code: 'EUR', symbol: '€' },
  IE: { code: 'EUR', symbol: '€' },
  LU: { code: 'EUR', symbol: '€' },
  MT: { code: 'EUR', symbol: '€' },
  CY: { code: 'EUR', symbol: '€' },
  SK: { code: 'EUR', symbol: '€' },
  SI: { code: 'EUR', symbol: '€' },
  EE: { code: 'EUR', symbol: '€' },
  LV: { code: 'EUR', symbol: '€' },
  LT: { code: 'EUR', symbol: '€' },
};

const LANGUAGE_MAP: Record<string, string> = {
  AE: 'ar', SA: 'ar', KW: 'ar', QA: 'ar', BH: 'ar', OM: 'ar',
  JO: 'ar', LB: 'ar', EG: 'ar', MA: 'ar', TN: 'ar', DZ: 'ar',
  LY: 'ar', IQ: 'ar', SY: 'ar', YE: 'ar',
  FR: 'fr', BE: 'fr', CH: 'fr', SN: 'fr', CI: 'fr', CM: 'fr',
  ES: 'es', MX: 'es', CO: 'es', AR: 'es', CL: 'es', PE: 'es',
  VE: 'es', EC: 'es', BO: 'es', PY: 'es', UY: 'es', GT: 'es',
  HN: 'es', SV: 'es', NI: 'es', CR: 'es', PA: 'es', CU: 'es',
  DO: 'es',
};

export type GeoData = {
  country_code: string;
  country_name: string;
  currency: string;
  symbol: string;
  language: string;
};

function mapToCurrency(code: string): { code: string; symbol: string } {
  return CURRENCY_MAP[code] ?? { code: 'USD', symbol: '$' };
}

function mapToLanguage(code: string): string {
  return LANGUAGE_MAP[code] ?? 'en';
}

export function defaultGeo(): GeoData {
  return {
    country_code: 'US',
    country_name: 'United States',
    currency: 'USD',
    symbol: '$',
    language: 'en',
  };
}

const COUNTRY_NAME_MAP: Record<string, string> = {
  IN: 'India',
  US: 'United States',
  CA: 'Canada',
  GB: 'United Kingdom',
  AU: 'Australia',
  NZ: 'New Zealand',
  SG: 'Singapore',
  MY: 'Malaysia',
  TH: 'Thailand',
  JP: 'Japan',
  CN: 'China',
  AE: 'United Arab Emirates',
  SA: 'Saudi Arabia',
  KW: 'Kuwait',
  QA: 'Qatar',
  BH: 'Bahrain',
  OM: 'Oman',
  ZA: 'South Africa',
  DE: 'Germany',
  FR: 'France',
  IT: 'Italy',
  ES: 'Spain',
  NL: 'Netherlands',
  BE: 'Belgium',
  AT: 'Austria',
  PT: 'Portugal',
  IE: 'Ireland',
};

export async function detectGeo(ip?: string, headerCountry?: string | null): Promise<GeoData> {
  // If we have a country code from the CDN headers, use it!
  if (headerCountry && headerCountry !== 'XX' && headerCountry !== 'T1') {
    const cleanCountry = headerCountry.toUpperCase();
    const { code, symbol } = mapToCurrency(cleanCountry);
    const countryName = COUNTRY_NAME_MAP[cleanCountry] || cleanCountry;
    return {
      country_code: cleanCountry,
      country_name: countryName,
      currency: code,
      symbol,
      language: mapToLanguage(cleanCountry),
    };
  }

  // 1. Try ipapi.co
  try {
    const apiKey = process.env.NEXT_PUBLIC_GEO_API_KEY;
    const query = apiKey ? `?key=${apiKey}` : '';
    const url = ip 
      ? `https://ipapi.co/${ip}/json/${query}` 
      : `https://ipapi.co/json/${query}`;
    const res = await fetch(url, { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      if (!data.error) {
        const { code, symbol } = mapToCurrency(data.country_code);
        return {
          country_code: data.country_code ?? 'US',
          country_name: data.country_name ?? 'United States',
          currency: code,
          symbol,
          language: mapToLanguage(data.country_code),
        };
      }
    }
  } catch (e) {
    console.error("ipapi.co failed, trying fallback:", e);
  }

  // 2. Try ip-api.com as fallback
  try {
    const url = ip 
      ? `http://ip-api.com/json/${ip}` 
      : `http://ip-api.com/json/`;
    const res = await fetch(url, { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      if (data.status === 'success') {
        const { code, symbol } = mapToCurrency(data.countryCode);
        return {
          country_code: data.countryCode ?? 'US',
          country_name: data.country ?? 'United States',
          currency: code,
          symbol,
          language: mapToLanguage(data.countryCode),
        };
      }
    }
  } catch (e) {
    console.error("ip-api.com fallback failed:", e);
  }

  return defaultGeo();
}
