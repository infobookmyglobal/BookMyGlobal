import QRCode from 'qrcode'

export async function generateQRCode(applicationId: string, origin?: string): Promise<Buffer> {
  let appUrl = origin || process.env.NEXT_PUBLIC_APP_URL;

  // Fallback to the production domain if appUrl is not set or points to localhost
  // (since a QR code scanned by a user's phone needs to be public anyway)
  if (!appUrl || appUrl.includes('localhost')) {
    appUrl = 'https://www.bookmyglobal.com';
  }

  // Remove trailing slash if present
  appUrl = appUrl.replace(/\/$/, '');

  const url = `${appUrl}/verify/${applicationId}`
  const dataUrl = await QRCode.toDataURL(url, {
    width: 200,
    margin: 1,
    color: { dark: '#000000', light: '#ffffff' }
  })
  const base64 = dataUrl.replace('data:image/png;base64,', '')
  return Buffer.from(base64, 'base64')
}

