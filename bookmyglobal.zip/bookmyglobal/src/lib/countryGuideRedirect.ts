import { prisma } from "@/lib/prisma";

/**
 * Returns the slug of the matching "Travel Guides" page under Know More for a given country name or slug.
 * Returns null if no matching travel guide is found.
 */
export async function getTravelGuideSlugForCountry(countryNameOrSlug: string): Promise<string | null> {
  if (!countryNameOrSlug) return null;

  try {
    const guides = await prisma.page.findMany({
      where: {
        isActive: true,
        category: "Travel Guides",
      },
      select: {
        slug: true,
        title: true,
      },
    });

    if (!guides.length) return null;

    const raw = countryNameOrSlug.trim().toLowerCase();

    // Normalize country name / slug (e.g. "albania-international-driving-permit" -> "albania")
    const countryBaseName = raw
      .replace(/-international-driving-permit$/i, "")
      .replace(/-/g, " ")
      .trim();

    const countrySlugBase = countryBaseName.replace(/\s+/g, "-");

    // 1. Exact or prefix match on title (e.g., "Albania Complete Driving...")
    let match = guides.find((g) => {
      const titleLower = g.title.toLowerCase();
      return (
        titleLower.startsWith(countryBaseName + " ") ||
        titleLower.startsWith(countryBaseName + ":") ||
        titleLower.startsWith(countryBaseName + "—") ||
        titleLower.startsWith(countryBaseName + " -")
      );
    });

    // 2. Prefix match on slug (e.g., "albania-complete-driving...")
    if (!match) {
      match = guides.find((g) => {
        const slugLower = g.slug.toLowerCase();
        return slugLower === countrySlugBase || slugLower.startsWith(countrySlugBase + "-");
      });
    }

    // 3. Word boundary match in title
    if (!match) {
      match = guides.find((g) => {
        const titleLower = g.title.toLowerCase();
        const regex = new RegExp(`\\b${countryBaseName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i");
        return regex.test(titleLower);
      });
    }

    return match ? match.slug : null;
  } catch (error) {
    console.error("Error finding travel guide for country:", error);
    return null;
  }
}

/**
 * Returns a map of country names / slugs to their matching Travel Guide slug.
 * Useful for bulk client components like CountryList or IDPListClient.
 */
export async function getAllCountryTravelGuideMap(): Promise<Record<string, string>> {
  const map: Record<string, string> = {};
  try {
    const guides = await prisma.page.findMany({
      where: {
        isActive: true,
        category: "Travel Guides",
      },
      select: {
        slug: true,
        title: true,
      },
    });

    for (const guide of guides) {
      // Extract main country word(s) from title before "Complete", "International", "Driving", "Guide", ":", etc.
      const title = guide.title;
      // Match patterns like "Albania Complete Driving...", "Albania International Driving Permit...", "Albania Driving & IDP Guide..."
      const match = title.match(/^([A-Za-z\s]+?)\s+(?:Complete|International|Driving|IDP|Guide|202\d|:|-|—)/i);
      if (match && match[1]) {
        const countryName = match[1].trim();
        if (countryName && countryName.length > 2) {
          map[countryName.toLowerCase()] = guide.slug;
        }
      }
    }
  } catch (error) {
    console.error("Error building country travel guide map:", error);
  }
  return map;
}

/**
 * Returns the final redirect URL for a country, checking manual override settings first,
 * then falling back to auto-matched Travel Guides.
 */
export async function getTravelGuideRedirectUrlForCountry(
  countrySlug: string,
  countryName?: string
): Promise<string | null> {
  if (!countrySlug && !countryName) return null;

  const slugKey = countrySlug ? countrySlug.trim().toLowerCase() : "";
  const nameKey = countryName ? countryName.trim().toLowerCase() : "";

  // 1. Check DB for custom manual redirects mapping
  try {
    const setting = await prisma.setting.findUnique({
      where: { key: "country_redirects_map" },
    });

    if (setting && setting.value) {
      const redirectsMap: Record<string, string> = JSON.parse(setting.value);
      const customTarget =
        redirectsMap[slugKey] || (nameKey ? redirectsMap[nameKey] : undefined);

      if (customTarget && customTarget.trim()) {
        const target = customTarget.trim();
        // If explicitly set to "default", "none", or self country URL -> do not redirect
        if (
          target.toLowerCase() === "none" ||
          target.toLowerCase() === "default" ||
          target.toLowerCase() === `/countries/${slugKey}`
        ) {
          return null;
        }
        return target.startsWith("/") || target.startsWith("http") ? target : `/${target}`;
      }
    }
  } catch (err) {
    console.error("Error reading country_redirects_map:", err);
  }

  // 2. Fallback to auto-detected travel guide
  const autoSlug = await getTravelGuideSlugForCountry(countryName || countrySlug);
  if (autoSlug) {
    return `/${autoSlug}`;
  }

  return null;
}
