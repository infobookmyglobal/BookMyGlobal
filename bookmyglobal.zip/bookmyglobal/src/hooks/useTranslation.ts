"use client";

import { useGeoStore } from "@/store/geoStore";
import en from "../../messages/en.json";
import es from "../../messages/es.json";
import fr from "../../messages/fr.json";
import ar from "../../messages/ar.json";
import de from "../../messages/de.json";
import it from "../../messages/it.json";
import ja from "../../messages/ja.json";
import hi from "../../messages/hi.json";

const translations: Record<string, any> = { en, es, fr, ar, de, it, ja, hi };

export function useTranslation() {
  const { language } = useGeoStore();
  const messages = translations[language] || en;

  const t = (key: string): string => {
    const keys = key.split(".");
    let current: any = messages;
    for (const k of keys) {
      if (current && typeof current === "object" && k in current) {
        current = current[k];
      } else {
        // fallback to English
        let fallback: any = en;
        for (const fk of keys) {
          if (fallback && typeof fallback === "object" && fk in fallback) {
            fallback = fallback[fk];
          } else {
            return key;
          }
        }
        return typeof fallback === "string" ? fallback : key;
      }
    }
    return typeof current === "string" ? current : key;
  };

  return { t, language };
}
