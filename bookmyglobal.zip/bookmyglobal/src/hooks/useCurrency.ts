'use client';

import { useGeoStore } from '@/store/geoStore';
import { convertPrice, formatPrice, FALLBACK_RATES } from '@/lib/currency';

export function useCurrency() {
  const { currency, symbol, exchangeRates } = useGeoStore();
  const rates = exchangeRates ?? FALLBACK_RATES;

  const format = (usdAmount: number): string => {
    const converted = convertPrice(usdAmount, currency, rates);
    return formatPrice(converted, currency);
  };

  const convert = (usdAmount: number): number =>
    convertPrice(usdAmount, currency, rates);

  return { format, convert, currency, symbol };
}
