'use client';

import { useEffect } from 'react';
import { useGeoStore } from '@/store/geoStore';
import { FALLBACK_RATES } from '@/lib/currency';

const GEO_CACHE_TTL = 1 * 60 * 60 * 1000; // 1 hour

export function useGeo() {
  const { setGeo, setRates } = useGeoStore();

  useEffect(() => {
    async function init() {
      const state = useGeoStore.getState();
      const cacheAge = state.fetchedAt ? Date.now() - state.fetchedAt : Infinity;

      // 1. If cache is fresh, load rates if missing
      if (cacheAge < GEO_CACHE_TTL && state.nativeCurrency) {
        if (!state.exchangeRates) {
          fetchAndSetRates(state.currency, setRates);
        }
        return;
      }

      // 2. Fetch fresh geo from our API in the background
      try {
        const res = await fetch('/api/geo', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          
          // If location changed or hasn't been set yet
          if (!state.nativeCurrency || state.nativeCurrency !== data.currency) {
            setGeo({
              country: data.country_code,
              countryName: data.country_name,
              currency: data.currency,
              symbol: data.symbol,
              language: data.language,
              nativeCurrency: data.currency,
              nativeSymbol: data.symbol,
              fetchedAt: Date.now(),
            });
            fetchAndSetRates(data.currency, setRates);
          } else {
            // Location is the same, just update timestamp to keep cache valid
            setGeo({
              fetchedAt: Date.now(),
            });
            fetchAndSetRates(state.currency, setRates);
          }
        } else {
          throw new Error('Geo API request failed');
        }
      } catch (err) {
        console.error("Geo detection failed on initialization:", err);
        if (!state.exchangeRates) {
          setRates(FALLBACK_RATES);
        }
      }
    }

    init();
  }, [setGeo, setRates]);
}

async function fetchAndSetRates(
  currency: string,
  setRates: (rates: Record<string, number>) => void
) {
  try {
    const res = await fetch('/api/geo/rates', { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      setRates(data.rates ?? FALLBACK_RATES);
    } else {
      setRates(FALLBACK_RATES);
    }
  } catch {
    setRates(FALLBACK_RATES);
  }
}
