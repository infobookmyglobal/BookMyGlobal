import Link from "next/link";

export function Logo({ className = "", light = true }: { className?: string; light?: boolean }) {
  const base = light ? "text-white" : "text-navy";
  const mid = light ? "text-gold" : "text-blue";
  return (
    <Link href="/" className={`font-sora font-extrabold text-lg tracking-tight ${className}`} aria-label="BookMyGlobal home">
      <span className={base}>Book</span>
      <span className={mid}>My</span>
      <span className={base}>Global</span>
    </Link>
  );
}
