"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { Search, X } from "lucide-react";

interface DestPage {
  slug: string;
  urlPath: string;
  country: string;
  cityName: string;
  metaDescription: string;
  pageType: string;
}

interface IDPListClientProps {
  initialPages: DestPage[];
  travelGuideMap?: Record<string, string>;
}

function idpHref(slug: string) {
  return `/idp/${slug}`;
}

export function IDPListClient({ initialPages, travelGuideMap = {} }: IDPListClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSearch, setActiveSearch] = useState("");

  const filteredPages = useMemo(() => {
    const q = activeSearch.toLowerCase().trim();
    if (!q) return initialPages;
    return initialPages.filter(
      (p) =>
        p.country.toLowerCase().includes(q) ||
        p.cityName.toLowerCase().includes(q) ||
        p.metaDescription.toLowerCase().includes(q)
    );
  }, [activeSearch, initialPages]);

  // Group by country
  const grouped = useMemo(() => {
    return filteredPages.reduce<Record<string, DestPage[]>>((acc, page) => {
      if (!acc[page.country]) acc[page.country] = [];
      acc[page.country].push(page);
      return acc;
    }, {});
  }, [filteredPages]);

  const countries = useMemo(() => {
    return Object.keys(grouped).sort();
  }, [grouped]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveSearch(searchQuery);
  };

  const handleClear = () => {
    setSearchQuery("");
    setActiveSearch("");
  };

  return (
    <div className="idp-list-content">
      {/* Search Input Container */}
      <form onSubmit={handleSearchSubmit} className="search-container">
        <div className="search-wrapper">
          <Search className="search-icon w-5 h-5 text-slate-400 mr-2 shrink-0" />
          <input
            type="text"
            placeholder="Search country or city..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              // Also update instantly for great UX
              setActiveSearch(e.target.value);
            }}
            className="search-input"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={handleClear}
              className="clear-button p-1 hover:bg-slate-100 rounded-full mr-2 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button type="submit" className="search-button">
            Search
          </button>
        </div>
      </form>

      {/* Country sections listing */}
      {countries.map((country) => {
        const countryPages = grouped[country];
        const hubPage = countryPages.find((p) => p.pageType === 'HUB');
        const cityPages = countryPages.filter((p) => p.pageType === 'CITY');

        const travelGuideSlug = travelGuideMap[country.toLowerCase()];
        const hubHref = travelGuideSlug ? `/${travelGuideSlug}` : (hubPage ? idpHref(hubPage.slug) : "#");

        return (
          <section key={country} className="idp-country-section">
            <div className="idp-country-section__inner">
              <h2 className="idp-country-section__title">{country}</h2>

              {/* Hub Page Card */}
              {hubPage && (
                <Link href={hubHref} className="idp-hub-card" id={`hub-${hubPage.slug}`}>
                  <div className="idp-hub-card__left">
                    <span className="idp-hub-card__badge">🏛️ Country Guide</span>
                    <h3 className="idp-hub-card__name">{hubPage.cityName.replace(/\s*[Hh]ub\s*$/, "")}</h3>
                    <p className="idp-hub-card__desc">{hubPage.metaDescription}</p>
                  </div>
                  <span className="idp-hub-card__link">View Full Guide →</span>
                </Link>
              )}

              {/* City Page Grid */}
              {cityPages.length > 0 && (
                <div className="idp-city-grid">
                  {cityPages.map((city) => (
                    <Link key={city.slug} href={idpHref(city.slug)} className="idp-city-card" id={`city-${city.slug}`}>
                      <span className="idp-city-card__type">🏙️ City Guide</span>
                      <h3 className="idp-city-card__name">{city.cityName}</h3>
                      <p className="idp-city-card__desc">{city.metaDescription}</p>
                      <span className="idp-city-card__link">View Guide →</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </section>
        );
      })}

      {countries.length === 0 && initialPages.length > 0 && (
        <div className="no-results">
          <p className="no-results__text">No destination guides found matching &ldquo;{activeSearch}&rdquo;</p>
          <button onClick={handleClear} className="no-results__btn">
            Clear Search
          </button>
        </div>
      )}

      {initialPages.length === 0 && (
        <div className="loading-placeholder">
          Destination guides loading...
        </div>
      )}

      <style>{`
        .search-container {
          max-width: 550px;
          width: 100%;
          margin: 0 auto 32px;
        }
        .search-wrapper {
          display: flex;
          align-items: center;
          background: white;
          border: 2px solid #e2e8f0;
          border-radius: 9999px;
          padding: 6px 8px 6px 18px;
          transition: all 0.2s ease;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        }
        .search-wrapper:focus-within {
          border-color: #0033CC;
          box-shadow: 0 0 0 3px rgba(0, 51, 204, 0.15);
        }
        .search-input {
          flex: 1;
          border: none;
          outline: none;
          font-family: var(--font-dmsans);
          font-size: 15px;
          color: #001A66;
          padding: 8px 0;
          background: transparent;
        }
        .search-input::placeholder {
          color: #94a3b8;
        }
        .search-button {
          background: #0033CC;
          color: white;
          border: none;
          border-radius: 9999px;
          padding: 8px 22px;
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.2s ease;
          box-shadow: 0 2px 4px rgba(0, 51, 204, 0.2);
        }
        .search-button:hover {
          background: #001A66;
          transform: translateY(-1px);
        }
        .clear-button {
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .no-results {
          text-align: center;
          padding: 64px 24px;
          background: #f8fafc;
          border-radius: 20px;
          border: 2px dashed #e2e8f0;
          max-width: 550px;
          margin: 0 auto;
        }
        .no-results__text {
          font-family: var(--font-dmsans);
          font-size: 15px;
          color: #64748b;
          margin: 0 0 16px;
        }
        .no-results__btn {
          background: #0033CC;
          color: white;
          border: none;
          border-radius: 10px;
          padding: 8px 18px;
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .no-results__btn:hover {
          background: #001A66;
        }
        .loading-placeholder {
          text-align: center;
          padding: 80px 24px;
          color: #64748b;
          font-family: var(--font-dmsans);
        }
      `}</style>
    </div>
  );
}
