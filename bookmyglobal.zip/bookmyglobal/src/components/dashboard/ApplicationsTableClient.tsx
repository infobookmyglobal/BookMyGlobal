"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Eye } from "lucide-react";
import { StatusBadge } from "./StatusBadge";
import { ViewApplicationModal } from "./ViewApplicationModal";

interface Application {
  id: string;
  idpNumber: string | null;
  productType: string;
  validity: number;
  status: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  address: string | null;
  dob: Date | string | null;
  licenseNumber: string | null;
  licenseIssueDate: Date | string | null;
  licenseExpiryDate: Date | string | null;
  gender: string | null;
  countryOfBirth: string | null;
  countryOfResidence: string | null;
  licenseClass: string | null;
  parentName: string | null;
  destinationCountry: string | null;
  passportUrl: string | null;
  licenseUrl: string | null;
  profilePhotoUrl: string | null;
  pdfBookletUrl: string | null;
  pdfIdCardUrl: string | null;
  adminNotes: string | null;
  rejectionReason: string | null;
  createdAt: Date | string;
  currency: string;
  baseAmount: number;
  finalAmount: number;
  couponCode: string | null;
}

interface ApplicationsTableClientProps {
  applications: Application[];
}

export function ApplicationsTableClient({ applications }: ApplicationsTableClientProps) {
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  return (
    <>
      <div className="bg-white border border-border-custom rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-navy text-white text-xs uppercase tracking-wider">
                <th className="p-4 text-left">ID</th>
                <th className="p-4 text-left">Product</th>
                <th className="p-4 text-left">Validity</th>
                <th className="p-4 text-left">Amount</th>
                <th className="p-4 text-left">Status</th>
                <th className="p-4 text-left">Date</th>
                <th className="p-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-custom">
              {applications.map((app) => (
                <tr key={app.id} className="hover:bg-bg-custom transition-colors">
                  <td className="p-4 font-mono font-bold text-xs text-muted">
                    {app.idpNumber || `#${app.id.slice(-8).toUpperCase()}`}
                  </td>
                  <td className="p-4 font-bold text-navy">
                    {app.productType === "NFC_KIT" ? "NFC Smart Kit" : "Digital IDP"}
                  </td>
                  <td className="p-4 text-muted">{app.validity}yr</td>
                  <td className="p-4 font-bold">
                    ${app.finalAmount} {app.currency}
                  </td>
                  <td className="p-4">
                    <StatusBadge status={app.status} />
                  </td>
                  <td className="p-4 text-muted">
                    {new Date(app.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <div className="flex flex-wrap items-center gap-3">
                      {/* View eye button */}
                      <button
                        onClick={() => setSelectedApp(app)}
                        className="text-[11px] font-bold text-navy hover:underline flex items-center gap-1 cursor-pointer bg-transparent border-none p-0"
                        title="View details and approved documents"
                      >
                        <Eye className="w-3.5 h-3.5" /> View
                      </button>

                      {app.status === "PENDING" && !app.passportUrl && (
                        <Link
                          href="/dashboard/upload"
                          className="text-[11px] font-bold text-blue hover:underline"
                        >
                          Upload Docs
                        </Link>
                      )}

                      {app.status !== "APPROVED" && app.status !== "COMPLETED" && (
                        <Link
                          href={`/dashboard/applications/${app.id}/edit`}
                          className="text-[11px] font-bold text-orange-600 hover:underline"
                        >
                          Edit Form
                        </Link>
                      )}

                      {app.status === "APPROVED" && app.pdfBookletUrl && (
                        <Link
                          href="/dashboard/download"
                          className="text-[11px] font-bold text-green-600 hover:underline"
                        >
                          Download
                        </Link>
                      )}

                      <Link
                        href={`/verify/${app.id}`}
                        className="text-[11px] font-bold text-muted hover:underline"
                      >
                        Verify
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <ViewApplicationModal
        isOpen={selectedApp !== null}
        onClose={() => setSelectedApp(null)}
        application={selectedApp}
      />
    </>
  );
}
