"use client";

import React from "react";
import { X, User, FileText, Calendar, MapPin, Download, Eye } from "lucide-react";
import { StatusBadge } from "./StatusBadge";

interface Application {
  id: string;
  idpNumber: string | null;
  productType: string;
  validity: number;
  status: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  address: string | null;
  dob: Date | string | null;
  licenseNumber: string | null;
  licenseIssueDate: Date | string | null;
  licenseExpiryDate: Date | string | null;
  gender: string | null;
  countryOfBirth: string | null;
  countryOfResidence: string | null;
  licenseClass: string | null;
  parentName: string | null;
  destinationCountry: string | null;
  passportUrl: string | null;     // License Back
  licenseUrl: string | null;      // License Front
  profilePhotoUrl: string | null; // Profile photo
  pdfBookletUrl: string | null;
  pdfIdCardUrl: string | null;
  adminNotes: string | null;
  rejectionReason: string | null;
  createdAt: Date | string;
  currency: string;
  baseAmount: number;
  finalAmount: number;
  couponCode: string | null;
}

interface ViewApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  application: Application | null;
}

export function ViewApplicationModal({ isOpen, onClose, application }: ViewApplicationModalProps) {
  if (!isOpen || !application) return null;

  const formatDate = (dateVal: Date | string | null) => {
    if (!dateVal) return "N/A";
    return new Date(dateVal).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getProductLabel = (type: string) => {
    return type === "NFC_KIT" ? "NFC Smart Kit (Physical + Digital)" : "Digital IDP Only";
  };

  const getMediaUrl = (urlOrKey: string | null) => {
    if (!urlOrKey) return "";
    if (urlOrKey.startsWith("http") || urlOrKey.startsWith("/")) return urlOrKey;
    const cfDomain = process.env.NEXT_PUBLIC_CLOUDFRONT_DOMAIN || "dxndggch6n61v.cloudfront.net";
    return `https://${cfDomain}/${urlOrKey}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop overlay */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl transition-all border border-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h3 className="font-sora text-lg font-black text-navy">
                Application Summary
              </h3>
              <StatusBadge status={application.status} />
            </div>
            <p className="text-xs text-muted font-bold mt-1">
              IDP Number: <span className="font-mono text-navy">{application.idpNumber || "Pending Approval"}</span> | ID: <span className="font-mono text-navy">#{application.id.slice(-8).toUpperCase()}</span>
            </p>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Rejection / Admin Notice Box */}
          {application.status === "REJECTED" && application.rejectionReason && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-sm text-red-800">
              <p className="font-bold mb-1">Rejection Details:</p>
              <p className="font-medium">{application.rejectionReason}</p>
            </div>
          )}

          {application.adminNotes && (
            <div className="bg-blue/5 border border-blue/10 rounded-2xl p-4 text-sm text-navy">
              <p className="font-bold mb-1">Status Message:</p>
              <p className="font-medium text-xs leading-relaxed">{application.adminNotes}</p>
            </div>
          )}

          {/* Details Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            
            {/* Column 1: Personal and Travel Info */}
            <div className="space-y-6">
              
              {/* Section: Applicant Details */}
              <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-5 space-y-4">
                <h4 className="font-sora text-sm font-black text-navy border-b border-slate-200 pb-2 flex items-center gap-2">
                  <User className="w-4 h-4 text-blue" />
                  Personal Information
                </h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Full Name</span>
                    <span className="font-bold text-navy">{application.fullName}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Gender</span>
                    <span className="font-bold text-navy capitalize">{application.gender || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Date of Birth</span>
                    <span className="font-bold text-navy">{formatDate(application.dob)}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Parent's Name</span>
                    <span className="font-bold text-navy">{application.parentName || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Email</span>
                    <span className="font-bold text-navy break-all">{application.email}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Phone</span>
                    <span className="font-bold text-navy">{application.phone}</span>
                  </div>
                </div>
              </div>

              {/* Section: Travel & Product Details */}
              <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-5 space-y-4">
                <h4 className="font-sora text-sm font-black text-navy border-b border-slate-200 pb-2 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue" />
                  Product & Delivery details
                </h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div className="col-span-2">
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Requested Product</span>
                    <span className="font-bold text-navy">{getProductLabel(application.productType)}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Validity Term</span>
                    <span className="font-bold text-navy">{application.validity} Year{application.validity > 1 ? "s" : ""}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Destination Country</span>
                    <span className="font-bold text-navy">{application.destinationCountry || "N/A"}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Delivery Address</span>
                    <span className="font-bold text-navy whitespace-pre-line leading-relaxed">
                      {application.address || "N/A"}
                    </span>
                  </div>
                </div>
              </div>

            </div>

            {/* Column 2: License Details */}
            <div className="space-y-6">
              
              {/* Section: License Info */}
              <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-5 space-y-4">
                <h4 className="font-sora text-sm font-black text-navy border-b border-slate-200 pb-2 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue" />
                  Domestic License details
                </h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">License Number</span>
                    <span className="font-bold text-navy uppercase">{application.licenseNumber || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">License Class</span>
                    <span className="font-bold text-navy uppercase">{application.licenseClass || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Country of Birth</span>
                    <span className="font-bold text-navy">{application.countryOfBirth || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Country of Residence</span>
                    <span className="font-bold text-navy">{application.countryOfResidence || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Issue Date</span>
                    <span className="font-bold text-navy">{formatDate(application.licenseIssueDate)}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Expiry Date</span>
                    <span className="font-bold text-navy">{formatDate(application.licenseExpiryDate)}</span>
                  </div>
                </div>
              </div>

              {/* Section: Submission info */}
              <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-5 space-y-4">
                <h4 className="font-sora text-sm font-black text-navy border-b border-slate-200 pb-2 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue" />
                  Application Metadata
                </h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Submission Date</span>
                    <span className="font-bold text-navy">{formatDate(application.createdAt)}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Base Fee</span>
                    <span className="font-bold text-navy">${application.baseAmount} {application.currency}</span>
                  </div>
                  <div>
                    <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Paid Amount</span>
                    <span className="font-bold text-emerald-600 font-extrabold">${application.finalAmount} {application.currency}</span>
                  </div>
                  {application.couponCode && (
                    <div>
                      <span className="text-muted font-bold block uppercase tracking-wider text-[9px] mb-0.5">Coupon Applied</span>
                      <span className="font-bold text-navy">{application.couponCode}</span>
                    </div>
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* Submitted Documents (Photos) Section */}
          <div className="space-y-4 border-t border-slate-100 pt-6">
            <h4 className="font-sora text-sm font-black text-navy flex items-center gap-2">
              <Eye className="w-4 h-4 text-blue" />
              Uploaded Documents & Approved Photos
            </h4>
            
            <div className="grid sm:grid-cols-3 gap-5">
              {/* Profile Photo */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/30 flex flex-col justify-between h-72">
                <div>
                  <span className="text-[10px] font-black uppercase text-muted tracking-wider block mb-1">Profile Photo</span>
                  <p className="text-[11px] font-bold text-navy truncate">Passport size headshot</p>
                </div>
                <div className="flex-1 flex items-center justify-center my-3 relative overflow-hidden bg-slate-100 rounded-xl max-h-48 border border-dashed border-slate-200">
                  {application.profilePhotoUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img 
                      src={getMediaUrl(application.profilePhotoUrl)} 
                      alt="Profile Photo" 
                      className="w-full h-full object-contain hover:scale-105 transition-transform" 
                    />
                  ) : (
                    <span className="text-xs text-muted font-bold">Not Uploaded</span>
                  )}
                </div>
                {application.profilePhotoUrl && (
                  <a 
                    href={getMediaUrl(application.profilePhotoUrl)} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="mt-2 w-full py-2 bg-slate-100 hover:bg-slate-200 text-navy font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                )}
              </div>

              {/* License Front */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/30 flex flex-col justify-between h-72">
                <div>
                  <span className="text-[10px] font-black uppercase text-muted tracking-wider block mb-1">License Front</span>
                  <p className="text-[11px] font-bold text-navy truncate">{application.licenseNumber || "Driver's license card front"}</p>
                </div>
                <div className="flex-1 flex items-center justify-center my-3 relative overflow-hidden bg-slate-100 rounded-xl max-h-48 border border-dashed border-slate-200">
                  {application.licenseUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img 
                      src={getMediaUrl(application.licenseUrl)} 
                      alt="License Front" 
                      className="w-full h-full object-contain hover:scale-105 transition-transform" 
                    />
                  ) : (
                    <span className="text-xs text-muted font-bold">Not Uploaded</span>
                  )}
                </div>
                {application.licenseUrl && (
                  <a 
                    href={getMediaUrl(application.licenseUrl)} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="mt-2 w-full py-2 bg-slate-100 hover:bg-slate-200 text-navy font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                )}
              </div>

              {/* License Back */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/30 flex flex-col justify-between h-72">
                <div>
                  <span className="text-[10px] font-black uppercase text-muted tracking-wider block mb-1">License Back</span>
                  <p className="text-[11px] font-bold text-navy truncate">Driver's license card back</p>
                </div>
                <div className="flex-1 flex items-center justify-center my-3 relative overflow-hidden bg-slate-100 rounded-xl max-h-48 border border-dashed border-slate-200">
                  {application.passportUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img 
                      src={getMediaUrl(application.passportUrl)} 
                      alt="License Back" 
                      className="w-full h-full object-contain hover:scale-105 transition-transform" 
                    />
                  ) : (
                    <span className="text-xs text-muted font-bold">Not Uploaded</span>
                  )}
                </div>
                {application.passportUrl && (
                  <a 
                    href={getMediaUrl(application.passportUrl)} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="mt-2 w-full py-2 bg-slate-100 hover:bg-slate-200 text-navy font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </a>
                )}
              </div>
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button 
            onClick={onClose} 
            className="px-5 py-2.5 bg-navy hover:bg-[#001A66] text-white text-xs font-black rounded-xl transition-all shadow-md cursor-pointer"
          >
            Close Summary
          </button>
        </div>
      </div>
    </div>
  );
}
