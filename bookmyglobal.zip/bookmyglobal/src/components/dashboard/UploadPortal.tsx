"use client";

import { useState } from "react";
import { DocumentUploader } from "@/components/application/DocumentUploader";
import { CheckCircle, AlertTriangle, Info } from "lucide-react";

type Application = {
  id: string;
  productType: string;
  validity: number;
  status: string;
  passportUrl: string | null;   // License Back
  licenseUrl: string | null;    // License Front
  profilePhotoUrl: string | null;
  adminNotes: string | null;
};

/** Parse the [Re-upload Request] note out of adminNotes for display */
function parseReuploadNote(adminNotes: string | null): string | null {
  if (!adminNotes) return null;
  const match = adminNotes.match(/\[Re-upload Request\]:\s*(.+)/);
  return match ? match[1].trim() : null;
}

export function UploadPortal({ applications }: { applications: Application[] }) {
  const [successId, setSuccessId] = useState<string | null>(null);
  const [uploads, setUploads] = useState<
    Record<string, { passportKey?: string; licenseKey?: string; profileKey?: string }>
  >({});
  const [submitting, setSubmitting] = useState<string | null>(null);

  if (applications.length === 0) {
    return (
      <div className="bg-white border border-border-custom rounded-2xl p-10 text-center">
        <p className="text-muted text-sm font-bold">No applications pending document upload.</p>
      </div>
    );
  }

  const setUpload = (id: string, field: string, key: string) => {
    setUploads((prev) => ({ ...prev, [id]: { ...prev[id], [field]: key } }));
  };

  const handleSubmit = async (app: Application) => {
    const u = uploads[app.id] || {};
    setSubmitting(app.id);
    await fetch(`/api/applications/${app.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        passportUrl: u.passportKey ?? app.passportUrl,
        licenseUrl: u.licenseKey ?? app.licenseUrl,
        profilePhotoUrl: u.profileKey ?? app.profilePhotoUrl,
        status: "UNDER_REVIEW",
      }),
    });
    setSubmitting(null);
    setSuccessId(app.id);
  };

  return (
    <div className="space-y-6">
      {applications.map((app) => {
        const u = uploads[app.id] || {};

        // Determine which docs are actually missing (nulled by admin or never uploaded)
        const needsPassport = !app.passportUrl;   // License Back
        const needsLicense = !app.licenseUrl;     // License Front
        const needsProfile = !app.profilePhotoUrl;

        const isReuploadRequest = needsPassport || needsLicense || needsProfile;
        const isPartialReupload =
          isReuploadRequest &&
          [needsPassport, needsLicense, needsProfile].filter(Boolean).length < 3;

        const reuploadNote = parseReuploadNote(app.adminNotes);

        // Submit enabled only when all *required* docs are satisfied
        const allDone =
          (needsPassport ? !!u.passportKey : true) &&
          (needsLicense ? !!u.licenseKey : true) &&
          (needsProfile ? !!u.profileKey : true);

        if (successId === app.id) {
          return (
            <div key={app.id} className="bg-green-50 border border-green-200 rounded-2xl p-6 flex items-center gap-4">
              <CheckCircle className="w-8 h-8 text-green-600 shrink-0" />
              <div>
                <p className="font-bold text-green-800">Documents submitted successfully!</p>
                <p className="text-sm text-green-600">We'll review your application within 24 hours.</p>
              </div>
            </div>
          );
        }

        return (
          <div key={app.id} className="bg-white border border-border-custom rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="px-6 py-4 border-b border-border-custom flex items-center justify-between">
              <div>
                <p className="font-sora font-black text-navy">
                  {app.productType === "NFC_KIT" ? "NFC Smart Kit" : "Digital IDP"} — {app.validity}yr
                </p>
                <p className="text-xs text-muted font-bold">#{app.id.slice(-8).toUpperCase()}</p>
              </div>
              <span
                className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${
                  app.status === "UNDER_REVIEW"
                    ? "bg-blue/10 text-blue"
                    : "bg-yellow-100 text-yellow-800"
                }`}
              >
                {app.status === "UNDER_REVIEW" ? "Under Review" : "Pending"}
              </span>
            </div>

            <div className="p-6 space-y-5">
              {/* Admin re-upload note */}
              {reuploadNote && (
                <div className="flex gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-black text-amber-800 uppercase tracking-wider mb-1">
                      Message from our team
                    </p>
                    <p className="text-sm text-amber-700 font-bold">{reuploadNote}</p>
                  </div>
                </div>
              )}

              {/* Partial re-upload info banner */}
              {isPartialReupload && (
                <div className="flex gap-3 bg-blue/5 border border-blue/15 rounded-xl p-4">
                  <Info className="w-5 h-5 text-blue shrink-0 mt-0.5" />
                  <p className="text-sm text-navy font-bold">
                    Our team has requested specific document(s) to be re-uploaded. Only the highlighted
                    documents below need to be replaced — the rest are already on file.
                  </p>
                </div>
              )}

              {/* Profile Photo */}
              {needsProfile ? (
                <div className="border-2 border-amber-300 rounded-2xl p-4 bg-amber-50/50 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black bg-amber-400 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Required
                    </span>
                    <span className="text-xs font-black text-navy">Profile Photo</span>
                  </div>
                  <DocumentUploader
                    label="Profile Photo"
                    fieldName="profile"
                    applicationId={app.id}
                    folder="profiles"
                    onUploadComplete={(_, key) => setUpload(app.id, "profileKey", key)}
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 border border-green-200 bg-green-50 rounded-2xl px-4 py-3">
                  <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                  <div>
                    <p className="text-xs font-black text-green-800">Profile Photo</p>
                    <p className="text-[11px] text-green-600 font-bold">Already on file — no action needed</p>
                  </div>
                </div>
              )}

              {/* License Front */}
              {needsLicense ? (
                <div className="border-2 border-amber-300 rounded-2xl p-4 bg-amber-50/50 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black bg-amber-400 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Required
                    </span>
                    <span className="text-xs font-black text-navy">Driving License (Front)</span>
                  </div>
                  <DocumentUploader
                    label="Driving License (Front)"
                    fieldName="license"
                    applicationId={app.id}
                    folder="licenses"
                    onUploadComplete={(_, key) => setUpload(app.id, "licenseKey", key)}
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 border border-green-200 bg-green-50 rounded-2xl px-4 py-3">
                  <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                  <div>
                    <p className="text-xs font-black text-green-800">Driving License (Front)</p>
                    <p className="text-[11px] text-green-600 font-bold">Already on file — no action needed</p>
                  </div>
                </div>
              )}

              {/* License Back */}
              {needsPassport ? (
                <div className="border-2 border-amber-300 rounded-2xl p-4 bg-amber-50/50 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black bg-amber-400 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Required
                    </span>
                    <span className="text-xs font-black text-navy">Driving License (Back)</span>
                  </div>
                  <DocumentUploader
                    label="Driving License (Back)"
                    fieldName="passport"
                    applicationId={app.id}
                    folder="passports"
                    onUploadComplete={(_, key) => setUpload(app.id, "passportKey", key)}
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 border border-green-200 bg-green-50 rounded-2xl px-4 py-3">
                  <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                  <div>
                    <p className="text-xs font-black text-green-800">Driving License (Back)</p>
                    <p className="text-[11px] text-green-600 font-bold">Already on file — no action needed</p>
                  </div>
                </div>
              )}

              <button
                onClick={() => handleSubmit(app)}
                disabled={!allDone || submitting === app.id}
                className="btn-primary w-full py-3 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting === app.id ? "Submitting…" : "Submit for Review →"}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
