"use client";

import { useState, useEffect } from "react";
import { Search, Save, Globe, Loader2, Check } from "lucide-react";

interface TranslationsClientProps {
  initialTranslations: any[];
}

export function TranslationsClient({ initialTranslations }: TranslationsClientProps) {
  const [lang, setLang] = useState("en");
  const [translations, setTranslations] = useState<any[]>(initialTranslations);
  const [search, setSearch] = useState("");
  const [editingValues, setEditingValues] = useState<Record<string, string>>({});
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [savedKey, setSavedKey] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch translations when language changes
  useEffect(() => {
    const fetchTranslations = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`/api/admin/translations?language=${lang}`);
        if (!response.ok) throw new Error("Failed to load");
        const data = await response.json();
        setTranslations(data);
        // Clear editing values for new language
        setEditingValues({});
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTranslations();
  }, [lang]);

  const handleValueChange = (key: string, value: string) => {
    setEditingValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async (key: string, originalValue: string) => {
    const newValue = editingValues[key] !== undefined ? editingValues[key] : originalValue;
    setSavingKey(key);

    try {
      const response = await fetch("/api/admin/translations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language: lang, key, value: newValue }),
      });

      if (!response.ok) throw new Error("Save failed");
      
      setSavedKey(key);
      setTimeout(() => setSavedKey(null), 2000);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSavingKey(null);
    }
  };

  const filtered = translations.filter((item) =>
    item.key.toLowerCase().includes(search.toLowerCase()) ||
    item.value.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-4xl text-xs font-bold text-navy">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-sora font-black text-navy text-2xl font-black">Translations CMS</h1>
          <p className="text-muted text-[10px]">Configure multi-language interface keys and localization maps.</p>
        </div>

        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue" />
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value)}
            className="border border-border-custom bg-white rounded-xl px-3 py-2 text-xs font-black text-navy outline-none focus:border-blue"
          >
            <option value="en">English (US)</option>
            <option value="es">Español (ES)</option>
            <option value="fr">Français (FR)</option>
            <option value="de">Deutsch (DE)</option>
            <option value="it">Italiano (IT)</option>
            <option value="pt">Português (PT)</option>
          </select>
        </div>
      </div>

      {/* Filter and search bar */}
      <div className="bg-white border border-border-custom rounded-3xl p-4 shadow-sm flex items-center justify-between">
        <div className="w-full relative max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
          <input
            type="text"
            placeholder="Filter translation keys or values..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-border-custom rounded-xl outline-none focus:border-blue bg-bg-custom/50 focus:bg-white transition-all font-bold"
          />
        </div>
      </div>

      {/* Translations Table */}
      <div className="bg-white border border-border-custom rounded-3xl overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-8 h-8 text-blue animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-navy text-white text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-4 w-1/3">Language Key</th>
                  <th className="px-6 py-4 w-1/2">Translated Value</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-custom text-xs">
                {filtered.map((item) => {
                  const isEditing = editingValues[item.key] !== undefined;
                  const currentValue = isEditing ? editingValues[item.key] : item.value;
                  const isSaving = savingKey === item.key;
                  const isSaved = savedKey === item.key;

                  return (
                    <tr key={item.id} className="hover:bg-bg-custom/40 transition-colors">
                      <td className="px-6 py-4 font-mono font-black text-navy">
                        {item.key}
                      </td>
                      <td className="px-6 py-4">
                        <textarea
                          rows={1}
                          value={currentValue}
                          onChange={(e) => handleValueChange(item.key, e.target.value)}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue resize-none font-bold bg-bg-custom/30 focus:bg-white"
                        />
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => handleSave(item.key, item.value)}
                          disabled={isSaving}
                          className={`p-2 border border-border-custom rounded-xl transition-all inline-flex items-center gap-1.5 ${
                            isSaved
                              ? "bg-green-500 text-white border-green-500"
                              : "bg-white hover:bg-bg-custom text-navy"
                          }`}
                        >
                          {isSaving ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : isSaved ? (
                            <Check className="w-3.5 h-3.5" />
                          ) : (
                            <Save className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={3} className="text-center py-12 text-muted font-bold">
                      No translations matches. Add keys to DB to sync.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
