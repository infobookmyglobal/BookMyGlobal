"use client";
import { WHATSAPP_URL } from "@/lib/contact";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCMS } from "@/components/CMSProvider";
import { getApiErrorMessage } from "@/lib/utils";
import {
  Save,
  Loader2,
  Check,
  Home,
  PhoneCall,
  ShieldAlert,
  Edit3,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Layers,
} from "lucide-react";

export interface CustomSection {
  id: string;
  eyebrow: string;
  title: string;
  subtitle: string;
  content: string;
  btnText: string;
  btnUrl: string;
  theme: "blue" | "dark" | "light" | "gray";
  enabled: boolean;
}

interface SiteEditClientProps {
  initialSettings: Record<string, string>;
}

export function SiteEditClient({ initialSettings }: SiteEditClientProps) {
  const router = useRouter();
  const { refetch } = useCMS();
  const [activeTab, setActiveTab] = useState<"home" | "contact" | "legal">("home");
  const [formData, setFormData] = useState<Record<string, string>>({
    // Home Section Toggles
    "site_edit:home:show_hero": initialSettings["site_edit:home:show_hero"] ?? "true",
    "site_edit:home:show_partners": initialSettings["site_edit:home:show_partners"] ?? "true",
    "site_edit:home:show_stats": initialSettings["site_edit:home:show_stats"] ?? "true",
    "site_edit:home:show_whatis": initialSettings["site_edit:home:show_whatis"] ?? "true",
    "site_edit:home:show_steps": initialSettings["site_edit:home:show_steps"] ?? "true",
    "site_edit:home:show_formats": initialSettings["site_edit:home:show_formats"] ?? "true",
    "site_edit:home:show_whyus": initialSettings["site_edit:home:show_whyus"] ?? "true",
    "site_edit:home:show_pricing": initialSettings["site_edit:home:show_pricing"] ?? "true",
    "site_edit:home:show_country": initialSettings["site_edit:home:show_country"] ?? "true",
    "site_edit:home:show_testimonials": initialSettings["site_edit:home:show_testimonials"] ?? "true",
    "site_edit:home:show_faqs": initialSettings["site_edit:home:show_faqs"] ?? "true",
    "site_edit:home:show_prefooter": initialSettings["site_edit:home:show_prefooter"] ?? "true",

    // Hero Section
    "site_edit:home:hero_eyebrow": initialSettings["site_edit:home:hero_eyebrow"] || "ONE PLATFORM. NINE WAYS TO GO PLACES",
    "site_edit:home:hero_title": initialSettings["site_edit:home:hero_title"] || "Every document. Every booking.\nOne trip, sorted.",
    "site_edit:home:hero_subtitle": initialSettings["site_edit:home:hero_subtitle"] || "From your International Driving Permit to the flight, the hotel, the visa paperwork and the people you'll meet there — BookMyGlobal handles the parts of travel that usually take eleven different tabs.",
    "site_edit:home:hero_btn_primary": initialSettings["site_edit:home:hero_btn_primary"] || "Explore services",
    "site_edit:home:hero_btn_secondary": initialSettings["site_edit:home:hero_btn_secondary"] || "See yoga retreats",
    "site_edit:home:hero_btn_partner": initialSettings["site_edit:home:hero_btn_partner"] || "Apply as Partner 🤝",
    "site_edit:home:trust_badge_1": initialSettings["site_edit:home:trust_badge_1"] || "✓ Instant Digital Delivery",
    "site_edit:home:trust_badge_2": initialSettings["site_edit:home:trust_badge_2"] || "🛡️ 100% Money-Back Guarantee",
    "site_edit:home:trust_badge_3": initialSettings["site_edit:home:trust_badge_3"] || "🔒 Secure Application",
    "site_edit:home:trust_badge_4": initialSettings["site_edit:home:trust_badge_4"] || "💬 24/7 WhatsApp Support",
    "site_edit:home:hero_warning_text": initialSettings["site_edit:home:hero_warning_text"] || "The IDP is a supplementary translation document and must be carried alongside your valid domestic driving license at all times.",

    // Rental Partners Band
    "site_edit:home:partners_header": initialSettings["site_edit:home:partners_header"] || "INTERNATIONAL DRIVING PERMIT ACCEPTED AT ALL MAJOR CAR RENTAL COMPANIES WORLDWIDE",
    "site_edit:home:partner_1": initialSettings["site_edit:home:partner_1"] || "Enterprise",
    "site_edit:home:partner_2": initialSettings["site_edit:home:partner_2"] || "HERTZ",
    "site_edit:home:partner_3": initialSettings["site_edit:home:partner_3"] || "Avis",
    "site_edit:home:partner_4": initialSettings["site_edit:home:partner_4"] || "Budget",
    "site_edit:home:partner_5": initialSettings["site_edit:home:partner_5"] || "SIXT",
    "site_edit:home:partner_6": initialSettings["site_edit:home:partner_6"] || "Europcar",

    // Core Statistics Banner
    "site_edit:home:stat_1_num": initialSettings["site_edit:home:stat_1_num"] || "9",
    "site_edit:home:stat_1_label": initialSettings["site_edit:home:stat_1_label"] || "services in one place",
    "site_edit:home:stat_2_num": initialSettings["site_edit:home:stat_2_num"] || "189+",
    "site_edit:home:stat_2_label": initialSettings["site_edit:home:stat_2_label"] || "countries an IDP covers",
    "site_edit:home:stat_3_num": initialSettings["site_edit:home:stat_3_num"] || "1",
    "site_edit:home:stat_3_label": initialSettings["site_edit:home:stat_3_label"] || "login for the whole trip",
    "site_edit:home:stat_4_num": initialSettings["site_edit:home:stat_4_num"] || "3yr",
    "site_edit:home:stat_4_label": initialSettings["site_edit:home:stat_4_label"] || "Maximum IDP Validity",

    // What is an IDP
    "site_edit:home:whatis_title1": initialSettings["site_edit:home:whatis_title1"] || "What is an ",
    "site_edit:home:whatis_title2": initialSettings["site_edit:home:whatis_title2"] || "International Driving Permit (IDP)?",
    "site_edit:home:whatis_p1": initialSettings["site_edit:home:whatis_p1"] || "An International Driving Permit (IDP) is a standardised multilingual translation document that presents the information from your existing domestic driving authorisation in multiple languages. When you travel abroad, car rental companies and road authorities can understand your entitlement to drive without needing to read your home country's script or language.",
    "site_edit:home:whatis_p2": initialSettings["site_edit:home:whatis_p2"] || "The IDP does not replace your domestic driving authorisation. Both documents must be carried together at all times when driving abroad. Together, they allow you to legally drive and rent vehicles in 189+ countries worldwide.",
    "site_edit:home:whatis_card1_title": initialSettings["site_edit:home:whatis_card1_title"] || "Why Rental Agencies Need It:",
    "site_edit:home:whatis_card1_desc": initialSettings["site_edit:home:whatis_card1_desc"] || "All major international car rental companies — including Hertz, Avis, Enterprise, SIXT and Budget — require an IDP for foreign drivers. Without one, your rental may be refused at the counter even with a confirmed booking.",
    "site_edit:home:whatis_card2_title": initialSettings["site_edit:home:whatis_card2_title"] || "Where It's Recognised:",
    "site_edit:home:whatis_card2_desc": initialSettings["site_edit:home:whatis_card2_desc"] || "Our IDP is recognised by rental agencies and road authorities in 189+ countries including UAE, Thailand, USA, UK, Germany, Australia, Malaysia, Indonesia, and across Europe and Southeast Asia.",
    "site_edit:home:whatis_card3_title": initialSettings["site_edit:home:whatis_card3_title"] || "How Fast You Receive It:",
    "site_edit:home:whatis_card3_desc": initialSettings["site_edit:home:whatis_card3_desc"] || "Your Digital IDP arrives by email within 2–4 hours. The physical NFC Smart Kit digital copy is sent instantly, with the physical booklet and card dispatched within 7–15 working days by courier.",
    "site_edit:home:whatis_card4_title": initialSettings["site_edit:home:whatis_card4_title"] || "Guaranteed or Refunded:",
    "site_edit:home:whatis_card4_desc": initialSettings["site_edit:home:whatis_card4_desc"] || "We offer a 100% money-back guarantee. If your International Driving Permit is not accepted at any car rental agency or road authority anywhere in the world, you may be eligible for a refund. Please review our Terms & Conditions and Refund Policy carefully, or contact our support team for assistance regarding your refund request..",

    // 3-Step Process
    "site_edit:home:steps_eyebrow": initialSettings["site_edit:home:steps_eyebrow"] || "HOW IT WORKS",
    "site_edit:home:steps_title": initialSettings["site_edit:home:steps_title"] || "Four steps, start to landing",
    "site_edit:home:steps_subtitle": initialSettings["site_edit:home:steps_subtitle"] || "Whether it's an IDP or a full trip with flights, hotels, and a yoga retreat — the process stays the same.",
    "site_edit:home:step1_title": initialSettings["site_edit:home:step1_title"] || "Pick what you need",
    "site_edit:home:step1_desc": initialSettings["site_edit:home:step1_desc"] || "Choose a service — an IDP, a flight, a visa, a retreat — and tell us what you're after.",
    "site_edit:home:step2_title": initialSettings["site_edit:home:step2_title"] || "Fill in the details",
    "site_edit:home:step2_desc": initialSettings["site_edit:home:step2_desc"] || "Share your trip and traveller details once. Upload documents securely where required.",
    "site_edit:home:step3_title": initialSettings["site_edit:home:step3_title"] || "Pay and confirm",
    "site_edit:home:step3_desc": initialSettings["site_edit:home:step3_desc"] || "Secure checkout in INR or local currency, with an instant confirmation.",

    // Format Options
    "site_edit:home:format_eyebrow": initialSettings["site_edit:home:format_eyebrow"] || "IDP FORMAT OPTIONS",
    "site_edit:home:format_title": initialSettings["site_edit:home:format_title"] || "Choose Your International Driving Permit Format",
    "site_edit:home:format_subtitle": initialSettings["site_edit:home:format_subtitle"] || "Select the documentation plan that best fits your travel needs. Stretched validity available.",
    "site_edit:home:format_opt1_badge": initialSettings["site_edit:home:format_opt1_badge"] || "⭐ RECOMMENDED FOR BALI, THAILAND, UAE",
    "site_edit:home:format_opt1_title": initialSettings["site_edit:home:format_opt1_title"] || "NFC Smart Kit",
    "site_edit:home:format_opt1_sub": initialSettings["site_edit:home:format_opt1_sub"] || "Physical Booklet + NFC Card + Digital IDP",
    "site_edit:home:format_opt1_btn": initialSettings["site_edit:home:format_opt1_btn"] || "Apply for NFC Smart Kit →",
    "site_edit:home:format_opt2_title": initialSettings["site_edit:home:format_opt2_title"] || "Digital IDP Only",
    "site_edit:home:format_opt2_sub": initialSettings["site_edit:home:format_opt2_sub"] || "PDF Booklet + English Identity Card",
    "site_edit:home:format_opt2_btn": initialSettings["site_edit:home:format_opt2_btn"] || "Apply for Digital IDP →",

    // Why Choose Us
    "site_edit:home:why_eyebrow": initialSettings["site_edit:home:why_eyebrow"] || "WHY CHOOSE US",
    "site_edit:home:why_heading": initialSettings["site_edit:home:why_heading"] || "Why Travellers Trust BookMyGlobal",
    "site_edit:home:why_subtitle": initialSettings["site_edit:home:why_subtitle"] || "We specialise exclusively in International Driving Permits — delivering the fastest, most reliable IDP assistance services for travelers globally.",
    "site_edit:home:benefit_1_title": initialSettings["site_edit:home:benefit_1_title"] || "Fast IDP Delivery",
    "site_edit:home:benefit_1_desc": initialSettings["site_edit:home:benefit_1_desc"] || "Our streamlined digital system ensures your application is processed and approved in under 2 hours, with digital delivery straight to your inbox.",
    "site_edit:home:benefit_2_title": initialSettings["site_edit:home:benefit_2_title"] || "189+ Countries Recognised",
    "site_edit:home:benefit_2_desc": initialSettings["site_edit:home:benefit_2_desc"] || "Fully compliant with the 1949 and 1968 international road traffic conventions, ensuring wide acceptance across all major destinations.",
    "site_edit:home:benefit_3_title": initialSettings["site_edit:home:benefit_3_title"] || "NFC & QR Verification",
    "site_edit:home:benefit_3_desc": initialSettings["site_edit:home:benefit_3_desc"] || "Every physical smart card includes a live NFC chip and secure QR code, enabling instant translation and verification by road authorities.",
    "site_edit:home:benefit_4_title": initialSettings["site_edit:home:benefit_4_title"] || "100% Money-Back Guarantee",
    "site_edit:home:benefit_4_desc": initialSettings["site_edit:home:benefit_4_desc"] || "We stand behind our service. If your permit is refused at an international car rental counter, we issue a full refund immediately.",
    "site_edit:home:benefit_5_title": initialSettings["site_edit:home:benefit_5_title"] || "24/7 WhatsApp Support",
    "site_edit:home:benefit_5_desc": initialSettings["site_edit:home:benefit_5_desc"] || "Our global customer support team is available day and night to assist you with application queries, updates, and general guidance.",
    "site_edit:home:benefit_6_title": initialSettings["site_edit:home:benefit_6_title"] || "Secure & Encrypted",
    "site_edit:home:benefit_6_desc": initialSettings["site_edit:home:benefit_6_desc"] || "Your data security is our top priority. We use bank-grade 256-bit encryption to protect your personal details and document uploads.",

    // Pricing Matrix
    "site_edit:home:pricing_eyebrow": initialSettings["site_edit:home:pricing_eyebrow"] || "NO HIDDEN FEES",
    "site_edit:home:pricing_title": initialSettings["site_edit:home:pricing_title"] || "Simple, Transparent IDP Pricing",
    "site_edit:home:pricing_subtitle": initialSettings["site_edit:home:pricing_subtitle"] || "One-time payment. No hidden subscription charges. 100% money-back guarantee included.",
    "site_edit:home:pricing_btn": initialSettings["site_edit:home:pricing_btn"] || "Apply for Your IDP Now →",

    // Country Guide
    "site_edit:home:country_eyebrow": initialSettings["site_edit:home:country_eyebrow"] || "DESTINATION GUIDE",
    "site_edit:home:country_title": initialSettings["site_edit:home:country_title"] || "Where Your IDP is Recognised",
    "site_edit:home:country_subtitle": initialSettings["site_edit:home:country_subtitle"] || "Your International Driving Permit is recognised in over 189 countries. Here are the most popular travel destinations for BookMyGlobal travellers.",
    "site_edit:home:country_btn": initialSettings["site_edit:home:country_btn"] || "View All 189+ Countries",

    // Testimonials
    "site_edit:home:testi_eyebrow": initialSettings["site_edit:home:testi_eyebrow"] || "TESTIMONIALS",
    "site_edit:home:testi_title": initialSettings["site_edit:home:testi_title"] || "What Travellers Say About Our IDP",
    "site_edit:home:testi_subtitle": initialSettings["site_edit:home:testi_subtitle"] || "Real reviews from smart travellers driving legally abroad with BookMyGlobal.",
    "site_edit:home:testi_google_link": initialSettings["site_edit:home:testi_google_link"] || "https://g.page/r/CcKIkRHxvbGiEAE/review",
    "site_edit:home:testi_1_name": initialSettings["site_edit:home:testi_1_name"] || "Sarah Jenkins",
    "site_edit:home:testi_1_dest": initialSettings["site_edit:home:testi_1_dest"] || "Travelled to Thailand",
    "site_edit:home:testi_1_text": initialSettings["site_edit:home:testi_1_text"] || "I was super stressed about renting a scooter in Phuket after hearing about police checkpoints. I applied on BookMyGlobal and got my digital permit in under 45 minutes! The WhatsApp support was incredibly quick to answer my questions.",
    "site_edit:home:testi_2_name": initialSettings["site_edit:home:testi_2_name"] || "Marcus Alvarez",
    "site_edit:home:testi_2_dest": initialSettings["site_edit:home:testi_2_dest"] || "Travelled to Spain & Italy",
    "site_edit:home:testi_2_text": initialSettings["site_edit:home:testi_2_text"] || "The Hertz desk in Madrid insisted on seeing an IDP. I didn't have one, but I applied right at the terminal on my phone. Received the digital PDF in an hour, showed it to the agent, and walked out with the keys. Lifesavers!",

    // FAQs Header
    "site_edit:home:faq_eyebrow": initialSettings["site_edit:home:faq_eyebrow"] || "GOT QUESTIONS?",
    "site_edit:home:faq_title": initialSettings["site_edit:home:faq_title"] || "Frequently asked questions",
    "site_edit:home:faq_subtitle": initialSettings["site_edit:home:faq_subtitle"] || "Quick answers about our services, attestation, retreats and community.",

    // Pre-Footer CTA Banner
    "site_edit:home:cta_title": initialSettings["site_edit:home:cta_title"] || "We're building the trip-planning tab you won't have to close",
    "site_edit:home:cta_subtitle": initialSettings["site_edit:home:cta_subtitle"] || "Tell us where you're headed and we'll help with the documents and bookings.",
    "site_edit:home:cta_btn": initialSettings["site_edit:home:cta_btn"] || "Get in touch →",

    // Contact Defaults
    "site_edit:contact:hero_eyebrow": initialSettings["site_edit:contact:hero_eyebrow"] || "24/7 Global Support — We're Always Here",
    "site_edit:contact:hero_title": initialSettings["site_edit:contact:hero_title"] || "Contact BookMyGlobal",
    "site_edit:contact:hero_subtitle": initialSettings["site_edit:contact:hero_subtitle"] || "Questions about your IDP, application status, or documentation? Our team responds within 2 hours, every day of the week.",
    "site_edit:contact:call_title": initialSettings["site_edit:contact:call_title"] || "Call Us",
    "site_edit:contact:call_phone": initialSettings["site_edit:contact:call_phone"] || "+66 93 453 1077",
    "site_edit:contact:call_hours": initialSettings["site_edit:contact:call_hours"] || "Mon–Sun · 9 AM – 9 PM ICT",
    "site_edit:contact:email_title": initialSettings["site_edit:contact:email_title"] || "Email Us",
    "site_edit:contact:email_address": initialSettings["site_edit:contact:email_address"] || "info@bookmyglobal.com",
    "site_edit:contact:email_desc": initialSettings["site_edit:contact:email_desc"] || "Response within 2 business hours",
    "site_edit:contact:form_title": initialSettings["site_edit:contact:form_title"] || "Send Us a Message",
    "site_edit:contact:form_subtitle": initialSettings["site_edit:contact:form_subtitle"] || "Fill in the details below and our team will get back to you promptly. All enquiries are fully confidential.",
    "site_edit:contact:address_title": initialSettings["site_edit:contact:address_title"] || "Official Address",
    "site_edit:contact:address_value": initialSettings["site_edit:contact:address_value"] || "BookMyGlobal\n120 Moo 3 Chaengwattana Road\nLak Si, Bangkok 10210, Thailand",

    "site_edit:contact:whatsapp_title": initialSettings["site_edit:contact:whatsapp_title"] || "Instant WhatsApp Support",
    "site_edit:contact:whatsapp_desc": initialSettings["site_edit:contact:whatsapp_desc"] || "Get real-time help with your IDP application — fastest way to reach our support team.",
    "site_edit:contact:whatsapp_phone": initialSettings["site_edit:contact:whatsapp_phone"] || "+66 934 531 077",
    "site_edit:contact:whatsapp_url": initialSettings["site_edit:contact:whatsapp_url"] || WHATSAPP_URL,

    "site_edit:contact:hours_title": initialSettings["site_edit:contact:hours_title"] || "Support Hours",
    "site_edit:contact:hours_weekday": initialSettings["site_edit:contact:hours_weekday"] || "9 AM – 9 PM",
    "site_edit:contact:hours_weekday_badge": initialSettings["site_edit:contact:hours_weekday_badge"] || "OPEN",
    "site_edit:contact:hours_saturday": initialSettings["site_edit:contact:hours_saturday"] || "10 AM – 6 PM",
    "site_edit:contact:hours_sunday": initialSettings["site_edit:contact:hours_sunday"] || "10 AM – 4 PM",
    "site_edit:contact:hours_whatsapp": initialSettings["site_edit:contact:hours_whatsapp"] || "24 / 7",
    "site_edit:contact:hours_whatsapp_badge": initialSettings["site_edit:contact:hours_whatsapp_badge"] || "ALWAYS",
    "site_edit:contact:hours_timezone": initialSettings["site_edit:contact:hours_timezone"] || "All times in ICT",

    "site_edit:contact:social_facebook": initialSettings["site_edit:contact:social_facebook"] || "https://www.facebook.com/share/1FTZ2V9vnJ/",
    "site_edit:contact:social_instagram": initialSettings["site_edit:contact:social_instagram"] || "https://www.instagram.com/theofficial_idp",
    "site_edit:contact:social_email": initialSettings["site_edit:contact:social_email"] || "info@bookmyglobal.com",

    "site_edit:contact:stat_1_val": initialSettings["site_edit:contact:stat_1_val"] || "150+",
    "site_edit:contact:stat_1_lbl": initialSettings["site_edit:contact:stat_1_lbl"] || "Countries Accepted",
    "site_edit:contact:stat_2_val": initialSettings["site_edit:contact:stat_2_val"] || "50K+",
    "site_edit:contact:stat_2_lbl": initialSettings["site_edit:contact:stat_2_lbl"] || "IDPs Issued",
    "site_edit:contact:stat_3_val": initialSettings["site_edit:contact:stat_3_val"] || "<2 hrs",
    "site_edit:contact:stat_3_lbl": initialSettings["site_edit:contact:stat_3_lbl"] || "Avg Response Time",
    "site_edit:contact:stat_4_val": initialSettings["site_edit:contact:stat_4_val"] || "24/7",
    "site_edit:contact:stat_4_lbl": initialSettings["site_edit:contact:stat_4_lbl"] || "WhatsApp Support",

    "site_edit:contact:trust_title": initialSettings["site_edit:contact:trust_title"] || "100% Money-Back Guarantee",
    "site_edit:contact:trust_desc": initialSettings["site_edit:contact:trust_desc"] || "If your IDP is not accepted anywhere in the world, we issue a full refund — no questions asked. Trusted by 50,000+ international drivers.",
    "site_edit:contact:trust_cta_text": initialSettings["site_edit:contact:trust_cta_text"] || "Apply for Your IDP →",
    "site_edit:contact:trust_cta_url": initialSettings["site_edit:contact:trust_cta_url"] || "https://bookmyglobal.com/driver-license-app/",

    // Legal Defaults
    "site_edit:legal:refunds_intro": initialSettings["site_edit:legal:refunds_intro"] || "Everything in one place — BookMyGlobal's complete policy framework for International Driving Permit services.",
    "site_edit:legal:privacy_intro": initialSettings["site_edit:legal:privacy_intro"] || "We value your privacy and security. This policy outlines how we handle and protect your personal information.",
    "site_edit:legal:disclaimer_intro": initialSettings["site_edit:legal:disclaimer_intro"] || "Important notice about the legal standing, scope, and use cases of the documentation provided by BookMyGlobal.",
    "site_edit:legal:terms_intro": initialSettings["site_edit:legal:terms_intro"] || "Please read these Terms & Conditions carefully before using our platform or ordering an IDP.",
  });

  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const [customSections, setCustomSections] = useState<CustomSection[]>(() => {
    try {
      const raw = initialSettings["site_edit:home:custom_sections"] || "[]";
      return JSON.parse(raw);
    } catch {
      return [];
    }
  });

  const handleCustomSectionsChange = (updated: CustomSection[]) => {
    setCustomSections(updated);
    setFormData((prev) => ({
      ...prev,
      "site_edit:home:custom_sections": JSON.stringify(updated),
    }));
    setSuccess(false);
    setError("");
  };

  const addCustomSection = () => {
    const newSec: CustomSection = {
      id: "sec_" + Date.now(),
      eyebrow: "NEW FEATURE",
      title: "New Custom Section Title",
      subtitle: "Custom subtitle describing this section and its purpose.",
      content: "Add detailed body text, explanations, or service information for your new section here.",
      btnText: "Apply Now →",
      btnUrl: "/apply",
      theme: "light",
      enabled: true,
    };
    handleCustomSectionsChange([...customSections, newSec]);
  };

  const updateSectionField = (id: string, field: keyof CustomSection, val: any) => {
    const updated = customSections.map((sec) =>
      sec.id === id ? { ...sec, [field]: val } : sec
    );
    handleCustomSectionsChange(updated);
  };

  const removeCustomSection = (id: string) => {
    const updated = customSections.filter((sec) => sec.id !== id);
    handleCustomSectionsChange(updated);
  };

  const moveCustomSection = (index: number, direction: "up" | "down") => {
    const targetIdx = direction === "up" ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= customSections.length) return;
    const updated = [...customSections];
    const temp = updated[index];
    updated[index] = updated[targetIdx];
    updated[targetIdx] = temp;
    handleCustomSectionsChange(updated);
  };

  const handleChange = (key: string, val: string) => {
    setFormData((prev) => ({
      ...prev,
      [key]: val,
    }));
    setSuccess(false);
    setError("");
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError("");
      setSuccess(false);

      const payload = Object.entries(formData)
        .filter(([key, value]) => initialSettings[key] !== value)
        .map(([key, value]) => ({ key, value }));

      if (payload.length === 0) {
        setSuccess(true);
        return;
      }

      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorMsg = await getApiErrorMessage(res);
        throw new Error(errorMsg);
      }

      setSuccess(true);
      await refetch();
      router.refresh();
    } catch (e: any) {
      console.error(e);
      setError(e.message || "Failed to update CMS settings");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-sora font-black text-navy text-2xl flex items-center gap-2">
            <Edit3 className="w-6 h-6 text-blue" />
            CMS Site Edit
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            Modify texts, badges, benefits, and support coordinates visible across the live site.
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-blue text-white text-xs font-semibold rounded-xl hover:bg-blue-600 disabled:bg-slate-300 transition-all shadow-md shadow-blue/10"
        >
          {saving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : success ? (
            <Check className="w-4 h-4 text-green-300" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          {saving ? "Saving Changes..." : success ? "Saved Successfully!" : "Save CMS Settings"}
        </button>
      </div>

      {/* Messages */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-semibold">
          {error}
        </div>
      )}
      {success && (
        <div className="p-4 bg-green-50 border border-green-200 text-green-700 text-xs rounded-xl font-semibold">
          CMS settings saved successfully and live content updated!
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-1 bg-slate-50 p-1.5 rounded-2xl w-fit">
        <button
          onClick={() => setActiveTab("home")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === "home"
              ? "bg-white text-blue shadow-sm"
              : "text-slate-500 hover:text-navy hover:bg-white/50"
          }`}
        >
          <Home className="w-4 h-4" />
          Home Page
        </button>
        <button
          onClick={() => setActiveTab("contact")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === "contact"
              ? "bg-white text-blue shadow-sm"
              : "text-slate-500 hover:text-navy hover:bg-white/50"
          }`}
        >
          <PhoneCall className="w-4 h-4" />
          Contact Page
        </button>
        <button
          onClick={() => setActiveTab("legal")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === "legal"
              ? "bg-white text-blue shadow-sm"
              : "text-slate-500 hover:text-navy hover:bg-white/50"
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          Legal Policies
        </button>
      </div>

      {/* Forms Container */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
        {activeTab === "home" && (
          <div className="space-y-8">
            <div className="bg-blue/5 border border-blue/20 rounded-2xl p-4 text-xs text-navy font-medium">
              <strong className="font-sora font-black block text-sm mb-0.5">Full Home Page Template Editor</strong>
              Configure all text, titles, subtitles, card fields, and section show/hide visibility toggles across the entire home page.
            </div>

            {/* 1. Hero Banner */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">1. Hero Banner Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_hero"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_hero", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Hero Eyebrow (Badge)</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:hero_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Hero Main Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_title"]}
                    onChange={(e) => handleChange("site_edit:home:hero_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Hero Subtitle</label>
                  <textarea
                    rows={3}
                    value={formData["site_edit:home:hero_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:hero_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Primary Button Label</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_btn_primary"] || ""}
                    onChange={(e) => handleChange("site_edit:home:hero_btn_primary", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Secondary Button Label</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_btn_secondary"] || ""}
                    onChange={(e) => handleChange("site_edit:home:hero_btn_secondary", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Partner Button Label</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_btn_partner"] || ""}
                    onChange={(e) => handleChange("site_edit:home:hero_btn_partner", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>

                {/* Trust Badges */}
                {[1, 2, 3, 4].map((num) => (
                  <div key={num} className="flex flex-col gap-1">
                    <label className="text-[11px] font-bold text-slate-400">Trust Badge {num}</label>
                    <input
                      type="text"
                      value={formData[`site_edit:home:trust_badge_${num}`] || ""}
                      onChange={(e) => handleChange(`site_edit:home:trust_badge_${num}`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                    />
                  </div>
                ))}

                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Warning Banner Text</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:hero_warning_text"] || ""}
                    onChange={(e) => handleChange("site_edit:home:hero_warning_text", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 2. Rental Partners Band */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">2. Rental Partners Logo Band</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_partners"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_partners", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Partners Header Text</label>
                <input
                  type="text"
                  value={formData["site_edit:home:partners_header"]}
                  onChange={(e) => handleChange("site_edit:home:partners_header", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6].map((num) => (
                  <div key={num} className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-400">Partner {num} Name</label>
                    <input
                      type="text"
                      value={formData[`site_edit:home:partner_${num}`] || ""}
                      onChange={(e) => handleChange(`site_edit:home:partner_${num}`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold bg-white outline-none focus:border-blue"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Core Statistics Banner */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">3. Core Statistics Banner</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_stats"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_stats", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((num) => (
                  <div key={num} className="border border-slate-200 p-3 rounded-xl bg-white space-y-2">
                    <label className="text-[10px] font-black text-blue uppercase">Stat {num}</label>
                    <input
                      type="text"
                      placeholder="Number (e.g. 189+)"
                      value={formData[`site_edit:home:stat_${num}_num`]}
                      onChange={(e) => handleChange(`site_edit:home:stat_${num}_num`, e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                    />
                    <input
                      type="text"
                      placeholder="Label (e.g. Countries)"
                      value={formData[`site_edit:home:stat_${num}_label`]}
                      onChange={(e) => handleChange(`site_edit:home:stat_${num}_label`, e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 4. What is an IDP Section */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">4. &quot;What is an IDP?&quot; Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_whatis"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_whatis", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Title Part 1</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:whatis_title1"]}
                    onChange={(e) => handleChange("site_edit:home:whatis_title1", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Title Part 2</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:whatis_title2"]}
                    onChange={(e) => handleChange("site_edit:home:whatis_title2", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Paragraph 1</label>
                  <textarea
                    rows={3}
                    value={formData["site_edit:home:whatis_p1"]}
                    onChange={(e) => handleChange("site_edit:home:whatis_p1", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Paragraph 2</label>
                  <textarea
                    rows={3}
                    value={formData["site_edit:home:whatis_p2"]}
                    onChange={(e) => handleChange("site_edit:home:whatis_p2", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>

                {[1, 2, 3, 4].map((num) => (
                  <div key={num} className="border border-slate-200 p-4 rounded-xl bg-white space-y-2">
                    <label className="text-xs font-black text-blue">Card {num} Details</label>
                    <input
                      type="text"
                      placeholder="Card Title"
                      value={formData[`site_edit:home:whatis_card${num}_title`]}
                      onChange={(e) => handleChange(`site_edit:home:whatis_card${num}_title`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                    />
                    <textarea
                      rows={3}
                      placeholder="Card Description"
                      value={formData[`site_edit:home:whatis_card${num}_desc`]}
                      onChange={(e) => handleChange(`site_edit:home:whatis_card${num}_desc`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue resize-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 5. 3-Step Process */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">5. 3-Step Process Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_steps"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_steps", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:steps_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:steps_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:steps_title"]}
                    onChange={(e) => handleChange("site_edit:home:steps_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <textarea
                    rows={2}
                    value={formData["site_edit:home:steps_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:steps_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>

                {[1, 2, 3].map((num) => (
                  <div key={num} className="border border-slate-200 p-4 rounded-xl bg-white space-y-2">
                    <label className="text-xs font-black text-blue">Step {num} Content</label>
                    <input
                      type="text"
                      placeholder="Step Title"
                      value={formData[`site_edit:home:step${num}_title`]}
                      onChange={(e) => handleChange(`site_edit:home:step${num}_title`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                    />
                    <textarea
                      rows={3}
                      placeholder="Step Description"
                      value={formData[`site_edit:home:step${num}_desc`]}
                      onChange={(e) => handleChange(`site_edit:home:step${num}_desc`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue resize-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 6. IDP Format Options */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">6. IDP Format Options Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_formats"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_formats", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:format_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:format_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:format_title"]}
                    onChange={(e) => handleChange("site_edit:home:format_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <textarea
                    rows={2}
                    value={formData["site_edit:home:format_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:format_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>

                <div className="border border-slate-200 p-4 rounded-xl bg-white space-y-2">
                  <label className="text-xs font-black text-blue">Option 1: NFC Smart Kit</label>
                  <input
                    type="text"
                    placeholder="Badge (e.g. ⭐ RECOMMENDED)"
                    value={formData["site_edit:home:format_opt1_badge"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt1_badge", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                  />
                  <input
                    type="text"
                    placeholder="Option Title"
                    value={formData["site_edit:home:format_opt1_title"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt1_title", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                  />
                  <input
                    type="text"
                    placeholder="Button Label"
                    value={formData["site_edit:home:format_opt1_btn"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt1_btn", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                  />
                </div>

                <div className="border border-slate-200 p-4 rounded-xl bg-white space-y-2">
                  <label className="text-xs font-black text-blue">Option 2: Digital IDP Only</label>
                  <input
                    type="text"
                    placeholder="Option Title"
                    value={formData["site_edit:home:format_opt2_title"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt2_title", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                  />
                  <input
                    type="text"
                    placeholder="Option Subtitle"
                    value={formData["site_edit:home:format_opt2_sub"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt2_sub", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue"
                  />
                  <input
                    type="text"
                    placeholder="Button Label"
                    value={formData["site_edit:home:format_opt2_btn"]}
                    onChange={(e) => handleChange("site_edit:home:format_opt2_btn", e.target.value)}
                    className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                  />
                </div>
              </div>
            </div>

            {/* 7. Why Choose Us */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">7. Why Choose Us Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_whyus"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_whyus", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:why_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:why_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Heading</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:why_heading"] || ""}
                    onChange={(e) => handleChange("site_edit:home:why_heading", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <textarea
                    rows={2}
                    value={formData["site_edit:home:why_subtitle"] || ""}
                    onChange={(e) => handleChange("site_edit:home:why_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>

                {[1, 2, 3, 4, 5, 6].map((num) => (
                  <div key={num} className="flex flex-col gap-1.5 border border-slate-200 p-4 rounded-xl bg-white">
                    <label className="text-xs font-black text-blue">Benefit {num}</label>
                    <input
                      type="text"
                      placeholder="Title"
                      value={formData[`site_edit:home:benefit_${num}_title`]}
                      onChange={(e) => handleChange(`site_edit:home:benefit_${num}_title`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold outline-none focus:border-blue"
                    />
                    <textarea
                      rows={2}
                      placeholder="Description"
                      value={formData[`site_edit:home:benefit_${num}_desc`]}
                      onChange={(e) => handleChange(`site_edit:home:benefit_${num}_desc`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium outline-none focus:border-blue resize-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 8. Pricing Matrix */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">8. Pricing Matrix Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_pricing"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_pricing", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:pricing_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:pricing_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:pricing_title"]}
                    onChange={(e) => handleChange("site_edit:home:pricing_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:pricing_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:pricing_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">CTA Button Label</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:pricing_btn"]}
                    onChange={(e) => handleChange("site_edit:home:pricing_btn", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 9. Destination Guide */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">9. Destination Guide Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_country"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_country", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:country_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:country_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:country_title"]}
                    onChange={(e) => handleChange("site_edit:home:country_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:country_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:country_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Bottom Link Button Text</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:country_btn"]}
                    onChange={(e) => handleChange("site_edit:home:country_btn", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 10. Testimonials */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">10. Testimonials Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_testimonials"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_testimonials", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:testi_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:testi_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:testi_title"]}
                    onChange={(e) => handleChange("site_edit:home:testi_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Google Review URL</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:testi_google_link"]}
                    onChange={(e) => handleChange("site_edit:home:testi_google_link", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                    placeholder="https://g.page/r/.../review"
                  />
                </div>

                {[1, 2].map((num) => (
                  <div key={num} className="border border-slate-200 p-4 rounded-xl bg-white space-y-2">
                    <label className="text-xs font-black text-blue">Testimonial {num}</label>
                    <input
                      type="text"
                      placeholder="Author Name"
                      value={formData[`site_edit:home:testi_${num}_name`]}
                      onChange={(e) => handleChange(`site_edit:home:testi_${num}_name`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-bold w-full outline-none focus:border-blue"
                    />
                    <input
                      type="text"
                      placeholder="Location / Destination"
                      value={formData[`site_edit:home:testi_${num}_dest`]}
                      onChange={(e) => handleChange(`site_edit:home:testi_${num}_dest`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue"
                    />
                    <textarea
                      rows={3}
                      placeholder="Review Text"
                      value={formData[`site_edit:home:testi_${num}_text`]}
                      onChange={(e) => handleChange(`site_edit:home:testi_${num}_text`, e.target.value)}
                      className="p-2.5 border border-slate-200 rounded-lg text-xs font-medium w-full outline-none focus:border-blue resize-none"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 11. FAQs Header */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">11. FAQs Header Section</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_faqs"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_faqs", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Eyebrow</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:faq_eyebrow"]}
                    onChange={(e) => handleChange("site_edit:home:faq_eyebrow", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">Section Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:faq_title"]}
                    onChange={(e) => handleChange("site_edit:home:faq_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">Section Subtitle</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:faq_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:faq_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 12. Pre-Footer CTA */}
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/40">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <h3 className="font-sora font-black text-navy text-sm">12. Pre-Footer CTA Banner</h3>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData["site_edit:home:show_prefooter"] !== "false"}
                    onChange={(e) => handleChange("site_edit:home:show_prefooter", e.target.checked ? "true" : "false")}
                    className="w-4 h-4 accent-blue rounded"
                  />
                  Show Section
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">CTA Title</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:cta_title"]}
                    onChange={(e) => handleChange("site_edit:home:cta_title", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-xs font-bold text-slate-500">CTA Subtitle</label>
                  <textarea
                    rows={2}
                    value={formData["site_edit:home:cta_subtitle"]}
                    onChange={(e) => handleChange("site_edit:home:cta_subtitle", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white resize-none"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-500">CTA Button Label</label>
                  <input
                    type="text"
                    value={formData["site_edit:home:cta_btn"]}
                    onChange={(e) => handleChange("site_edit:home:cta_btn", e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue bg-white"
                  />
                </div>
              </div>
            </div>

            {/* 13. Custom Dynamic Sections */}
            <div className="border-2 border-blue/30 rounded-2xl p-6 space-y-6 bg-blue/5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-blue/20 pb-4">
                <div>
                  <h3 className="font-sora font-black text-navy text-base flex items-center gap-2">
                    <Layers className="w-5 h-5 text-blue" />
                    13. Custom Dynamic Sections
                  </h3>
                  <p className="text-slate-500 text-xs mt-0.5">
                    Add new custom sections to your home page dynamically. You can create as many new sections as you need.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={addCustomSection}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-blue text-white text-xs font-black rounded-xl hover:bg-blue-600 transition-all shadow-sm shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  + Add New Section
                </button>
              </div>

              {customSections.length === 0 ? (
                <div className="text-center py-8 bg-white/60 rounded-xl border border-dashed border-slate-300">
                  <p className="text-xs text-slate-500 font-medium">No custom sections added yet.</p>
                  <button
                    type="button"
                    onClick={addCustomSection}
                    className="mt-3 text-xs font-bold text-blue hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Click here to add your first custom section
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {customSections.map((sec, idx) => (
                    <div
                      key={sec.id}
                      className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4 relative"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-full bg-blue/10 text-blue font-sora text-xs font-black flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span className="font-sora font-bold text-xs text-navy">
                            {sec.title || `Custom Section ${idx + 1}`}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <label className="flex items-center gap-1.5 text-xs font-bold text-slate-600 cursor-pointer mr-2">
                            <input
                              type="checkbox"
                              checked={sec.enabled !== false}
                              onChange={(e) => updateSectionField(sec.id, "enabled", e.target.checked)}
                              className="w-4 h-4 accent-blue rounded"
                            />
                            Active
                          </label>

                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => moveCustomSection(idx, "up")}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === customSections.length - 1}
                            onClick={() => moveCustomSection(idx, "down")}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => removeCustomSection(sec.id)}
                            className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 cursor-pointer"
                            title="Delete Section"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[11px] font-bold text-slate-500">Eyebrow / Badge Text</label>
                          <input
                            type="text"
                            value={sec.eyebrow}
                            onChange={(e) => updateSectionField(sec.id, "eyebrow", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                            placeholder="e.g. SPECIAL OFFER"
                          />
                        </div>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[11px] font-bold text-slate-500">Color Theme Style</label>
                          <select
                            value={sec.theme || "light"}
                            onChange={(e) => updateSectionField(sec.id, "theme", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-bold outline-none focus:border-blue bg-white"
                          >
                            <option value="light">Clean Light Gray Background</option>
                            <option value="dark">Sleek Navy Dark Pattern</option>
                            <option value="blue">Royal Blue Card Block</option>
                            <option value="gray">Pure White Minimal Card</option>
                          </select>
                        </div>

                        <div className="flex flex-col gap-1.5 md:col-span-2">
                          <label className="text-[11px] font-bold text-slate-500">Section Title</label>
                          <input
                            type="text"
                            value={sec.title}
                            onChange={(e) => updateSectionField(sec.id, "title", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-bold outline-none focus:border-blue"
                            placeholder="e.g. Express Urgent Processing Guarantee"
                          />
                        </div>

                        <div className="flex flex-col gap-1.5 md:col-span-2">
                          <label className="text-[11px] font-bold text-slate-500">Section Subtitle</label>
                          <input
                            type="text"
                            value={sec.subtitle}
                            onChange={(e) => updateSectionField(sec.id, "subtitle", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                            placeholder="e.g. Need your document immediately for a last-minute flight? We prioritize express approvals."
                          />
                        </div>

                        <div className="flex flex-col gap-1.5 md:col-span-2">
                          <label className="text-[11px] font-bold text-slate-500">Main Content / Description</label>
                          <textarea
                            rows={3}
                            value={sec.content}
                            onChange={(e) => updateSectionField(sec.id, "content", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                            placeholder="Write the full message, bullet points, or details for this custom section..."
                          />
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <label className="text-[11px] font-bold text-slate-500">Button Text</label>
                          <input
                            type="text"
                            value={sec.btnText}
                            onChange={(e) => updateSectionField(sec.id, "btnText", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-bold outline-none focus:border-blue"
                            placeholder="e.g. Apply Now →"
                          />
                        </div>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[11px] font-bold text-slate-500">Button Link URL</label>
                          <input
                            type="text"
                            value={sec.btnUrl}
                            onChange={(e) => updateSectionField(sec.id, "btnUrl", e.target.value)}
                            className="p-2.5 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                            placeholder="e.g. /apply or https://..."
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "contact" && (
          <div className="space-y-6">
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2">
              Hero Section Content
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Hero Eyebrow (Badge)</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:hero_eyebrow"]}
                  onChange={(e) => handleChange("site_edit:contact:hero_eyebrow", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Hero Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:hero_title"]}
                  onChange={(e) => handleChange("site_edit:contact:hero_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                />
              </div>
              <div className="flex flex-col gap-1.5 md:col-span-2">
                <label className="text-xs font-bold text-slate-500">Hero Subtitle</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:contact:hero_subtitle"]}
                  onChange={(e) => handleChange("site_edit:contact:hero_subtitle", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>
            </div>

            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2 mt-8">
              Quick Contact Cards & Form Info
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Call Card */}
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Call Us Card Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:call_title"]}
                  onChange={(e) => handleChange("site_edit:contact:call_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Phone Number</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:call_phone"]}
                  onChange={(e) => handleChange("site_edit:contact:call_phone", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Support Hours Detail</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:call_hours"]}
                  onChange={(e) => handleChange("site_edit:contact:call_hours", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              {/* Email Card */}
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Email Us Card Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:email_title"]}
                  onChange={(e) => handleChange("site_edit:contact:email_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Email Address</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:email_address"]}
                  onChange={(e) => handleChange("site_edit:contact:email_address", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Email Response Time</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:email_desc"]}
                  onChange={(e) => handleChange("site_edit:contact:email_desc", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              {/* Address Card */}
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Address Box Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:address_title"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:address_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Official Address Value</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:contact:address_value"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:address_value", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue resize-none"
                />
              </div>

              {/* Form Title & Subtitle */}
              <div className="flex flex-col gap-1.5 md:col-span-2 mt-4">
                <label className="text-xs font-bold text-slate-500">Contact Form Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:form_title"]}
                  onChange={(e) => handleChange("site_edit:contact:form_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue"
                />
              </div>
              <div className="flex flex-col gap-1.5 md:col-span-2">
                <label className="text-xs font-bold text-slate-500">Contact Form Subtitle</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:contact:form_subtitle"]}
                  onChange={(e) => handleChange("site_edit:contact:form_subtitle", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>
            </div>

            {/* WhatsApp Box & Socials */}
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2 mt-8">
              WhatsApp Support Box & Social Links
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* WhatsApp Support Box */}
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">WhatsApp Card Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:whatsapp_title"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:whatsapp_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">WhatsApp Card Description</label>
                <textarea
                  rows={2}
                  value={formData["site_edit:contact:whatsapp_desc"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:whatsapp_desc", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue resize-none"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">WhatsApp Display Phone</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:whatsapp_phone"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:whatsapp_phone", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">WhatsApp URL (API Link)</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:whatsapp_url"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:whatsapp_url", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              {/* Social links */}
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Social Media Links</label>
                <label className="text-[10px] font-bold text-slate-500 mt-2">Facebook URL</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:social_facebook"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:social_facebook", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Instagram URL</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:social_instagram"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:social_instagram", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Email Address (Follow box)</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:social_email"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:social_email", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>
            </div>

            {/* Support Hours */}
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2 mt-8">
              Support Hours Settings
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Hours Card Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:hours_title"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:hours_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Timezone Warning Label</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:hours_timezone"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:hours_timezone", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Hours Schedule Rows</label>
                
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Weekday Hours</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_weekday"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_weekday", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Weekday Badge</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_weekday_badge"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_weekday_badge", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Saturday Hours</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_saturday"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_saturday", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">Sunday Hours</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_sunday"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_sunday", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">WhatsApp Hours</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_whatsapp"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_whatsapp", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500">WhatsApp Badge</label>
                    <input
                      type="text"
                      value={formData["site_edit:contact:hours_whatsapp_badge"] || ""}
                      onChange={(e) => handleChange("site_edit:contact:hours_whatsapp_badge", e.target.value)}
                      className="p-2 border border-slate-200 rounded-lg text-xs font-medium bg-white outline-none focus:border-blue w-full"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Bar */}
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2 mt-8">
              Public Page Stats Bar
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex flex-col gap-1.5 border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                <label className="text-[10px] font-bold text-slate-500">Stat 1 Value</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_1_val"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_1_val", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-semibold bg-white outline-none focus:border-blue"
                />
                <label className="text-[9px] font-bold text-slate-400 mt-1">Stat 1 Label</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_1_lbl"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_1_lbl", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              <div className="flex flex-col gap-1.5 border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                <label className="text-[10px] font-bold text-slate-500">Stat 2 Value</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_2_val"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_2_val", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-semibold bg-white outline-none focus:border-blue"
                />
                <label className="text-[9px] font-bold text-slate-400 mt-1">Stat 2 Label</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_2_lbl"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_2_lbl", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              <div className="flex flex-col gap-1.5 border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                <label className="text-[10px] font-bold text-slate-500">Stat 3 Value</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_3_val"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_3_val", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-semibold bg-white outline-none focus:border-blue"
                />
                <label className="text-[9px] font-bold text-slate-400 mt-1">Stat 3 Label</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_3_lbl"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_3_lbl", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>

              <div className="flex flex-col gap-1.5 border border-slate-100 p-3 rounded-xl bg-slate-50/50">
                <label className="text-[10px] font-bold text-slate-500">Stat 4 Value</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_4_val"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_4_val", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-semibold bg-white outline-none focus:border-blue"
                />
                <label className="text-[9px] font-bold text-slate-400 mt-1">Stat 4 Label</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:stat_4_lbl"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:stat_4_lbl", e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>
            </div>

            {/* Trust Guarantee Strip */}
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2 mt-8">
              Trust Strip & Guarantee
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Guarantee Title</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:trust_title"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:trust_title", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">Guarantee Description</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:contact:trust_desc"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:trust_desc", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue resize-none"
                />
              </div>

              <div className="flex flex-col gap-1.5 border border-slate-100 p-4 rounded-2xl bg-slate-50/50">
                <label className="text-xs font-black text-blue">Call To Action Button</label>
                <label className="text-[10px] font-bold text-slate-500 mt-2">CTA Link Text</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:trust_cta_text"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:trust_cta_text", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
                <label className="text-[10px] font-bold text-slate-500 mt-2">CTA Redirect URL</label>
                <input
                  type="text"
                  value={formData["site_edit:contact:trust_cta_url"] || ""}
                  onChange={(e) => handleChange("site_edit:contact:trust_cta_url", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium bg-white outline-none focus:border-blue"
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === "legal" && (
          <div className="space-y-6">
            <h3 className="font-sora font-black text-navy text-sm border-b border-slate-100 pb-2">
              Legal Policy Intros
            </h3>
            <div className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Refunds Policy Intro Paragraph</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:legal:refunds_intro"]}
                  onChange={(e) => handleChange("site_edit:legal:refunds_intro", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Privacy Policy Intro Paragraph</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:legal:privacy_intro"]}
                  onChange={(e) => handleChange("site_edit:legal:privacy_intro", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Disclaimer Intro Paragraph</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:legal:disclaimer_intro"]}
                  onChange={(e) => handleChange("site_edit:legal:disclaimer_intro", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500">Terms & Conditions Intro Paragraph</label>
                <textarea
                  rows={3}
                  value={formData["site_edit:legal:terms_intro"]}
                  onChange={(e) => handleChange("site_edit:legal:terms_intro", e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-xs font-medium outline-none focus:border-blue resize-none"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
