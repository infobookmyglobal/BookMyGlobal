"use client";

import { useState, useEffect } from "react";
import { X, Check, AlertCircle, Mail, FileText, Truck, ArrowRight, Loader2, Trash } from "lucide-react";
import Image from "next/image";
import { getCurrencySymbol } from "@/lib/currency";

interface ApplicationReviewPanelProps {
  application: any;
  onClose: () => void;
  onRefresh: () => void;
}

function formatToIST(dateInput: Date | string) {
  return new Date(dateInput).toLocaleString("en-US", {
    timeZone: "Asia/Kolkata",
  }) + " (IST)";
}

export function ApplicationReviewPanel({
  application: initialApp,
  onClose,
  onRefresh,
}: ApplicationReviewPanelProps) {
  const [app, setApp] = useState(initialApp);
  const [notes, setNotes] = useState(app.adminNotes || "");
  const [isSavingNotes, setIsSavingNotes] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [isSubmittingRejection, setIsSubmittingRejection] = useState(false);
  const [isSubmittingApproval, setIsSubmittingApproval] = useState(false);
  const [isSubmittingPdf, setIsSubmittingPdf] = useState(false);
  const [isResendingEmail, setIsResendingEmail] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [isSavingChanges, setIsSavingChanges] = useState(false);
  const [isUploading, setIsUploading] = useState<{ [key: string]: boolean }>({});
  const [editFields, setEditFields] = useState({
    fullName: "",
    email: "",
    phone: "",
    country: "",
    dob: "",
    licenseNumber: "",
    licenseIssueDate: "",
    licenseExpiryDate: "",
    gender: "",
    countryOfBirth: "",
    countryOfResidence: "",
    licenseClass: "",
    parentName: "",
    destinationCountry: "",
    address: "",
    shippingAddress: "",
    profilePhotoUrl: "",
    licenseUrl: "",
    passportUrl: "",
  });

  useEffect(() => {
    setApp(initialApp);
    setNotes(initialApp.adminNotes || "");

    // Detect custom shipping address in adminNotes
    let initialShippingAddr = "";
    if (initialApp.adminNotes) {
      const match = initialApp.adminNotes.match(/SHIPPING ADDRESS:\s*([^\n|]+)/i);
      if (match && match[1]) {
        initialShippingAddr = match[1].trim();
      }
    }
    setShippingAddress(initialShippingAddr || initialApp.address || "");

    setEditFields({
      fullName: initialApp.fullName || "",
      email: initialApp.email || "",
      phone: initialApp.phone || "",
      country: initialApp.country || "",
      dob: initialApp.dob ? new Date(initialApp.dob).toISOString().split("T")[0] : "",
      licenseNumber: initialApp.licenseNumber || "",
      licenseIssueDate: initialApp.licenseIssueDate ? new Date(initialApp.licenseIssueDate).toISOString().split("T")[0] : "",
      licenseExpiryDate: initialApp.licenseExpiryDate ? new Date(initialApp.licenseExpiryDate).toISOString().split("T")[0] : "",
      gender: (initialApp as any).gender || "",
      countryOfBirth: (initialApp as any).countryOfBirth || "",
      countryOfResidence: (initialApp as any).countryOfResidence || "",
      licenseClass: (initialApp as any).licenseClass || "",
      parentName: (initialApp as any).parentName || "",
      destinationCountry: initialApp.destinationCountry || "",
      address: initialApp.address || "",
      shippingAddress: initialShippingAddr || initialApp.address || "",
      profilePhotoUrl: initialApp.profilePhotoUrl || "",
      licenseUrl: initialApp.licenseUrl || "",
      passportUrl: initialApp.passportUrl || "",
    });
  }, [initialApp]);

  // Re-upload state
  const [isReuploading, setIsReuploading] = useState(false);
  const [reuploadPassport, setReuploadPassport] = useState(false);
  const [reuploadLicense, setReuploadLicense] = useState(false);
  const [reuploadProfile, setReuploadProfile] = useState(false);
  const [reuploadNotes, setReuploadNotes] = useState("");
  const [isSubmittingReupload, setIsSubmittingReupload] = useState(false);

  // Form Edit Request state
  const [isRequestingEdit, setIsRequestingEdit] = useState(false);
  const [editRequestNotes, setEditRequestNotes] = useState("");
  const [isSubmittingEditRequest, setIsSubmittingEditRequest] = useState(false);

  // Shipment Creator state
  const [isCreatingShipment, setIsCreatingShipment] = useState(false);
  const [shippingAddress, setShippingAddress] = useState(app.address || "");
  const [recipientName, setRecipientName] = useState(app.fullName || "");
  const [recipientPhone, setRecipientPhone] = useState(app.phone || "");
  const [isSubmittingShipment, setIsSubmittingShipment] = useState(false);

  // Custom manual PDF upload states
  const [customBookletKey, setCustomBookletKey] = useState<string>("");
  const [customIdCardKey, setCustomIdCardKey] = useState<string>("");
  const [isUploadingCustomBooklet, setIsUploadingCustomBooklet] = useState(false);
  const [isUploadingCustomIdCard, setIsUploadingCustomIdCard] = useState(false);

  const getMediaUrl = (urlOrKey: string | null) => {
    if (!urlOrKey) return "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=256";
    if (urlOrKey.startsWith("http") || urlOrKey.startsWith("/")) return urlOrKey;
    // Map to CloudFront domain if it is just a key
    const cfDomain = process.env.NEXT_PUBLIC_CLOUDFRONT_DOMAIN || "d1234abcd5678.cloudfront.net";
    return `https://${cfDomain}/${urlOrKey}`;
  };

  const handleDocumentChange = async (fieldName: 'profilePhotoUrl' | 'licenseUrl' | 'passportUrl', file: File) => {
    setIsUploading(prev => ({ ...prev, [fieldName]: true }));
    try {
      const folderMap = {
        profilePhotoUrl: "profiles",
        licenseUrl: "licenses",
        passportUrl: "passports"
      };
      const folder = folderMap[fieldName];
      const timestamp = Date.now();
      let ext = "jpg";
      if (file.type === "image/png") ext = "png";
      else if (file.type === "application/pdf") ext = "pdf";
      else if (file.type === "image/webp") ext = "webp";
      const key = `uploads/${folder}/${app.id}/${timestamp}.${ext}`;

      const presignRes = await fetch("/api/upload/presign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, mimeType: file.type, applicationId: app.id }),
      });
      if (!presignRes.ok) throw new Error("Failed to get upload URL");
      const { uploadUrl, cloudFrontUrl } = await presignRes.json();

      await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });

      setEditFields(prev => ({ ...prev, [fieldName]: key }));
      alert(`${fieldName.replace("Url", "")} uploaded successfully!`);
    } catch (err: any) {
      alert("Failed to upload document: " + err.message);
    } finally {
      setIsUploading(prev => ({ ...prev, [fieldName]: false }));
    }
  };

  const handleCustomPdfUpload = async (type: 'booklet' | 'idcard', file: File) => {
    if (type === 'booklet') setIsUploadingCustomBooklet(true);
    else setIsUploadingCustomIdCard(true);

    try {
      const timestamp = Date.now();
      const key = `uploads/manual_pdfs/${app.id}/${type}_${timestamp}.pdf`;

      const presignRes = await fetch("/api/upload/presign", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, mimeType: "application/pdf" }),
      });
      if (!presignRes.ok) throw new Error("Failed to get upload URL");
      const { uploadUrl, key: returnedKey } = await presignRes.json();

      await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/pdf" },
        body: file,
      });

      if (type === 'booklet') {
        setCustomBookletKey(returnedKey);
      } else {
        setCustomIdCardKey(returnedKey);
      }
      alert(`Manual ${type} PDF uploaded successfully! Click 'Regenerate PDFs' to apply.`);
    } catch (err: any) {
      alert(`Failed to upload manual PDF: ${err.message}`);
    } finally {
      if (type === 'booklet') setIsUploadingCustomBooklet(false);
      else setIsUploadingCustomIdCard(false);
    }
  };

  const handleSaveChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingChanges(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editFields),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to save changes");
      }

      const resData = await response.json();
      alert(
        resData.pdfRegenerated
          ? "Application updated and PDFs successfully regenerated!"
          : "Application updated successfully!"
      );
      setIsEditing(false);
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSavingChanges(false);
    }
  };

  const handleSaveNotes = async () => {
    setIsSavingNotes(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes }),
      });
      if (!response.ok) throw new Error("Failed to save notes");
      alert("Notes saved successfully!");
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSavingNotes(false);
    }
  };

  const handleApprove = async () => {
    if (!confirm("Are you sure you want to approve this application and generate the permit booklet/ID card?")) return;
    setIsSubmittingApproval(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/approve`, {
        method: "POST",
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Approval and PDF generation failed (${response.status})`);
      }
      const result = await response.json();
      alert(`Application Approved!\nGenerated IDP Number: ${result.idpNumber}`);
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingApproval(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("⚠️ WARNING: This will permanently delete this application, its payment records, shipment records, and all associated data. This action CANNOT be undone. Are you sure you want to proceed?")) return;
    setIsDeleting(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || "Delete failed");
      }
      alert("Application successfully deleted!");
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      alert("Rejection reason is required");
      return;
    }
    setIsSubmittingRejection(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: rejectionReason }),
      });
      if (!response.ok) throw new Error("Rejection failed");
      alert("Application Rejected and email sent to the user.");
      setIsRejecting(false);
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingRejection(false);
    }
  };

  const handleRequestReupload = async () => {
    if (!reuploadPassport && !reuploadLicense && !reuploadProfile) {
      alert("Please select at least one document to re-upload.");
      return;
    }
    setIsSubmittingReupload(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/request-reupload`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          passport: reuploadPassport,
          license: reuploadLicense,
          profile: reuploadProfile,
          notes: reuploadNotes,
        }),
      });
      if (!response.ok) throw new Error("Request failed");
      alert("Re-upload request sent successfully and email sent to the user.");
      setIsReuploading(false);
      // Reset form states
      setReuploadPassport(false);
      setReuploadLicense(false);
      setReuploadProfile(false);
      setReuploadNotes("");
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingReupload(false);
    }
  };

  const handleRequestEdit = async () => {
    if (!editRequestNotes.trim()) {
      alert("Please specify what needs to be edited.");
      return;
    }
    setIsSubmittingEditRequest(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/request-edit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notes: editRequestNotes,
        }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Edit request failed");
      }
      alert("Edit request sent successfully and email sent to the user.");
      setIsRequestingEdit(false);
      setEditRequestNotes("");
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingEditRequest(false);
    }
  };

  const handleManualPdfGenerate = async () => {
    setIsSubmittingPdf(true);
    try {
      const response = await fetch("/api/pdf/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId: app.id,
          customBookletKey: customBookletKey || undefined,
          customIdCardKey: customIdCardKey || undefined,
        }),
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `PDF generation failed (${response.status})`);
      }
      alert("PDF Booklet and ID Card regenerated successfully!");
      setCustomBookletKey("");
      setCustomIdCardKey("");
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingPdf(false);
    }
  };

  const handleResendEmail = async (type: string) => {
    setIsResendingEmail(true);
    try {
      const response = await fetch(`/api/admin/applications/${app.id}/resend-email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ emailType: type }),
      });
      if (!response.ok) throw new Error("Email sending failed");
      alert(`Manual email (${type}) resent successfully.`);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsResendingEmail(false);
    }
  };

  const handleCreateShipment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingShipment(true);
    try {
      const response = await fetch("/api/shipments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          applicationId: app.id,
          address: shippingAddress,
          recipientName,
          recipientPhone,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create shipment");
      }

      const result = await response.json();
      alert(`Shipment Created successfully!\nAWB: ${result.awbNumber}`);
      setIsCreatingShipment(false);
      onRefresh();
      onClose();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmittingShipment(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-4xl bg-bg-custom h-full flex flex-col shadow-2xl relative animate-slide-in">
        {/* Header */}
        <div className="bg-navy text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div>
            <h2 className="font-sora font-black text-lg">
              Review Application
            </h2>
            <span className="text-[10px] text-white/60 font-bold font-mono">
              ID: {app.id} · {app.idpNumber || "No IDP#"}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {app.isDuplicate && (
            <div className="bg-amber-50 border border-amber-200 text-amber-950 px-5 py-3 rounded-2xl text-xs font-bold space-y-1">
              <div className="flex items-center gap-1.5 text-amber-800">
                <AlertCircle className="w-4 h-4" />
                <span>Duplicate Payment / Record Alert</span>
              </div>
              <p className="font-normal text-slate-600">
                Another application exists in the database with the exact same payment ID (<strong>{app.payment?.providerPaymentId}</strong>). This usually happens when the payment verification is retried or double-submitted. You may want to delete this record if it is a duplicate.
              </p>
            </div>
          )}

          {app.isInvalidDestination && (
            <div className="bg-rose-50 border border-rose-200 text-rose-950 px-5 py-3 rounded-2xl text-xs font-bold space-y-1">
              <div className="flex items-center gap-1.5 text-rose-800">
                <AlertCircle className="w-4 h-4" />
                <span>Physical IDP Required Alert</span>
              </div>
              <p className="font-normal text-slate-600">
                This applicant ordered a <strong>Digital IDP Only</strong>, but selected <strong>{app.destinationCountry}</strong> as their destination, which only accepts <strong>Physical IDPs</strong>. This application should be rejected or edited, or the customer must upgrade to a physical kit.
              </p>
            </div>
          )}

          {/* Status pipeline */}
          <div className="bg-white border border-border-custom rounded-3xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-black text-navy uppercase tracking-wider">Pipeline Status</h3>
              <span className="sm:hidden text-[10px] font-black uppercase bg-blue/10 text-blue px-2 py-0.5 rounded-full">
                {app.status.replace(/_/g, " ")}
              </span>
            </div>
            <div className="flex items-center justify-between text-center max-w-2xl mx-auto">
              {["PENDING", "UNDER_REVIEW", "APPROVED", "COMPLETED"].map((step, idx) => {
                const isPast =
                  app.status === step ||
                  (step === "PENDING" && app.status !== "PENDING") ||
                  (step === "UNDER_REVIEW" && ["APPROVED", "COMPLETED"].includes(app.status)) ||
                  (step === "APPROVED" && app.status === "COMPLETED");
                const isCurrent = app.status === step;

                return (
                  <div key={step} className="flex-1 flex items-center">
                    <div className="flex flex-col items-center mx-auto">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                          isCurrent
                            ? "bg-blue text-white ring-4 ring-blue/20"
                            : isPast
                            ? "bg-green-500 text-white"
                            : "bg-bg-custom text-muted border border-border-custom"
                        }`}
                      >
                        {isPast && !isCurrent ? <Check className="w-4 h-4" /> : idx + 1}
                      </div>
                      <span className="text-[9px] font-black text-navy mt-1.5 uppercase tracking-wide hidden sm:block">
                        {step.replace(/_/g, " ")}
                      </span>
                    </div>
                    {idx < 3 && (
                      <div
                        className={`flex-1 h-0.5 mx-2 ${
                          isPast ? "bg-green-400" : "bg-border-custom"
                        }`}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Left 2 Columns */}
            <div className="md:col-span-2 space-y-6">
              {/* Applicant Details */}
              <div className="bg-white border border-border-custom rounded-3xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-border-custom pb-2">
                  <h3 className="font-sora font-black text-navy text-sm">
                    Applicant Information
                  </h3>
                  {!isEditing && (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-blue hover:text-navy text-xs font-black flex items-center gap-1 bg-blue/5 hover:bg-blue/10 px-3 py-1 rounded-lg transition-all"
                    >
                      Edit Info
                    </button>
                  )}
                </div>

                {isEditing ? (
                  <form onSubmit={handleSaveChanges} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-muted block font-bold mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          value={editFields.fullName}
                          onChange={(e) => setEditFields(prev => ({ ...prev, fullName: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Nationality / Issuing Country</label>
                        <input
                          type="text"
                          required
                          value={editFields.country}
                          onChange={(e) => setEditFields(prev => ({ ...prev, country: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Email Address</label>
                        <input
                          type="email"
                          required
                          value={editFields.email}
                          onChange={(e) => setEditFields(prev => ({ ...prev, email: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Phone Number</label>
                        <input
                          type="text"
                          required
                          value={editFields.phone}
                          onChange={(e) => setEditFields(prev => ({ ...prev, phone: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Date of Birth</label>
                        <input
                          type="date"
                          required
                          value={editFields.dob}
                          onChange={(e) => setEditFields(prev => ({ ...prev, dob: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">License Number</label>
                        <input
                          type="text"
                          required
                          value={editFields.licenseNumber}
                          onChange={(e) => setEditFields(prev => ({ ...prev, licenseNumber: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Gender</label>
                        <select
                          value={editFields.gender}
                          onChange={(e) => setEditFields(prev => ({ ...prev, gender: e.target.value }))}
                          className="w-full border border-border-custom bg-white rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        >
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Parent/Guardian Name</label>
                        <input
                          type="text"
                          value={editFields.parentName}
                          onChange={(e) => setEditFields(prev => ({ ...prev, parentName: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Country of Birth</label>
                        <input
                          type="text"
                          value={editFields.countryOfBirth}
                          onChange={(e) => setEditFields(prev => ({ ...prev, countryOfBirth: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">Country of Residence</label>
                        <input
                          type="text"
                          value={editFields.countryOfResidence}
                          onChange={(e) => setEditFields(prev => ({ ...prev, countryOfResidence: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="text-muted block font-bold mb-1">License Class / Categories</label>
                        <input
                          type="text"
                          value={editFields.licenseClass}
                          onChange={(e) => setEditFields(prev => ({ ...prev, licenseClass: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="text-muted block font-bold mb-1">Destination Country</label>
                        <input
                          type="text"
                          required
                          value={editFields.destinationCountry}
                          onChange={(e) => setEditFields(prev => ({ ...prev, destinationCountry: e.target.value }))}
                          className="w-full border border-border-custom rounded-xl px-3 py-2 outline-none focus:border-blue font-black text-navy"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-muted block font-bold mb-1">Residential / License Address</label>
                        <textarea
                          value={editFields.address}
                          onChange={(e) => setEditFields(prev => ({ ...prev, address: e.target.value }))}
                          rows={2}
                          className="w-full border border-border-custom rounded-xl p-3 outline-none focus:border-blue font-black text-navy resize-none"
                        />
                      </div>
                      <div>
                        <label className="text-muted block font-bold mb-1">
                          📦 Shipping Address
                          {app.productType !== "NFC_KIT" && (
                            <span className="text-blue font-normal ml-1.5">(Digital Request)</span>
                          )}
                        </label>
                        <textarea
                          value={editFields.shippingAddress}
                          onChange={(e) => setEditFields(prev => ({ ...prev, shippingAddress: e.target.value }))}
                          rows={2}
                          placeholder={app.productType !== "NFC_KIT" ? "Digital IDP Request - No shipping required" : "Enter shipping address"}
                          className="w-full border border-border-custom rounded-xl p-3 outline-none focus:border-blue font-black text-navy resize-none"
                        />
                      </div>
                    </div>

                    {/* Replace document uploads inside admin review */}
                    <div className="border-t border-border-custom pt-4 mt-2">
                      <h4 className="font-sora font-black text-navy text-xs mb-3">Replace Uploaded Documents</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {[
                          { field: "profilePhotoUrl", label: "Profile Photo" },
                          { field: "licenseUrl", label: "License Front" },
                          { field: "passportUrl", label: "License Back" }
                        ].map((doc) => (
                          <div key={doc.field} className="space-y-2 text-center">
                            <label className="text-muted block font-bold text-[10px] uppercase tracking-wide">{doc.label}</label>
                            {editFields[doc.field as keyof typeof editFields] ? (
                              <div className="relative aspect-square rounded-xl overflow-hidden bg-bg-custom border border-border-custom">
                                <img
                                  src={getMediaUrl(editFields[doc.field as keyof typeof editFields] as string)}
                                  alt={doc.label}
                                  className="w-full h-full object-cover"
                                />
                                <button
                                  type="button"
                                  onClick={() => setEditFields(prev => ({ ...prev, [doc.field]: "" }))}
                                  className="absolute top-1.5 right-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 shadow-md transition-all"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <div className="border-2 border-dashed border-border-custom rounded-xl aspect-square flex flex-col items-center justify-center p-2 text-center hover:border-blue hover:bg-blue/5 transition-all cursor-pointer relative">
                                <input
                                  type="file"
                                  accept="image/jpeg,image/png,image/webp,application/pdf"
                                  className="absolute inset-0 opacity-0 cursor-pointer"
                                  disabled={isUploading[doc.field]}
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) handleDocumentChange(doc.field as any, file);
                                  }}
                                />
                                {isUploading[doc.field] ? (
                                  <Loader2 className="w-5 h-5 text-blue animate-spin" />
                                ) : (
                                  <>
                                    <Mail className="w-5 h-5 text-muted" />
                                    <span className="text-[9px] font-bold text-blue mt-1">Upload New</span>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end border-t border-border-custom pt-4">
                      <button
                        type="button"
                        onClick={() => setIsEditing(false)}
                        className="bg-bg-custom text-navy border border-border-custom font-bold text-xs px-4 py-2 rounded-xl hover:bg-border-custom transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSavingChanges}
                        className="bg-blue hover:bg-navy text-white font-black text-xs px-6 py-2 rounded-xl transition-all shadow-md shadow-blue/10 flex items-center gap-1.5"
                      >
                        {isSavingChanges && <Loader2 className="w-4 h-4 animate-spin" />}
                        Save Changes
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="text-muted block font-bold">Full Name</label>
                      <span className="font-black text-navy">{app.fullName}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Nationality</label>
                      <span className="font-black text-navy">{app.country}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Email Address</label>
                      <span className="font-black text-navy">{app.email}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Phone Number</label>
                      <span className="font-black text-navy">{app.phone}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Date of Birth</label>
                      <span className="font-black text-navy">
                        {app.dob ? new Date(app.dob).toLocaleDateString() : "N/A"}
                      </span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">License Number</label>
                      <span className="font-black text-navy">{app.licenseNumber || "N/A"}</span>
                    </div>

                    <div>
                      <label className="text-muted block font-bold">Gender</label>
                      <span className="font-black text-navy">{(app as any).gender || "N/A"}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Parent/Guardian Name</label>
                      <span className="font-black text-navy">{(app as any).parentName || "N/A"}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Country of Birth</label>
                      <span className="font-black text-navy">{(app as any).countryOfBirth || "N/A"}</span>
                    </div>
                    <div>
                      <label className="text-muted block font-bold">Country of Residence</label>
                      <span className="font-black text-navy">{(app as any).countryOfResidence || "N/A"}</span>
                    </div>
                    <div className="col-span-1 sm:col-span-2">
                      <label className="text-muted block font-bold">License Class / Categories</label>
                      <span className="font-black text-navy">{(app as any).licenseClass || "N/A"}</span>
                    </div>
                    <div className="col-span-1 sm:col-span-2">
                      <label className="text-muted block font-bold">Destination Country</label>
                      <span className="font-black text-navy">{app.destinationCountry || "N/A"}</span>
                    </div>
                    <div className="col-span-1 sm:col-span-2">
                      <label className="text-muted block font-bold">Residential / License Address</label>
                      <span className="font-black text-navy whitespace-pre-wrap">{app.address || "N/A"}</span>
                    </div>
                    <div className="col-span-1 sm:col-span-2">
                      <label className="text-muted block font-bold">📦 Shipping Address</label>
                      <span className="font-black text-navy whitespace-pre-wrap">
                        {app.productType === "NFC_KIT" ? (
                          (() => {
                            if (app.adminNotes) {
                              const match = app.adminNotes.match(/SHIPPING ADDRESS:\s*([^\n|]+)/i);
                              if (match && match[1]) {
                                return match[1].trim();
                              }
                            }
                            return app.address || "N/A";
                          })()
                        ) : (
                          <span className="text-blue font-bold">Digital IDP Request (No physical shipping required)</span>
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Order Info */}
              <div className="bg-white border border-border-custom rounded-3xl p-6 shadow-sm space-y-4">
                <h3 className="font-sora font-black text-navy text-sm border-b border-border-custom pb-2">
                  Product & Payment
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="text-muted block font-bold">Product Ordered</label>
                    <span className="font-black text-navy">
                      {app.productType === "NFC_KIT" ? "📦 NFC Smart Kit" : "📱 Digital IDP Only"}
                    </span>
                  </div>
                  <div>
                    <label className="text-muted block font-bold">Validity Option</label>
                    <span className="font-black text-navy">{app.validity} Year{app.validity > 1 ? "s" : ""}</span>
                  </div>
                  <div>
                    <label className="text-muted block font-bold">Payment Amount</label>
                    <span className="font-black text-green-700">
                      {getCurrencySymbol(app.currency || "USD")}{app.finalAmount.toFixed(2)} {app.currency || "USD"}
                    </span>
                  </div>
                  <div>
                    <label className="text-muted block font-bold">Payment Method</label>
                    <span className="font-black text-navy uppercase">{app.payment?.provider || "N/A"}</span>
                  </div>
                </div>
              </div>

              {/* Document Images */}
              <div className="bg-white border border-border-custom rounded-3xl p-6 shadow-sm space-y-4">
                <h3 className="font-sora font-black text-navy text-sm border-b border-border-custom pb-2">
                  Uploaded Documents
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {[
                    { label: "Profile Photo", url: app.profilePhotoUrl },
                    { label: "License Front", url: app.licenseUrl },
                    { label: "License Back", url: app.passportUrl },
                  ].map((doc) => (
                    <div key={doc.label} className="space-y-2 text-center">
                      <a
                        href={getMediaUrl(doc.url)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="relative aspect-square rounded-2xl overflow-hidden bg-bg-custom border border-border-custom block hover:scale-[1.03] transition-all cursor-zoom-in"
                      >
                        <img
                          src={getMediaUrl(doc.url)}
                          alt={doc.label}
                          className="w-full h-full object-cover"
                        />
                      </a>
                      <span className="text-[10px] font-black text-navy uppercase tracking-wider block">
                        {doc.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Panel / Sidebar Actions */}
            <div className="space-y-6">
              {/* Admin Notes */}
              <div className="bg-white border border-border-custom rounded-3xl p-5 shadow-sm space-y-3">
                <h3 className="font-sora font-black text-navy text-xs uppercase tracking-wider">Admin Notes</h3>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Internal notes about document checks..."
                  className="w-full border border-border-custom rounded-xl p-3 text-xs outline-none focus:border-blue resize-none h-28"
                />
                <button
                  onClick={handleSaveNotes}
                  disabled={isSavingNotes}
                  className="w-full btn-secondary py-2 flex items-center justify-center gap-2 text-xs font-bold"
                >
                  {isSavingNotes ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Save Notes"}
                </button>
              </div>

              {/* Administrative Pipeline */}
              <div className="bg-white border border-border-custom rounded-3xl p-5 shadow-sm space-y-3">
                <h3 className="font-sora font-black text-navy text-xs uppercase tracking-wider">Workflow Actions</h3>
                
                {app.status === "UNDER_REVIEW" || app.status === "PENDING" ? (
                  <div className="grid gap-2">
                    <button
                      onClick={handleApprove}
                      disabled={isSubmittingApproval}
                      className="w-full bg-green-500 hover:bg-green-600 text-white font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-green-500/10"
                    >
                      {isSubmittingApproval ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Approve & Generate IDP
                    </button>
                    <button
                      onClick={() => setIsRejecting(true)}
                      className="w-full border-2 border-red-200 hover:border-red-500 text-red-600 hover:bg-red-50 font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
                    >
                      <AlertCircle className="w-4 h-4" /> Reject Application
                    </button>
                    <button
                      onClick={() => setIsReuploading(true)}
                      className="w-full border-2 border-orange-200 hover:border-orange-500 text-orange-600 hover:bg-orange-50 font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
                    >
                      <Mail className="w-4 h-4" /> Request Re-upload
                    </button>
                    <button
                      onClick={() => setIsRequestingEdit(true)}
                      className="w-full border-2 border-blue/20 hover:border-blue text-blue hover:bg-blue/5 font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
                    >
                      <FileText className="w-4 h-4" /> Request Form Edit
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Custom PDF Upload Section */}
                    <div className="border border-border-custom rounded-2xl p-3.5 space-y-3 bg-bg-custom/40">
                      <span className="text-[10px] text-muted font-black uppercase tracking-wider block">
                        Upload Custom PDFs (Optional)
                      </span>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {/* Booklet PDF */}
                        <div className="relative">
                          {customBookletKey ? (
                            <div className="flex flex-col items-center justify-between border border-green-500 bg-green-50/50 rounded-xl p-2 h-[80px] text-center">
                              <span className="text-[9px] font-black text-green-700 truncate w-full">📄 Booklet Loaded</span>
                              <button
                                type="button"
                                onClick={() => setCustomBookletKey("")}
                                className="text-[9px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 px-2 py-0.5 rounded-lg transition-all"
                              >
                                Remove
                              </button>
                            </div>
                          ) : (
                            <label className="flex flex-col items-center justify-center border border-dashed border-border-custom hover:border-blue hover:bg-blue/5 rounded-xl p-2 h-[80px] text-center cursor-pointer transition-all">
                              <input
                                type="file"
                                accept="application/pdf"
                                className="hidden"
                                disabled={isUploadingCustomBooklet}
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleCustomPdfUpload('booklet', file);
                                }}
                              />
                              {isUploadingCustomBooklet ? (
                                <Loader2 className="w-4 h-4 text-blue animate-spin" />
                              ) : (
                                <>
                                  <FileText className="w-4 h-4 text-muted mb-1" />
                                  <span className="text-[9px] font-black text-blue">Add Booklet PDF</span>
                                </>
                              )}
                            </label>
                          )}
                        </div>

                        {/* ID Card PDF */}
                        <div className="relative">
                          {customIdCardKey ? (
                            <div className="flex flex-col items-center justify-between border border-green-500 bg-green-50/50 rounded-xl p-2 h-[80px] text-center">
                              <span className="text-[9px] font-black text-green-700 truncate w-full">📄 ID Card Loaded</span>
                              <button
                                type="button"
                                onClick={() => setCustomIdCardKey("")}
                                className="text-[9px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 px-2 py-0.5 rounded-lg transition-all"
                              >
                                Remove
                              </button>
                            </div>
                          ) : (
                            <label className="flex flex-col items-center justify-center border border-dashed border-border-custom hover:border-blue hover:bg-blue/5 rounded-xl p-2 h-[80px] text-center cursor-pointer transition-all">
                              <input
                                type="file"
                                accept="application/pdf"
                                className="hidden"
                                disabled={isUploadingCustomIdCard}
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleCustomPdfUpload('idcard', file);
                                }}
                              />
                              {isUploadingCustomIdCard ? (
                                <Loader2 className="w-4 h-4 text-blue animate-spin" />
                              ) : (
                                <>
                                  <FileText className="w-4 h-4 text-muted mb-1" />
                                  <span className="text-[9px] font-black text-blue">Add ID Card PDF</span>
                                </>
                              )}
                            </label>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={handleManualPdfGenerate}
                      disabled={isSubmittingPdf}
                      className="w-full btn-secondary py-3 flex items-center justify-center gap-2 text-xs font-black"
                    >
                      {isSubmittingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />} Regenerate PDFs
                    </button>

                    {app.pdfBookletUrl && (
                      <>
                        <div className="grid grid-cols-2 gap-2 mt-1">
                          <a
                            href={getMediaUrl(app.pdfBookletUrl)}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center justify-center gap-1.5 border-2 border-navy text-navy hover:bg-navy hover:text-white rounded-xl py-2.5 font-black text-[10px] transition-all bg-white"
                          >
                            <FileText className="w-3.5 h-3.5" /> View Booklet
                          </a>
                          <a
                            href={getMediaUrl(app.pdfIdCardUrl)}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center justify-center gap-1.5 border-2 border-blue text-blue hover:bg-blue hover:text-white rounded-xl py-2.5 font-black text-[10px] transition-all bg-white"
                          >
                            <FileText className="w-3.5 h-3.5" /> View ID Card
                          </a>
                        </div>
                        {app.pdfRegeneratedAt && (
                          <div className="text-[9px] text-orange-600 font-black text-center mt-2 bg-orange-50 border border-orange-200 rounded-xl py-2 px-2.5">
                            🔄 PDFs last regenerated on:<br />
                            {formatToIST(app.pdfRegeneratedAt)}
                          </div>
                        )}
                      </>
                    )}

                    <div className="border-t border-border-custom pt-3 space-y-1.5">
                      <span className="text-[10px] text-muted font-bold block mb-1">Resend SES Notification</span>
                      <div className="grid grid-cols-2 gap-1.5">
                        {["confirmation", "approved", "rejected", "shipping"].map((type) => (
                          <button
                            key={type}
                            disabled={isResendingEmail}
                            onClick={() => handleResendEmail(type)}
                            className="bg-bg-custom border border-border-custom hover:border-navy text-[9px] font-black text-navy capitalize py-1.5 rounded-lg transition-all"
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>

                    {app.productType === "NFC_KIT" && app.status === "APPROVED" && (
                      <button
                        onClick={() => setIsCreatingShipment(true)}
                        className="w-full bg-blue hover:bg-navy text-white font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-blue/10 mt-3"
                      >
                        <Truck className="w-4 h-4" /> Create ShipGlobal Label
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Danger Zone */}
              <div className="bg-red-50/50 border border-red-100 rounded-3xl p-5 space-y-3 mt-3">
                <h3 className="font-sora font-black text-red-800 text-xs uppercase tracking-wider">Danger Zone</h3>
                <button
                  onClick={handleDelete}
                  disabled={isDeleting}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-black text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-md shadow-red-600/10"
                >
                  {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash className="w-4 h-4" />} Delete Application
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Rejection Modal Overlay */}
        {isRejecting && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4 animate-scale-in">
              <div className="flex items-center justify-between border-b border-border-custom pb-3">
                <h4 className="font-sora font-black text-navy text-sm">Specify Rejection Reason</h4>
                <button onClick={() => setIsRejecting(false)} className="text-muted hover:text-navy">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Reason (e.g., license photo is blurry, name mismatch)..."
                className="w-full border border-border-custom rounded-xl p-3 text-xs outline-none focus:border-red-500 h-28"
              />
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setIsRejecting(false)}
                  className="bg-bg-custom text-navy border border-border-custom font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-border-custom"
                >
                  Cancel
                </button>
                <button
                  onClick={handleReject}
                  disabled={isSubmittingRejection}
                  className="bg-red-600 hover:bg-red-700 text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-red-500/10"
                >
                  {isSubmittingRejection ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : "Confirm Rejection"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Shipment Creator Modal Overlay */}
        {isCreatingShipment && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-lg rounded-3xl p-6 shadow-2xl space-y-4 animate-scale-in">
              <div className="flex items-center justify-between border-b border-border-custom pb-3">
                <h4 className="font-sora font-black text-navy text-sm flex items-center gap-2">
                  <Truck className="w-4 h-4 text-blue" /> ShipGlobal Package Label Creator
                </h4>
                <button onClick={() => setIsCreatingShipment(false)} className="text-muted hover:text-navy">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <form onSubmit={handleCreateShipment} className="space-y-4 text-xs">
                <div>
                  <label className="block text-muted font-bold mb-1">Recipient Full Name</label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full border border-border-custom rounded-xl px-3 py-2.5 outline-none focus:border-blue font-bold"
                  />
                </div>
                <div>
                  <label className="block text-muted font-bold mb-1">Recipient Phone</label>
                  <input
                    type="text"
                    required
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full border border-border-custom rounded-xl px-3 py-2.5 outline-none focus:border-blue font-bold"
                  />
                </div>
                <div>
                  <label className="block text-muted font-bold mb-1">Street Address, Pincode & City details</label>
                  <textarea
                    required
                    rows={3}
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    className="w-full border border-border-custom rounded-xl p-3 outline-none focus:border-blue font-bold resize-none"
                    placeholder="Enter complete shipping details..."
                  />
                </div>
                <div className="flex gap-2 justify-end border-t border-border-custom pt-3">
                  <button
                    type="button"
                    onClick={() => setIsCreatingShipment(false)}
                    className="bg-bg-custom text-navy border border-border-custom font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-border-custom"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingShipment}
                    className="bg-blue hover:bg-navy text-white font-black text-xs px-6 py-2.5 rounded-xl transition-all shadow-md shadow-blue/10 flex items-center gap-1.5"
                  >
                    {isSubmittingShipment && <Loader2 className="w-4 h-4 animate-spin" />}
                    Confirm Shipment & Dispatch →
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Re-upload Modal Overlay */}
        {isReuploading && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4 animate-scale-in">
              <div className="flex items-center justify-between border-b border-border-custom pb-3">
                <h4 className="font-sora font-black text-navy text-sm">Request Document Re-upload</h4>
                <button onClick={() => setIsReuploading(false)} className="text-muted hover:text-navy">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                <p className="text-[11px] text-muted font-bold">Select the document(s) you want the user to upload again:</p>
                
                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 text-xs font-bold text-navy cursor-pointer">
                    <input
                      type="checkbox"
                      checked={reuploadPassport && reuploadLicense && reuploadProfile}
                      onChange={(e) => {
                        const val = e.target.checked;
                        setReuploadPassport(val);
                        setReuploadLicense(val);
                        setReuploadProfile(val);
                      }}
                      className="rounded border-border-custom text-blue focus:ring-blue h-4 w-4"
                    />
                    <span>All 3 Documents</span>
                  </label>

                  <div className="pl-6 space-y-2 border-l-2 border-border-custom">
                    <label className="flex items-center gap-2.5 text-xs font-bold text-navy cursor-pointer">
                      <input
                        type="checkbox"
                        checked={reuploadPassport}
                        onChange={(e) => setReuploadPassport(e.target.checked)}
                        className="rounded border-border-custom text-blue focus:ring-blue h-4 w-4"
                      />
                      <span>License Back</span>
                    </label>

                    <label className="flex items-center gap-2.5 text-xs font-bold text-navy cursor-pointer">
                      <input
                        type="checkbox"
                        checked={reuploadLicense}
                        onChange={(e) => setReuploadLicense(e.target.checked)}
                        className="rounded border-border-custom text-blue focus:ring-blue h-4 w-4"
                      />
                      <span>License Front</span>
                    </label>

                    <label className="flex items-center gap-2.5 text-xs font-bold text-navy cursor-pointer">
                      <input
                        type="checkbox"
                        checked={reuploadProfile}
                        onChange={(e) => setReuploadProfile(e.target.checked)}
                        className="rounded border-border-custom text-blue focus:ring-blue h-4 w-4"
                      />
                      <span>Profile Photo</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[11px] text-muted font-bold">Message / Instructions for User</label>
                  <textarea
                    value={reuploadNotes}
                    onChange={(e) => setReuploadNotes(e.target.value)}
                    placeholder="Describe what was wrong (e.g., License Back photo is blurry, please upload a clear photo)..."
                    className="w-full border border-border-custom rounded-xl p-3 text-xs outline-none focus:border-blue h-24"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setIsReuploading(false)}
                  className="bg-bg-custom text-navy border border-border-custom font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-border-custom"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRequestReupload}
                  disabled={isSubmittingReupload}
                  className="bg-blue hover:bg-navy text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-blue/10 flex items-center gap-1.5"
                >
                  {isSubmittingReupload ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-3.5 h-3.5" />} Send Request
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Request Form Edit Modal Overlay */}
        {isRequestingEdit && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4 animate-scale-in">
              <div className="flex items-center justify-between border-b border-border-custom pb-3">
                <h4 className="font-sora font-black text-navy text-sm">Request Form Update</h4>
                <button onClick={() => setIsRequestingEdit(false)} className="text-muted hover:text-navy">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                <p className="text-[11px] text-muted font-bold">Ask the user to edit their application details.</p>
                <div className="space-y-1">
                  <label className="block text-[11px] text-muted font-bold">Message / Instructions for User</label>
                  <textarea
                    value={editRequestNotes}
                    onChange={(e) => setEditRequestNotes(e.target.value)}
                    placeholder="Describe what needs to be updated (e.g., Please correct your date of birth, name mismatch)..."
                    className="w-full border border-border-custom rounded-xl p-3 text-xs outline-none focus:border-blue h-24"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => setIsRequestingEdit(false)}
                  className="bg-bg-custom text-navy border border-border-custom font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-border-custom"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRequestEdit}
                  disabled={isSubmittingEditRequest}
                  className="bg-blue hover:bg-navy text-white font-black text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-blue/10 flex items-center gap-1.5"
                >
                  {isSubmittingEditRequest ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-3.5 h-3.5" />} Send Request
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
