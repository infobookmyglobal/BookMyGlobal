"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import {
  Globe,
  Save,
  Loader2,
  Check,
  Search,
  RotateCcw,
  Sparkles,
  Link as LinkIcon,
  CheckCircle,
  ExternalLink,
  Edit3,
} from "lucide-react";
import { getApiErrorMessage } from "@/lib/utils";

interface CountryItem {
  id: string;
  name: string;
  slug: string;
  flag?: string | null;
}

interface GuideItem {
  slug: string;
  title: string;
  category?: string | null;
}

interface RedirectsClientProps {
  settings: any[];
  countries?: CountryItem[];
  travelGuides?: GuideItem[];
  autoGuideMap?: Record<string, string>;
}

export function RedirectsClient({
  settings,
  countries = [],
  travelGuides = [],
  autoGuideMap = {},
}: RedirectsClientProps) {
  const router = useRouter();

  // Helper to find setting value
  const findValue = (key: string, defaultValue: string = "") => {
    const item = settings.find((s) => s.key === key);
    return item ? item.value : defaultValue;
  };

  // Country Redirects State: Record<countrySlug, targetUrl>
  const [countryRedirectsMap, setCountryRedirectsMap] = useState<Record<string, string>>(() => {
    try {
      const raw = findValue("country_redirects_map", "{}");
      return JSON.parse(raw);
    } catch {
      return {};
    }
  });

  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  // Custom mode tracker for rows where user wants to type a custom URL explicitly
  const [customModeMap, setCustomModeMap] = useState<Record<string, boolean>>({});

  // Search & Filter state
  const [redirectSearch, setRedirectSearch] = useState("");
  const [filterMode, setFilterMode] = useState<"all" | "overridden" | "auto" | "custom" | "default">("all");

  const guideSlugsSet = useMemo(() => {
    return new Set(travelGuides.map((g) => `/${g.slug.toLowerCase()}`));
  }, [travelGuides]);

  const handleRedirectSelectChange = (countrySlug: string, selectedValue: string) => {
    const slugKey = countrySlug.toLowerCase();
    if (selectedValue === "custom") {
      setCustomModeMap((prev) => ({ ...prev, [slugKey]: true }));
      // Keep existing custom value or set empty custom template
      const current = countryRedirectsMap[slugKey] || "";
      if (!current || current === "none" || current === "auto") {
        setCountryRedirectsMap((prev) => ({ ...prev, [slugKey]: "/" }));
      }
    } else {
      setCustomModeMap((prev) => ({ ...prev, [slugKey]: false }));
      setCountryRedirectsMap((prev) => {
        const copy = { ...prev };
        if (!selectedValue || selectedValue === "auto") {
          delete copy[slugKey];
        } else {
          copy[slugKey] = selectedValue.trim();
        }
        return copy;
      });
    }
  };

  const handleCustomUrlInputChange = (countrySlug: string, customUrl: string) => {
    const slugKey = countrySlug.toLowerCase();
    setCountryRedirectsMap((prev) => {
      const copy = { ...prev };
      if (!customUrl.trim()) {
        delete copy[slugKey];
      } else {
        copy[slugKey] = customUrl.trim();
      }
      return copy;
    });
  };

  const handleClearAllOverrides = () => {
    if (confirm("Are you sure you want to clear all manual country redirects and revert to auto-detection?")) {
      setCountryRedirectsMap({});
      setCustomModeMap({});
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSaving(true);

    try {
      // Build payload containing updated country_redirects_map
      const payload = [
        { key: "country_redirects_map", value: JSON.stringify(countryRedirectsMap) },
      ];

      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorMsg = await getApiErrorMessage(response);
        throw new Error(errorMsg);
      }

      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2500);
      router.refresh();
    } catch (err: any) {
      alert(err.message || "Failed to save country redirects");
    } finally {
      setIsSaving(false);
    }
  };

  // Helper to determine if target is custom URL
  const isCustomUrl = (target: string) => {
    if (!target || target === "none" || target === "auto") return false;
    const lower = target.toLowerCase();
    return !guideSlugsSet.has(lower);
  };

  // Filtered country list
  const filteredCountries = useMemo(() => {
    return countries.filter((c) => {
      const matchesSearch =
        c.name.toLowerCase().includes(redirectSearch.toLowerCase()) ||
        c.slug.toLowerCase().includes(redirectSearch.toLowerCase());

      if (!matchesSearch) return false;

      const slugKey = c.slug.toLowerCase();
      const manualVal = countryRedirectsMap[slugKey];
      const autoSlug = autoGuideMap[slugKey] || autoGuideMap[c.name.toLowerCase()];

      if (filterMode === "overridden") return Boolean(manualVal);
      if (filterMode === "auto") return !manualVal && Boolean(autoSlug);
      if (filterMode === "custom") return Boolean(manualVal && isCustomUrl(manualVal));
      if (filterMode === "default") return !manualVal && !autoSlug;
      return true;
    });
  }, [countries, redirectSearch, filterMode, countryRedirectsMap, autoGuideMap, guideSlugsSet]);

  // Statistics
  const overriddenCount = Object.keys(countryRedirectsMap).length;
  const customUrlCount = Object.values(countryRedirectsMap).filter((val) => isCustomUrl(val)).length;
  const autoMatchedCount = countries.filter(
    (c) => !countryRedirectsMap[c.slug.toLowerCase()] && (autoGuideMap[c.slug.toLowerCase()] || autoGuideMap[c.name.toLowerCase()])
  ).length;

  return (
    <div className="space-y-6 text-xs font-bold text-navy">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-border-custom p-6 rounded-3xl shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Globe className="w-6 h-6 text-blue shrink-0" />
            <h1 className="font-sora font-black text-navy text-2xl">Country Redirect Manager</h1>
          </div>
          <p className="text-slate-500 text-xs font-medium mt-1">
            Configure custom destination redirects, travel guide overrides, or auto-matched destination pages for all country URLs.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {overriddenCount > 0 && (
            <button
              type="button"
              onClick={handleClearAllOverrides}
              className="px-3.5 py-2.5 bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" /> Reset Overrides
            </button>
          )}

          <button
            type="button"
            onClick={() => handleSave()}
            disabled={isSaving}
            className={`btn-primary py-2.5 px-5 font-black flex items-center gap-2 text-xs rounded-xl shadow-md transition-all ${
              isSaved ? "bg-green-500 hover:bg-green-600 border-green-500 text-white" : ""
            }`}
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : isSaved ? (
              <Check className="w-4 h-4" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {isSaved ? "Saved Successfully!" : "Save Changes"}
          </button>
        </div>
      </div>

      {/* Stat Badges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm">
          <div className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Total Countries</div>
          <div className="text-navy font-black text-2xl mt-1">{countries.length}</div>
        </div>

        <div className="bg-white border border-green-200 bg-green-50/50 p-4 rounded-2xl shadow-sm">
          <div className="text-green-600 text-[10px] font-bold uppercase tracking-wider">Auto-Matched Guides</div>
          <div className="text-green-700 font-black text-2xl mt-1">{autoMatchedCount}</div>
        </div>

        <div className="bg-white border border-blue-200 bg-blue-50/50 p-4 rounded-2xl shadow-sm">
          <div className="text-blue text-[10px] font-bold uppercase tracking-wider">Manual Overrides</div>
          <div className="text-blue font-black text-2xl mt-1">{overriddenCount}</div>
        </div>

        <div className="bg-white border border-purple-200 bg-purple-50/50 p-4 rounded-2xl shadow-sm">
          <div className="text-purple-600 text-[10px] font-bold uppercase tracking-wider">Custom URLs</div>
          <div className="text-purple-700 font-black text-2xl mt-1">{customUrlCount}</div>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-white border border-border-custom rounded-3xl p-6 shadow-sm space-y-5">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search country name or slug (e.g. Albania, /countries/albania)..."
              value={redirectSearch}
              onChange={(e) => setRedirectSearch(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold text-navy outline-none focus:border-blue transition-all"
            />
          </div>

          <select
            value={filterMode}
            onChange={(e) => setFilterMode(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-bold text-navy outline-none focus:border-blue shrink-0 cursor-pointer"
          >
            <option value="all">All Countries ({countries.length})</option>
            <option value="overridden">Manual Overrides ({overriddenCount})</option>
            <option value="custom">Custom URLs ({customUrlCount})</option>
            <option value="auto">Auto-Matched Guides ({autoMatchedCount})</option>
            <option value="default">Default Template</option>
          </select>
        </div>

        {/* Country Redirect Table */}
        <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm bg-white">
          <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
            <table className="w-full text-left text-xs font-bold border-collapse">
              <thead className="sticky top-0 bg-slate-100 border-b border-slate-200 text-slate-500 uppercase text-[10px] z-10">
                <tr>
                  <th className="py-3.5 px-4 w-[28%]">Country Page</th>
                  <th className="py-3.5 px-4 w-[22%]">Auto-Detected Target</th>
                  <th className="py-3.5 px-4 w-[36%]">Redirect Destination</th>
                  <th className="py-3.5 px-4 text-right w-[14%]">Status & Preview</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCountries.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-12 text-center text-slate-400 text-xs font-bold">
                      No countries matched your search criteria.
                    </td>
                  </tr>
                ) : (
                  filteredCountries.map((c) => {
                    const slugKey = c.slug.toLowerCase();
                    const manualTarget = countryRedirectsMap[slugKey] || "";
                    const autoGuideSlug = autoGuideMap[slugKey] || autoGuideMap[c.name.toLowerCase()];
                    const hasManual = Boolean(manualTarget);
                    const isCustom = isCustomUrl(manualTarget);
                    const isExplicitCustomMode = customModeMap[slugKey] || isCustom;

                    // Calculate effective preview URL
                    let previewUrl = `/countries/${c.slug}`;
                    if (manualTarget === "none") {
                      previewUrl = `/countries/${c.slug}`;
                    } else if (manualTarget) {
                      if (manualTarget.startsWith("/") || manualTarget.startsWith("http://") || manualTarget.startsWith("https://")) {
                        previewUrl = manualTarget;
                      } else {
                        previewUrl = `/${manualTarget}`;
                      }
                    } else if (autoGuideSlug) {
                      previewUrl = `/${autoGuideSlug}`;
                    }

                    // Select box value calculation
                    let selectValue = manualTarget;
                    if (isExplicitCustomMode) {
                      selectValue = "custom";
                    } else if (!hasManual) {
                      selectValue = "";
                    }

                    return (
                      <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Country Info */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl shrink-0 leading-none">{c.flag || "🌐"}</span>
                            <div className="min-w-0">
                              <div className="text-navy font-bold truncate">{c.name}</div>
                              <div className="text-[10px] text-slate-400 font-mono font-medium truncate">
                                /countries/{c.slug}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Auto-Detected Target */}
                        <td className="py-3.5 px-4">
                          {autoGuideSlug ? (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-green-50 text-green-700 border border-green-200 rounded-lg text-[10px] font-mono max-w-full">
                              <Sparkles className="w-3 h-3 text-green-500 shrink-0" />
                              <span className="truncate max-w-[160px]">/{autoGuideSlug}</span>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-medium">
                              None (Default Template)
                            </span>
                          )}
                        </td>

                        {/* Redirect Destination Selector & Custom Input */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-2 max-w-full">
                            <select
                              value={selectValue}
                              onChange={(e) => handleRedirectSelectChange(c.slug, e.target.value)}
                              className={`w-full border rounded-xl px-3 py-1.5 text-xs font-mono font-bold outline-none transition-all truncate max-w-full cursor-pointer ${
                                isCustom
                                  ? "bg-purple-50/70 border-purple-300 text-purple-800"
                                  : hasManual
                                  ? "bg-blue/5 border-blue text-blue"
                                  : "bg-slate-50 border-slate-200 text-slate-700 focus:border-blue"
                              }`}
                            >
                              <option value="">⚡ Auto-Detect (Default Rule)</option>
                              <option value="none">🚫 Disable Redirect (Stay on Country Page)</option>
                              <option value="custom">✏️ Custom URL / Path...</option>

                              <optgroup label="Know More Travel Guides & CMS Pages">
                                {travelGuides.map((guide) => (
                                  <option key={guide.slug} value={`/${guide.slug}`}>
                                    /{guide.slug} ({guide.title})
                                  </option>
                                ))}
                              </optgroup>
                            </select>

                            {/* Custom URL Input Field */}
                            {isExplicitCustomMode && (
                              <div className="flex items-center gap-1.5 animate-fade-in">
                                <div className="relative flex-1">
                                  <Edit3 className="w-3.5 h-3.5 text-purple-500 absolute left-2.5 top-2" />
                                  <input
                                    type="text"
                                    placeholder="Enter custom path (e.g. /custom-guide or https://...)"
                                    value={manualTarget === "custom" || manualTarget === "none" ? "" : manualTarget}
                                    onChange={(e) => handleCustomUrlInputChange(c.slug, e.target.value)}
                                    className="w-full bg-purple-50/40 border border-purple-200 rounded-xl pl-8 pr-3 py-1.5 text-xs font-mono font-bold text-purple-900 outline-none focus:border-purple-500 transition-all placeholder:text-purple-300 placeholder:font-sans"
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        </td>

                        {/* Status Badge & Preview Button */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex flex-col items-end gap-1.5">
                            {isCustom ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-800 rounded-md text-[9px] font-black uppercase tracking-wide">
                                <LinkIcon className="w-3 h-3 text-purple-600" /> Custom URL
                              </span>
                            ) : hasManual ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue text-white rounded-md text-[9px] font-black uppercase tracking-wide">
                                <LinkIcon className="w-3 h-3" /> Guide Override
                              </span>
                            ) : autoGuideSlug ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-800 rounded-md text-[9px] font-black uppercase tracking-wide">
                                <CheckCircle className="w-3 h-3 text-green-600" /> Auto Guide
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-500 rounded-md text-[9px] font-black uppercase tracking-wide">
                                Default
                              </span>
                            )}

                            {/* Live Preview Button */}
                            <a
                              href={previewUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] text-blue hover:text-blue-dark font-bold hover:underline py-0.5 px-1 rounded transition-colors"
                              title={`Preview destination: ${previewUrl}`}
                            >
                              <span>Preview</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
