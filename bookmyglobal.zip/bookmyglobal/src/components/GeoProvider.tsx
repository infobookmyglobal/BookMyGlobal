'use client';

import { useGeo } from '@/hooks/useGeo';

/**
 * GeoProvider — drop this inside the root layout <body>.
 * It triggers geo detection on mount and populates the geoStore.
 * Renders nothing visible.
 */
export function GeoProvider({ children }: { children: React.ReactNode }) {
  useGeo();
  return <>{children}</>;
}
