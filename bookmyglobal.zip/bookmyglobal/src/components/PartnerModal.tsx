"use client";

import React, { useState } from "react";
import { X, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

interface PartnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PartnerModal({ isOpen, onClose }: PartnerModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !address) {
      setErrorMessage("All fields are required.");
      setStatus("error");
      return;
    }

    setStatus("submitting");
    setErrorMessage("");

    try {
      const res = await fetch("/api/partner/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, address }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Something went wrong.");
      }

      setStatus("success");
      setName("");
      setEmail("");
      setPhone("");
      setAddress("");
    } catch (err: any) {
      setStatus("error");
      setErrorMessage(err.message || "Failed to submit partner application.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop overlay */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative w-full max-w-2xl overflow-y-auto md:overflow-hidden rounded-3xl bg-white shadow-2xl transition-all border border-slate-100 flex flex-col md:flex-row max-h-[90vh]">
        {/* Close Button */}
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-950/40 hover:bg-slate-950/60 text-white md:bg-slate-100 md:hover:bg-slate-200 md:text-slate-500 md:hover:text-slate-700 transition-colors z-20"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left Side: Benefits (Navy Gradient) */}
        <div className="bg-[#001A66] p-8 text-white md:w-1/2 flex flex-col justify-between relative overflow-hidden shrink-0">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="relative z-10 space-y-6">
            <div>
              <span className="inline-block bg-white/10 text-white/90 text-[10px] font-black tracking-widest uppercase px-3 py-1 rounded-full mb-3">
                Partner Program
              </span>
              <h3 className="font-sora text-xl md:text-2xl font-black leading-tight">
                Grow Your Business With Us
              </h3>
            </div>

            <p className="text-white/70 text-xs leading-relaxed">
              Join our exclusive network of travel agencies, booking platforms, and content creators. 
              Help your clients acquire their International Driving Permits hassle-free.
            </p>

            <ul className="space-y-4 pt-2">
              <li className="flex items-start gap-3">
                <span className="text-[#FFD700] text-sm mt-0.5">✦</span>
                <div>
                  <h4 className="font-bold text-xs text-[#FFD700]">Earn Commissions</h4>
                  <p className="text-[11px] text-white/70 leading-normal">
                    Receive payouts for every successful application referred through your platform.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-[#FFD700] text-sm mt-0.5">✦</span>
                <div>
                  <h4 className="font-bold text-xs text-[#FFD700]">Custom Discount Coupons</h4>
                  <p className="text-[11px] text-white/70 leading-normal">
                    Provide your audience or clients with tailored codes to make their permit cheaper.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-[#FFD700] text-sm mt-0.5">✦</span>
                <div>
                  <h4 className="font-bold text-xs text-[#FFD700]">Dedicated Dashboard</h4>
                  <p className="text-[11px] text-white/70 leading-normal">
                    Monitor referral clicks, conversions, commission balances, and payouts in real-time.
                  </p>
                </div>
              </li>
            </ul>
          </div>

          <div className="text-[10px] text-white/40 pt-6 relative z-10 border-t border-white/10 mt-6">
            BookMyGlobal © {new Date().getFullYear()}
          </div>
        </div>

        {/* Right Side: Form (White Background) */}
        <div className="p-8 md:w-1/2 flex flex-col justify-between md:overflow-y-auto shrink-0 relative">

          {status === "success" ? (
            <div className="my-auto text-center space-y-4 py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mb-2">
                <CheckCircle className="w-10 h-10" />
              </div>
              <h3 className="font-sora text-lg font-black text-navy">Application Submitted!</h3>
              <p className="text-slate-500 text-xs leading-relaxed">
                Thank you for applying. Our admin team will review your details. 
                If approved, we will send an email with your credentials to login and access your referral dashboard.
              </p>
              <button
                onClick={onClose}
                className="w-full bg-[#0033CC] hover:bg-[#001A66] text-white font-bold text-xs py-3 rounded-xl transition-all shadow-md mt-4"
              >
                Close
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <h3 className="font-sora text-lg font-black text-navy">Apply as Partner</h3>
                <p className="text-slate-400 text-[11px]">Submit your contact details to request partner access.</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3.5">
                {status === "error" && (
                  <div className="p-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-xl text-xs flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div>
                  <label className="block text-slate-500 font-bold text-[10px] uppercase mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    disabled={status === "submitting"}
                    className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0033CC] focus:border-[#0033CC] transition-all bg-slate-50/50 disabled:opacity-60"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-bold text-[10px] uppercase mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="john@example.com"
                    disabled={status === "submitting"}
                    className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0033CC] focus:border-[#0033CC] transition-all bg-slate-50/50 disabled:opacity-60"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-bold text-[10px] uppercase mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (555) 019-2834"
                    disabled={status === "submitting"}
                    className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0033CC] focus:border-[#0033CC] transition-all bg-slate-50/50 disabled:opacity-60"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-bold text-[10px] uppercase mb-1">Physical Address</label>
                  <textarea
                    required
                    rows={2}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="123 Travel Way, Suite 400..."
                    disabled={status === "submitting"}
                    className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#0033CC] focus:border-[#0033CC] transition-all bg-slate-50/50 resize-none disabled:opacity-60"
                  />
                </div>

                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="w-full bg-[#0033CC] hover:bg-[#001A66] text-white font-bold text-xs py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-4 disabled:opacity-75 disabled:cursor-not-allowed cursor-pointer"
                >
                  {status === "submitting" ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <span>Submit Partner Request</span>
                  )}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
