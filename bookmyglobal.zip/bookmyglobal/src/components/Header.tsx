"use client";

import { useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Menu, X, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/Logo";
import { DesktopAuth, MobileAuth } from "@/components/header/AuthenticatedActions";

const QrScannerModal = dynamic(() => import("@/components/header/QrScannerModal"), { ssr: false });

export const NAV_LINKS = [
  { href: "/#services", label: "Services" },
  { href: "/#how-it-works", label: "How it works" },
  { href: "/#yoga", label: "Yoga Tourism" },
  { href: "/#community", label: "Community" },
  { href: "/blog", label: "Blog" },
  { href: "/#faq", label: "FAQ" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 bg-navy/95 backdrop-blur border-b border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
          <Logo />

          <nav className="hidden lg:flex items-center gap-6">
            {NAV_LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="text-sm font-bold text-white/70 hover:text-white transition-colors">
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => setQrOpen(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-white/80 hover:text-white transition-colors"
            >
              <ShieldCheck className="w-4 h-4" /> Verify IDP
            </button>
            <DesktopAuth />
            <Link href="/contact" className="bg-green hover:bg-green/90 text-white text-xs font-black rounded-full px-5 py-2.5 transition-colors">
              Get in touch
            </Link>
          </div>

          <button className="md:hidden text-white p-2" onClick={() => setMobileOpen((v) => !v)} aria-label="Toggle menu">
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t border-white/10 bg-navy px-4 py-4 flex flex-col gap-3">
            {NAV_LINKS.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setMobileOpen(false)} className="text-sm font-bold text-white/80 py-1.5">
                {l.label}
              </Link>
            ))}
            <button
              onClick={() => { setMobileOpen(false); setQrOpen(true); }}
              className="text-left text-sm font-bold text-white/80 py-1.5"
            >
              Verify an IDP
            </button>
            <MobileAuth onCloseMobile={() => setMobileOpen(false)} />
            <Link href="/contact" onClick={() => setMobileOpen(false)} className="text-center font-black text-white bg-green rounded-full py-3 text-sm">
              Get in touch
            </Link>
          </div>
        )}
      </header>
      {qrOpen && <QrScannerModal isOpen={qrOpen} onClose={() => setQrOpen(false)} />}
    </>
  );
}
