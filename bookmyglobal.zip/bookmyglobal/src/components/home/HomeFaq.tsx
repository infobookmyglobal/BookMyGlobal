"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export function HomeFaq({ items }: { items: { q: string; a: string }[] }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="space-y-3">
      {items.map((f, i) => {
        const isOpen = open === i;
        return (
          <div key={f.q} className="bg-white border border-border-custom rounded-2xl overflow-hidden">
            <button
              onClick={() => setOpen(isOpen ? null : i)}
              aria-expanded={isOpen}
              className="w-full flex items-center justify-between gap-4 text-left px-5 py-4"
            >
              <span className="font-sora font-bold text-navy text-sm sm:text-base">{f.q}</span>
              <ChevronDown className={`w-5 h-5 shrink-0 text-blue transition-transform ${isOpen ? "rotate-180" : ""}`} />
            </button>
            {isOpen && <p className="px-5 pb-5 text-sm text-muted-custom leading-relaxed">{f.a}</p>}
          </div>
        );
      })}
    </div>
  );
}
