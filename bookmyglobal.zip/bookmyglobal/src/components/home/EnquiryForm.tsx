"use client";

import { useState } from "react";
import { CheckCircle2 } from "lucide-react";

export const ENQUIRY_TYPES: { value: string; label: string }[] = [
  { value: "GENERAL", label: "General question" },
  { value: "FLIGHT", label: "Flight booking" },
  { value: "HOTEL", label: "Hotel booking" },
  { value: "TOURS", label: "Tours & activities" },
  { value: "CRUISE", label: "Cruise travel" },
  { value: "BUS", label: "International bus booking" },
  { value: "ATTESTATION", label: "MEA & embassy attestation (India)" },
  { value: "VISA", label: "Visa assistance (India)" },
  { value: "RETREAT", label: "Yoga retreat" },
  { value: "COMMUNITY", label: "Traveler community" },
];

const input =
  "w-full rounded-xl border border-border-custom bg-white px-4 py-3 text-sm text-navy placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue/30 focus:border-blue";

export function EnquiryForm({ defaultType = "GENERAL" }: { defaultType?: string }) {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setState("sending");
    setError("");
    try {
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.fromEntries(fd.entries())),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "Something went wrong");
      }
      setState("done");
    } catch (err: any) {
      setError(err.message);
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="text-center py-12">
        <CheckCircle2 className="w-12 h-12 text-green mx-auto" />
        <h3 className="mt-4 font-sora font-extrabold text-navy text-xl">Thanks — we've got it</h3>
        <p className="mt-2 text-sm text-muted-custom">Our team will reply to your email shortly.</p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <input name="name" required minLength={2} placeholder="Your name" className={input} />
        <input name="email" type="email" required placeholder="Email address" className={input} />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <input name="phone" placeholder="Phone / WhatsApp (optional)" className={input} />
        <select name="type" defaultValue={defaultType} className={input}>
          {ENQUIRY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
      </div>
      <textarea name="message" required minLength={5} rows={5} placeholder="Tell us where you're headed and what you need" className={input} />
      {/* honeypot: hidden from people, bots fill it */}
      <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      {state === "error" && <p className="text-sm text-red-600 font-bold">{error}</p>}
      <button
        type="submit"
        disabled={state === "sending"}
        className="bg-green hover:bg-green/90 disabled:opacity-60 text-white font-black text-sm rounded-full px-8 py-3.5 transition-colors"
      >
        {state === "sending" ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
