"use client";

import React, { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { Calendar, Clock, ArrowRight, BookOpen, Search, X, Sparkles, User } from "lucide-react";
import { format } from "date-fns";
import { getBlogAuthor } from "@/lib/utils";

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  featuredImageUrl: string | null;
  category: string | null;
  tags: string;
  status: string;
  publishedAt: string | Date | null;
  createdAt: string | Date;
  updatedAt: string | Date;
}

interface BlogClientPageProps {
  initialBlogs: BlogPost[];
}

function getReadTime(content: string): string {
  const wordsPerMinute = 225;
  const noOfWords = content.split(/\s+/).length;
  const minutes = Math.ceil(noOfWords / wordsPerMinute);
  return `${minutes} min read`;
}

export function BlogClientPage({ initialBlogs }: BlogClientPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  // Dynamically calculate category counts based on initial list
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: initialBlogs.length };
    initialBlogs.forEach((b) => {
      if (b.category) {
        counts[b.category] = (counts[b.category] || 0) + 1;
      }
    });
    return counts;
  }, [initialBlogs]);

  // Distinct list of categories
  const categories = useMemo(() => {
    const cats = Array.from(new Set(initialBlogs.map((b) => b.category).filter(Boolean)));
    return ["All", ...cats];
  }, [initialBlogs]);

  // Filtered posts based on search query and active category
  const filteredBlogs = useMemo(() => {
    return initialBlogs.filter((post) => {
      const matchesCategory = activeCategory === "All" || post.category === activeCategory;
      const matchesSearch =
        !searchQuery.trim() ||
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (post.excerpt && post.excerpt.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (post.category && post.category.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (post.tags && post.tags.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [initialBlogs, activeCategory, searchQuery]);

  const isFilterActive = activeCategory !== "All" || searchQuery.trim() !== "";

  // Original layout split
  const featuredPost = filteredBlogs[0];
  const remainingPosts = filteredBlogs.slice(1);

  return (
    <div className="py-12 px-4 max-w-7xl mx-auto w-full space-y-10">
      {/* Search & Filter Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-slate-50 p-6 rounded-3xl border border-slate-200/60 shadow-sm">
        {/* Search Input */}
        <div className="relative w-full md:max-w-md">
          <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5" />
          </span>
          <input
            type="text"
            placeholder="Search guides, rules, road tips..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-10 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-medium text-navy placeholder-slate-400 outline-none focus:border-blue focus:ring-4 focus:ring-blue/5 transition-all shadow-sm"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-navy transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Categories Horizontal Scroll */}
        <div className="w-full md:w-auto overflow-x-auto scrollbar-none flex gap-2 pb-1 md:pb-0 justify-start">
          {categories.map((cat) => {
            const count = categoryCounts[cat || ""] || 0;
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat || "All")}
                className={`shrink-0 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isActive
                    ? "bg-blue text-white shadow-md shadow-blue/10"
                    : "bg-white hover:bg-slate-100 text-slate-600 hover:text-navy border border-slate-200/50"
                }`}
              >
                {cat}
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    isActive ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid Content */}
      {filteredBlogs.length === 0 ? (
        <div className="text-center py-20 bg-slate-50 rounded-3xl border border-dashed border-slate-200 max-w-md mx-auto">
          <BookOpen className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h2 className="font-sora font-black text-navy text-xl mb-2">No Matching Guides</h2>
          <p className="text-sm text-slate-500 mb-6">
            We couldn't find any driving guides matching your query. Try updating your filters or search terms.
          </p>
          <button
            onClick={() => {
              setSearchQuery("");
              setActiveCategory("All");
            }}
            className="px-6 py-3 bg-blue text-white text-xs font-black rounded-xl hover:bg-blue-600 transition-colors shadow-md"
          >
            Clear Filters
          </button>
        </div>
      ) : isFilterActive ? (
        // Render simple grid list when filter is active
        <section className="space-y-8">
          <h3 className="font-sora font-black text-navy text-2xl border-b border-slate-100 pb-4">
            Search Results ({filteredBlogs.length})
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBlogs.map((post) => (
              <BlogCard key={post.id} post={post} />
            ))}
          </div>
        </section>
      ) : (
        // Original layout (Featured + Grid) when no search/filter is active
        <div className="space-y-16">
          {featuredPost && (
            <section className="group relative bg-white border border-border-custom rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 grid md:grid-cols-2 gap-0">
              <div className="relative min-h-[300px] md:min-h-[450px]">
                {featuredPost.featuredImageUrl ? (
                  <Image
                    src={featuredPost.featuredImageUrl}
                    alt={featuredPost.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    priority
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                ) : (
                  <div className="absolute inset-0 bg-navy flex items-center justify-center text-white">
                    <BookOpen className="w-20 h-20 opacity-30" />
                  </div>
                )}
                {featuredPost.category && (
                  <span className="absolute top-4 left-4 bg-blue text-white text-xs font-black uppercase tracking-wider px-3 py-1 rounded-lg">
                    {featuredPost.category}
                  </span>
                )}
              </div>

              <div className="p-8 md:p-12 flex flex-col justify-center space-y-4">
                <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-muted">
                  <span className="flex items-center gap-1 text-blue font-black">
                    <User className="w-3.5 h-3.5" />
                    By {getBlogAuthor(featuredPost.slug)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {format(new Date(featuredPost.publishedAt || featuredPost.createdAt), "dd MMM yyyy")}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {getReadTime(featuredPost.content)}
                  </span>
                </div>

                <h2 className="font-sora font-black text-navy text-2xl md:text-4xl leading-tight group-hover:text-blue transition-colors">
                  <Link href={`/blog/${featuredPost.slug}`}>{featuredPost.title}</Link>
                </h2>

                <p className="text-muted text-base leading-relaxed">
                  {featuredPost.excerpt ||
                    "Discover the full roadmap to planning your perfect driving trip abroad with complete peace of mind."}
                </p>

                <div className="pt-4">
                  <Link
                    href={`/blog/${featuredPost.slug}`}
                    className="inline-flex items-center gap-2 text-blue font-black hover:text-navy transition-colors group-hover:translate-x-1 duration-200"
                  >
                    Read Full Article <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </section>
          )}

          {remainingPosts.length > 0 && (
            <section className="space-y-8">
              <h3 className="font-sora font-black text-navy text-2xl border-b border-slate-100 pb-4">
                Latest Driving Resources
              </h3>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {remainingPosts.map((post) => (
                  <BlogCard key={post.id} post={post} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}

function BlogCard({ post }: { post: BlogPost }) {
  return (
    <article className="group flex flex-col bg-white border border-border-custom rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300">
      <div className="relative aspect-video">
        {post.featuredImageUrl ? (
          <Image
            src={post.featuredImageUrl}
            alt={post.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />
        ) : (
          <div className="absolute inset-0 bg-navy/10 flex items-center justify-center text-navy">
            <BookOpen className="w-12 h-12 opacity-30" />
          </div>
        )}
        {post.category && (
          <span className="absolute top-3 left-3 bg-navy text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded">
            {post.category}
          </span>
        )}
      </div>

      <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-3 text-[10px] font-bold text-muted uppercase">
            <span className="flex items-center gap-1 text-blue font-black">
              <User className="w-3 h-3" />
              By {getBlogAuthor(post.slug)}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {format(new Date(post.publishedAt || post.createdAt), "dd MMM yyyy")}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {getReadTime(post.content)}
            </span>
          </div>

          <h4 className="font-sora font-black text-navy text-lg leading-snug group-hover:text-blue transition-colors">
            <Link href={`/blog/${post.slug}`}>{post.title}</Link>
          </h4>

          <p className="text-muted text-xs leading-relaxed line-clamp-3">
            {post.excerpt ||
              "Read more about driving rules and safety tips to ensure you drive lawfully in international destinations."}
          </p>
        </div>

        <div className="pt-2">
          <Link
            href={`/blog/${post.slug}`}
            className="inline-flex items-center gap-1 text-xs font-black text-blue hover:text-navy transition-colors group-hover:translate-x-1 duration-200"
          >
            Read Article <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </article>
  );
}
