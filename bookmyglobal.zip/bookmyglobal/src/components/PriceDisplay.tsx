"use client";

import { useEffect, useState } from "react";
import { useCurrency } from "@/hooks/useCurrency";

interface PriceDisplayProps {
  usd: number;
  className?: string;
}

export function PriceDisplay({ usd, className }: PriceDisplayProps) {
  const [mounted, setMounted] = useState(false);
  const { format } = useCurrency();

  useEffect(() => {
    setMounted(false);
    setMounted(true);
  }, []);

  if (!mounted) {
    // Return standard USD symbol on initial server render to match HTML structure and avoid hydration issues
    return <span className={className}>${usd}</span>;
  }

  return <span className={className}>{format(usd)}</span>;
}
