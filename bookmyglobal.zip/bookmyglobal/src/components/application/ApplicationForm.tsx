"use client";
import { WHATSAPP_URL } from "@/lib/contact";

import { useState, useEffect, useMemo } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import Script from "next/script";
import { useCartStore } from "@/store/cartStore";
import { useGeoStore } from "@/store/geoStore";
import { Check, ChevronRight, ShieldCheck, HelpCircle, ArrowRight, ArrowLeft, MapPin } from "lucide-react";
import { SearchableCountrySelect } from "./SearchableCountrySelect";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "");

// Pricing Configs
const USD_PRICES = {
  DIGITAL: { 1: 21, 2: 26, 3: 32 },
  NFC_KIT: { 1: 32, 2: 37, 3: 42 },
} as const;

const INR_PRICES = {
  DIGITAL: { 1: 1999, 2: 2499, 3: 2999 },
  NFC_KIT: { 1: 2999, 2: 3499, 3: 3999 },
} as const;

const FALLBACK_COUNTRIES = [
  { name: "India", flag: "🇮🇳" },
  { name: "Belize", flag: "🇧🇿" },
  { name: "United States", flag: "🇺🇸" },
  { name: "United Kingdom", flag: "🇬🇧" },
  { name: "Canada", flag: "🇨🇦" },
  { name: "Australia", flag: "🇦🇺" },
  { name: "Germany", flag: "🇩🇪" },
  { name: "France", flag: "🇫🇷" },
  { name: "Spain", flag: "🇪🇸" },
  { name: "United Arab Emirates", flag: "🇦🇪" },
  { name: "Thailand", flag: "🇹🇭" },
  { name: "Singapore", flag: "🇸🇬" },
  { name: "Malaysia", flag: "🇲🇾" },
  { name: "Indonesia", flag: "🇮🇩" },
  { name: "Saudi Arabia", flag: "🇸🇦" },
  { name: "Qatar", flag: "🇶🇦" },
  { name: "Oman", flag: "🇴🇲" },
  { name: "Kuwait", flag: "🇰🇼" },
  { name: "Bahrain", flag: "🇧🇭" },
  { name: "Sri Lanka", flag: "🇱🇰" },
  { name: "Nepal", flag: "🇳🇵" },
  { name: "Bangladesh", flag: "🇧🇩" },
];

const LICENSE_CLASSES = [
  { code: "A", label: "A — Motorcycle", desc: "Two-wheelers, scooters" },
  { code: "B", label: "B — Car", desc: "Passenger car, up to 8 seats" },
  { code: "C", label: "C — Truck", desc: "Vehicle over 3500 kg" },
  { code: "D", label: "D — Bus", desc: "Vehicle over 8 seats" },
  { code: "E", label: "E — Trailer", desc: "Vehicle with trailer" },
];

const PHONE_CODES = [
  { code: "+91", country: "IN", flag: "🇮🇳" },
  { code: "+1", country: "US/CA", flag: "🇺🇸" },
  { code: "+44", country: "UK", flag: "🇬🇧" },
  { code: "+61", country: "AU", flag: "🇦🇺" },
  { code: "+971", country: "AE", flag: "🇦🇪" },
  { code: "+66", country: "TH", flag: "🇹🇭" },
  { code: "+65", country: "SG", flag: "🇸🇬" },
  { code: "+966", country: "SA", flag: "🇸🇦" },
  { code: "+33", country: "FR", flag: "🇫🇷" },
  { code: "+49", country: "DE", flag: "🇩🇪" },
  { code: "+34", country: "ES", flag: "🇪🇸" },
];

// Zod schemas
const personalSchema = z.object({
  email: z.string().email("Invalid email address"),
  phoneCode: z.string().min(1, "Phone code is required"),
  phone: z.string().min(7, "Phone number is too short"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  parentName: z.string().min(1, "Parent / Guardian name is required"),
  dob: z.string().refine((d) => {
    const date = new Date(d);
    const today = new Date();
    const age = today.getFullYear() - date.getFullYear();
    return age >= 18;
  }, "You must be at least 18 years old"),
  sex: z.string().min(1, "Sex is required"),
  countryOfBirth: z.string().min(1, "Country of birth is required"),
  countryOfResidence: z.string().min(1, "Country of residence is required"),
  licenseNumber: z.string().min(1, "License number is required"),
  licenseClass: z.array(z.string()).min(1, "Select at least one vehicle category"),
  
  // License Address
  licenseStreetAddress: z.string().min(1, "License street address is required"),
  licenseCity: z.string().min(1, "License city is required"),
  licenseState: z.string().min(1, "License state is required"),
  licenseZipCode: z.string().min(1, "License zip code is required"),
  licenseCountry: z.string().min(1, "License country is required"),

  // Shipping details
  streetAddress: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  shippingCountry: z.string().optional(),
});

type PersonalForm = z.infer<typeof personalSchema>;

// ── STEP INDICATOR ─────────────────────────────────────────────────────────
function StepIndicator({ current }: { current: number }) {
  return (
    <div className="flex items-center justify-center gap-1.5 sm:gap-4 mb-8">
      {/* Step 1 */}
      <div className="flex items-center gap-1 sm:gap-2">
        <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-[10px] sm:text-xs transition-all ${
          current > 0 ? "bg-[#22c55e] text-white" : current === 0 ? "bg-blue text-white ring-4 ring-blue/20" : "bg-slate-200 text-slate-500"
        }`}>
          {current > 0 ? "✓" : "1"}
        </div>
        <span className={`text-[10px] sm:text-xs font-black ${current === 0 ? "text-navy" : "text-slate-400"}`}>Start</span>
      </div>

      <div className={`w-4 sm:w-12 h-0.5 transition-all ${current > 0 ? "bg-[#22c55e]" : "bg-slate-200"}`} />

      {/* Step 2 */}
      <div className="flex items-center gap-1 sm:gap-2">
        <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-[10px] sm:text-xs transition-all ${
          current > 1 ? "bg-[#22c55e] text-white" : current === 1 ? "bg-blue text-white ring-4 ring-blue/20" : "bg-slate-200 text-slate-500"
        }`}>
          {current > 1 ? "✓" : "2"}
        </div>
        <span className={`text-[10px] sm:text-xs font-black ${current === 1 ? "text-navy" : "text-slate-400"}`}>Driver Info</span>
      </div>

      <div className={`w-4 sm:w-12 h-0.5 transition-all ${current > 1 ? "bg-[#22c55e]" : "bg-slate-200"}`} />

      {/* Step 3 */}
      <div className="flex items-center gap-1 sm:gap-2">
        <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-[10px] sm:text-xs transition-all ${
          current === 2 ? "bg-blue text-white ring-4 ring-blue/20" : "bg-slate-200 text-slate-500"
        }`}>
          3
        </div>
        <span className={`text-[10px] sm:text-xs font-black ${current === 2 ? "text-navy" : "text-slate-400"}`}>Payment</span>
      </div>
    </div>
  );
}

// ── MINI HEADER ────────────────────────────────────────────────────────────
function MiniHeader() {
  return (
    <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-blue rounded-lg flex items-center justify-center text-white font-bold text-lg">B</div>
        <span className="font-sora font-black text-xs text-navy leading-tight">
          BookMy<br /><span className="text-blue">Global</span>
        </span>
      </div>
      <div className="flex items-center gap-1.5 bg-green-50 border border-green-200 px-3 py-1 rounded-full text-[10px] font-black text-green-700">
        <span className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />
        24/7 Support
      </div>
    </div>
  );
}

// ── STEP 1: START ──────────────────────────────────────────────────────────
function Step1({
  countries,
  onNext,
  issuingCountry,
  setIssuingCountry,
  destinationCountry,
  setDestinationCountry,
  usdPrices,
}: {
  countries: any[];
  onNext: () => void;
  issuingCountry: string;
  setIssuingCountry: (c: string) => void;
  destinationCountry: string;
  setDestinationCountry: (c: string) => void;
  usdPrices: {
    DIGITAL: { 1: number; 2: number; 3: number };
    NFC_KIT: { 1: number; 2: number; 3: number };
  };
}) {
  const { productType, validity, setProduct, setValidity, discount, setAmounts, currency, setCoupon } = useCartStore();
  const [couponInput, setCouponInput] = useState("");
  const [couponStatus, setCouponStatus] = useState<"idle" | "valid" | "invalid">("idle");
  const [couponMsg, setCouponMsg] = useState("");

  const currentYear = new Date().getFullYear();

  // Set default product and validity on mount if not set
  useEffect(() => {
    if (!productType) setProduct("NFC_KIT");
    if (!validity) setValidity(1);
  }, []);

  const [isOtherIssuing, setIsOtherIssuing] = useState(false);
  const [customIssuing, setCustomIssuing] = useState("");
  const [isOtherDest, setIsOtherDest] = useState(false);
  const [customDest, setCustomDest] = useState("");

  // Sync with prop updates / localStorage initial values
  useEffect(() => {
    if (countries.length > 0) {
      if (issuingCountry) {
        const inList = countries.some(c => c.name === issuingCountry);
        if (!inList && issuingCountry !== "Other") {
          setIsOtherIssuing(true);
          setCustomIssuing(issuingCountry);
        }
      }
      if (destinationCountry) {
        const inList = countries.some(c => c.name === destinationCountry);
        if (!inList && destinationCountry !== "Other") {
          setIsOtherDest(true);
          setCustomDest(destinationCountry);
        }
      }
    }
  }, [countries]);

  const { currency: geoCurrency, nativeCurrency, nativeSymbol, exchangeRates, country } = useGeoStore();

  const localCurrency = (nativeCurrency && nativeCurrency !== "USD") ? nativeCurrency : "INR";
  const localSymbol = localCurrency === "INR" ? "₹" : (nativeSymbol || localCurrency);
  const localCountryCode = localCurrency === "INR" ? "IN" : (country && country !== "US" ? country : "");

  const getDynamicPrice = (product: "DIGITAL" | "NFC_KIT", years: 1 | 2 | 3, curr: string) => {
    const usdPrice = usdPrices[product][years];
    if (curr === "USD") return usdPrice;
    if (curr === "INR") {
      if (product === "DIGITAL") {
        if (years === 1) return Math.round(usdPrice * 95.19);
        if (years === 2) return Math.round(usdPrice * 96.11);
        if (years === 3) return Math.round(usdPrice * 93.71);
      } else {
        if (years === 1) return Math.round(usdPrice * 93.71);
        if (years === 2) return Math.round(usdPrice * 94.56);
        if (years === 3) return Math.round(usdPrice * 95.21);
      }
    }
    if (exchangeRates && exchangeRates[curr]) {
      return Math.ceil(usdPrice * exchangeRates[curr]);
    }
    return usdPrice;
  };

  const activeProduct = productType || "NFC_KIT";
  const activeValidity = validity || 1;
  const basePrice = getDynamicPrice(activeProduct, activeValidity, currency);
  const finalPrice = Math.max(0, basePrice - discount);

  // Sync cart store amount whenever items / validity / discount / currency change
  useEffect(() => {
    setAmounts(basePrice, finalPrice, currency);
  }, [productType, validity, discount, currency, basePrice, finalPrice]);

  // Synchronize cart store currency with geoStore's currency on mount or when geoCurrency changes
  useEffect(() => {
    if (geoCurrency && geoCurrency !== currency) {
      const newBase = getDynamicPrice(activeProduct, activeValidity, geoCurrency);
      const newFinal = Math.max(0, newBase - discount);
      setAmounts(newBase, newFinal, geoCurrency);
    }
  }, [geoCurrency]);

  const handleCurrencyChange = (newCurrency: string) => {
    setCoupon(null, 0); // Reset coupon to avoid conflicts
    setCouponStatus("idle");
    setCouponMsg("");
    setCouponInput("");

    // Determine symbol for newCurrency
    let newSymbol = "$";
    if (newCurrency === "USD") {
      newSymbol = "$";
    } else if (newCurrency === localCurrency) {
      newSymbol = localSymbol;
    } else if (newCurrency === "INR") {
      newSymbol = "₹";
    } else if (exchangeRates && exchangeRates[newCurrency]) {
      newSymbol = newCurrency;
    }

    // Update geo store currency and symbol
    useGeoStore.getState().setGeo({ currency: newCurrency, symbol: newSymbol });

    // Update cart store currency and amounts
    const newBase = getDynamicPrice(activeProduct, activeValidity, newCurrency);
    const newFinal = Math.max(0, newBase - discount);
    setAmounts(newBase, newFinal, newCurrency);
  };

  const applyCoupon = async () => {
    if (!couponInput.trim()) return;
    const res = await fetch(`/api/coupons/validate?code=${couponInput}`);
    const data = await res.json();
    if (data.valid) {
      const disc = data.discountType === "PERCENT" ? (basePrice * data.discountValue) / 100 : data.discountValue;
      setCoupon(couponInput.toUpperCase(), disc);
      setCouponStatus("valid");
      const sym = currency === "INR" ? "₹" : (currency === "USD" ? "$" : (currency === localCurrency ? localSymbol : currency));
      setCouponMsg(`Coupon applied! ${data.discountType === "PERCENT" ? data.discountValue + "% off" : sym + data.discountValue + " off"}`);
    } else {
      setCoupon(null, 0);
      setCouponStatus("invalid");
      setCouponMsg(data.error || "Invalid coupon");
    }
  };

  const destCountryObj = countries.find((c) => c.name === destinationCountry);
  const requiresPhysical = destCountryObj?.requiresPhysical || false;

  // Dynamically calculate allowed validity years for the destination country
  const allowedYears = useMemo<number[]>(() => {
    if (destCountryObj?.validityYears) {
      try {
        const parsed = JSON.parse(destCountryObj.validityYears);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error("Error parsing validityYears:", e);
      }
    }
    return [1, 2, 3];
  }, [destCountryObj]);

  // Adjust validity choice if the new country doesn't support the current selection
  useEffect(() => {
    if (destCountryObj && !allowedYears.includes(activeValidity)) {
      setValidity(allowedYears[0] as 1 | 2 | 3);
    }
  }, [destCountryObj, allowedYears, activeValidity, setValidity]);

  // Auto-select NFC_KIT (Print + Digital) if country requires physical
  useEffect(() => {
    if (requiresPhysical && activeProduct !== "NFC_KIT") {
      setProduct("NFC_KIT");
    }
  }, [requiresPhysical, activeProduct, setProduct]);

  return (
    <div className="space-y-6">
      {/* Order Summary Box */}
      <div className="bg-[#fef8e6] border border-[#f5dca0] rounded-2xl px-5 py-3 flex items-center justify-between text-sm font-bold text-navy">
        <div className="space-y-0.5">
          <div className="text-xs font-black text-muted uppercase">Order Summary</div>
          <div>{activeValidity} Year — {activeProduct === "NFC_KIT" ? "Print + Digital IDP" : "Digital IDP Only"}</div>
        </div>
        <div className="text-lg font-black text-blue">
          {currency === "INR" ? "₹" : (currency === "USD" ? "$" : (currency === localCurrency ? localSymbol : currency))}{finalPrice}
        </div>
      </div>

      {/* Currency & Region Selector */}
      <div className="flex gap-2 justify-center bg-slate-100 p-1 rounded-xl max-w-[240px] mx-auto">
        <button
          type="button"
          onClick={() => handleCurrencyChange("USD")}
          className={`flex-1 py-1.5 rounded-lg text-sm font-black transition-colors uppercase ${
            currency === "USD" ? "bg-white text-navy shadow-sm" : "text-muted hover:text-navy"
          }`}
        >
          US USD ($)
        </button>
        <button
          type="button"
          onClick={() => handleCurrencyChange(localCurrency)}
          className={`flex-1 py-1.5 rounded-lg text-sm font-black transition-colors uppercase ${
            currency === localCurrency ? "bg-white text-navy shadow-sm" : "text-muted hover:text-navy"
          }`}
        >
          <span className="flex items-center justify-center gap-1"><MapPin className="w-3.5 h-3.5" /> {localCountryCode} {localCurrency} ({localSymbol})</span>
        </button>
      </div>

      <div className="space-y-4">
        <h2 className="font-sora font-black text-navy text-xl text-center">Start Your Application</h2>
        <p className="text-muted text-sm text-center max-w-sm mx-auto">Apply online, get verified in minutes, and receive your permit wherever you are.</p>
      </div>

      {/* Issuing Country — Searchable */}
      <div>
        <label className="block text-xs font-black text-navy uppercase tracking-wider mb-1.5">Which country issued your license?</label>
        <SearchableCountrySelect
          value={issuingCountry}
          onChange={(val) => setIssuingCountry(val)}
          countries={countries}
          placeholder="Search issuing country…"
        />
      </div>

      {/* Destination Country — Searchable */}
      <div>
        <label className="block text-xs font-black text-navy uppercase tracking-wider mb-1.5">Select Destination Country</label>
        <SearchableCountrySelect
          value={destinationCountry}
          onChange={(val) => setDestinationCountry(val)}
          countries={countries}
          placeholder="Search destination country…"
        />
      </div>

      {/* Country Specific Travel Regulation Alert */}
      {destCountryObj && (
        <div className={`p-5 rounded-2xl border text-sm space-y-2 transition-all duration-300 ${
          destCountryObj.alertColor === "green"
            ? "bg-emerald-50/70 border-emerald-200 text-emerald-950"
            : destCountryObj.alertColor === "blue"
            ? "bg-blue-50/70 border-blue-200 text-blue-950"
            : destCountryObj.alertColor === "orange"
            ? "bg-amber-50/70 border-amber-200 text-amber-950"
            : "bg-slate-100/70 border-slate-300 text-slate-900"
        }`}>
          <div className="flex items-start gap-2.5">
            <span className="text-lg leading-none mt-0.5">
              {destCountryObj.alertColor === "green" ? "✅" :
               destCountryObj.alertColor === "blue" ? "ℹ️" :
               destCountryObj.alertColor === "orange" ? "⚠️" : "🚫"}
            </span>
            <div className="space-y-1.5">
              <h4 className="font-bold text-base leading-snug">
                {destCountryObj.websiteTitle || `${destinationCountry} Requirements`}
              </h4>
              <p className="font-medium text-xs leading-relaxed opacity-90">
                {destCountryObj.websiteMessage}
              </p>
              {destCountryObj.dualConventionLine && (
                <div className="text-[11px] font-bold opacity-80 pt-1 border-t border-current/10">
                  {destCountryObj.dualConventionLine}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Permit Validity Selector */}
      <div>
        <label className="block text-xs font-black text-navy uppercase tracking-wider mb-1.5">Permit Validity</label>
        <div className="grid grid-cols-3 gap-3">
          {([1, 2, 3] as const).map((yr) => {
            const isAllowed = allowedYears.includes(yr);
            return (
              <button
                key={yr}
                type="button"
                disabled={!isAllowed}
                onClick={() => setValidity(yr)}
                className={`border-2 rounded-xl p-4 text-center font-sora font-black transition-all ${
                  !isAllowed
                    ? "opacity-40 cursor-not-allowed border-slate-100 bg-slate-50 text-slate-400"
                    : activeValidity === yr
                    ? "border-blue bg-blue/5 text-blue ring-2 ring-blue/10"
                    : "border-border-custom hover:border-blue text-navy bg-white"
                }`}
              >
                <div className="text-xl">{yr} Year{yr > 1 ? "s" : ""}</div>
                <div className="text-xs text-muted mt-0.5">
                  {isAllowed ? `expires ${currentYear + yr}` : "Not accepted"}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Permit Type Selector */}
      <div>
        <label className="block text-xs font-black text-navy uppercase tracking-wider mb-3">Choose Your Permit Type</label>
        <div className="grid md:grid-cols-2 gap-4">
          {/* NFC Kit */}
          <div
            onClick={() => setProduct("NFC_KIT")}
            className={`border-2 rounded-2xl p-5 cursor-pointer relative transition-all bg-white ${
              activeProduct === "NFC_KIT" ? "border-blue bg-blue/5 shadow-lg" : "border-border-custom hover:border-blue/50"
            }`}
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-navy text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-sm">
              ⭐ Best Value
            </div>
            <div className="flex items-center justify-between mb-3 mt-2">
              <span className="font-sora font-black text-navy text-base">NFC Smart Kit — Print + Digital</span>
              <span className="font-sora font-black text-blue text-lg">
                {currency === "INR" ? "₹" : (currency === "USD" ? "$" : (currency === localCurrency ? localSymbol : currency))}{getDynamicPrice("NFC_KIT", activeValidity as 1 | 2 | 3, currency)}
              </span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-600">
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> Physical NFC card + IDP Booklet</li>
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> {requiresPhysical ? `Required for ${destinationCountry}` : "Required for countries requiring physical copy"}</li>
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> NFC Tap to Verify - Live QR Code</li>
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> Instant digital + physical kit in 7–15 days</li>
            </ul>
          </div>

          {/* Digital Only */}
          <div
            onClick={() => {
              if (requiresPhysical) {
                alert(`${destinationCountry} requires a physical permit. We highly recommend selecting the NFC Smart Kit.`);
              }
              setProduct("DIGITAL");
            }}
            className={`border-2 rounded-2xl p-5 cursor-pointer transition-all bg-white ${
              activeProduct === "DIGITAL" ? "border-blue bg-blue/5 shadow-lg" : "border-border-custom hover:border-blue/50"
            }`}
          >
            <div className="flex items-center justify-between mb-3 mt-2">
              <span className="font-sora font-black text-navy text-base">Digital IDP Only</span>
              <span className="font-sora font-black text-blue text-lg">
                {currency === "INR" ? "₹" : (currency === "USD" ? "$" : (currency === localCurrency ? localSymbol : currency))}{getDynamicPrice("DIGITAL", activeValidity as 1 | 2 | 3, currency)}
              </span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-600">
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> Instant email delivery</li>
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> Digital IDP booklet (multiple languages)</li>
              <li className="flex items-center gap-1.5"><Check className="w-3.5 h-3.5 text-green shrink-0" /> Digital English ID card included</li>
              <li className="flex items-center gap-1.5 text-red-500 font-bold"><Check className="w-3.5 h-3.5 text-red-500 shrink-0" /> {requiresPhysical ? `⚠️ Not valid alone in ${destinationCountry}` : "⚠️ Not valid alone in physical-only countries"}</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Coupon Field */}
      <div>
        <label className="block text-xs font-black text-navy uppercase tracking-wider mb-1.5">Coupon Code</label>
        <div className="flex gap-2">
          <input
            value={couponInput}
            onChange={(e) => { setCouponInput(e.target.value.toUpperCase()); setCouponStatus("idle"); }}
            placeholder="Enter coupon code..."
            className="flex-1 border border-border-custom rounded-xl px-4 py-2.5 text-sm font-bold outline-none focus:border-blue"
          />
          <button onClick={applyCoupon} className="btn-secondary px-5 py-2 text-sm">Apply</button>
        </div>
        {couponStatus === "valid" && <p className="text-green-600 text-xs font-bold mt-1.5">✓ {couponMsg}</p>}
        {couponStatus === "invalid" && <p className="text-red-500 text-xs font-bold mt-1.5">✗ {couponMsg}</p>}
      </div>

      {/* Submit Button */}
      <button
        onClick={onNext}
        className="btn-primary w-full py-4 text-base font-black flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
      >
        Continue <ChevronRight className="w-4 h-4" />
      </button>

      {/* Trust & Badges */}
      <div className="border-t border-slate-100 pt-6 space-y-4">
        <div className="grid grid-cols-3 gap-2 text-center text-navy font-sora font-black">
          <div>
            <div className="text-base text-blue">189+</div>
            <div className="text-[9px] text-muted uppercase">Countries Covered</div>
          </div>
          <div>
            <div className="text-base text-blue">8min</div>
            <div className="text-[9px] text-muted uppercase">Application Time</div>
          </div>
          <div>
            <div className="text-base text-blue">3yr</div>
            <div className="text-[9px] text-muted uppercase">Max Validity</div>
          </div>
        </div>

        {/* Brand Logos mock */}
        <div className="flex items-center justify-center gap-3 opacity-60 grayscale hover:grayscale-0 transition-all py-1.5 border-y border-slate-100 text-[10px] font-black text-slate-500">
          <span>Enterprise</span><span>|</span><span>Hertz</span><span>|</span><span>Avis</span><span>|</span><span>Budget</span><span>|</span><span>Sixt</span>
        </div>

        {/* Security badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-[9px] font-bold text-muted">
          <span className="bg-slate-150 px-2 py-1 rounded shrink-0">🔒 SSL Secure</span>
          <span className="bg-slate-150 px-2 py-1 rounded shrink-0">🛡️ GDPR</span>
          <span className="bg-slate-150 px-2 py-1 rounded shrink-0">💳 PCI DSS</span>
          <span className="bg-slate-150 px-2 py-1 rounded shrink-0">⭐ 50K+ Drivers</span>
        </div>
      </div>
    </div>
  );
}

// ── STEP 2: DRIVER INFO ────────────────────────────────────────────────────
function Step2({
  countries,
  onNext,
  onBack,
  savedData,
}: {
  countries: any[];
  onNext: (data: PersonalForm) => void;
  onBack: () => void;
  savedData?: Partial<PersonalForm>;
}) {
  const { productType } = useCartStore();
  const { register, handleSubmit, setValue, watch, control, formState: { errors } } = useForm<PersonalForm>({
    resolver: zodResolver(personalSchema),
    defaultValues: {
      phoneCode: "+91",
      sex: "Male",
      licenseClass: ["B"],
      ...savedData,
    },
  });

  const watchSex = watch("sex");
  const watchLicenseClass = watch("licenseClass") || [];
  const watchPhoneCode = watch("phoneCode");

  const [sameAsLicense, setSameAsLicense] = useState(() => {
    if (savedData) {
      return (
        savedData.streetAddress === savedData.licenseStreetAddress &&
        savedData.city === savedData.licenseCity &&
        savedData.state === savedData.licenseState &&
        savedData.zipCode === savedData.licenseZipCode &&
        savedData.shippingCountry === savedData.licenseCountry &&
        !!savedData.licenseStreetAddress
      );
    }
    return false;
  });

  const watchLicenseStreet = watch("licenseStreetAddress");
  const watchLicenseCity = watch("licenseCity");
  const watchLicenseState = watch("licenseState");
  const watchLicenseZip = watch("licenseZipCode");
  const watchLicenseCountry = watch("licenseCountry");

  useEffect(() => {
    if (sameAsLicense) {
      setValue("streetAddress", watchLicenseStreet || "");
      setValue("city", watchLicenseCity || "");
      setValue("state", watchLicenseState || "");
      setValue("zipCode", watchLicenseZip || "");
      setValue("shippingCountry", watchLicenseCountry || "");
    }
  }, [
    sameAsLicense,
    watchLicenseStreet,
    watchLicenseCity,
    watchLicenseState,
    watchLicenseZip,
    watchLicenseCountry,
    setValue,
  ]);

  const handleClassToggle = (code: string) => {
    const current = [...watchLicenseClass];
    const index = current.indexOf(code);
    if (index > -1) {
      if (current.length > 1) {
        current.splice(index, 1);
      }
    } else {
      current.push(code);
    }
    setValue("licenseClass", current);
  };

  const onSubmitForm = (data: PersonalForm) => {
    // If NFC Kit, shipping details are required
    if (productType === "NFC_KIT") {
      if (!data.streetAddress || !data.city || !data.state || !data.zipCode || !data.shippingCountry) {
        alert("Please complete all shipping address fields for the NFC Smart Kit delivery.");
        return;
      }
    }
    onNext(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmitForm)} className="space-y-5">
      <div className="space-y-1">
        <h2 className="font-sora font-black text-navy text-xl">Driver Information</h2>
        <p className="text-muted text-xs">Make sure information matches your driver&apos;s license exactly.</p>
      </div>

      {/* Email */}
      <div>
        <label className="block text-[10px] font-black text-navy uppercase mb-1">Email Address *</label>
        <input
          {...register("email")}
          type="email"
          placeholder="your.email@example.com"
          className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
        />
        <p className="text-[10px] text-muted mt-1">* Your digital IDP and login credentials will be sent here.</p>
        {errors.email && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.email.message}</p>}
      </div>

      {/* Phone with custom code selector */}
      <div>
        <label className="block text-[10px] font-black text-navy uppercase mb-1">Mobile / WhatsApp *</label>
        <div className="flex gap-2">
          <select
            {...register("phoneCode")}
            className="border border-border-custom rounded-xl px-3 py-2.5 text-xs font-bold text-navy outline-none bg-white focus:border-blue"
          >
            {PHONE_CODES.map((p) => (
              <option key={p.code} value={p.code}>
                {p.flag} {p.code}
              </option>
            ))}
          </select>
          <input
            {...register("phone")}
            type="tel"
            placeholder=""
            className="flex-1 border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
          />
        </div>
        <p className="text-[10px] text-muted mt-1">For delivery updates and WhatsApp support.</p>
        {errors.phone && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.phone.message}</p>}
      </div>

      {/* Name Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">First Name *</label>
          <input
            {...register("firstName")}
            placeholder=""
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
          />
          {errors.firstName && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.firstName.message}</p>}
        </div>
        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Last Name *</label>
          <input
            {...register("lastName")}
            placeholder=""
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
          />
          {errors.lastName && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.lastName.message}</p>}
        </div>
      </div>

      {/* Parent Name */}
      <div>
        <label className="block text-[10px] font-black text-navy uppercase mb-1">Parent / Guardian Name *</label>
        <input
          {...register("parentName")}
          placeholder="As required for official IDP records"
          className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
        />
        {errors.parentName && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.parentName.message}</p>}
      </div>

      {/* DOB & Sex */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Date of Birth *</label>
          <input
            {...register("dob")}
            type="date"
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
          />
          {errors.dob && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.dob.message}</p>}
        </div>

        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Sex *</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { value: "Male", label: "👨 Male" },
              { value: "Female", label: "👩 Female" },
              { value: "Other", label: "⚧ Other" },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setValue("sex", opt.value)}
                className={`border rounded-xl py-2.5 text-center font-bold text-xs transition-all ${
                  watchSex === opt.value
                    ? "border-blue bg-blue/5 text-blue ring-2 ring-blue/10"
                    : "border-border-custom hover:border-blue text-navy bg-white"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Birth & Residence Country — Searchable */}
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Country of Birth *</label>
          <Controller
            name="countryOfBirth"
            control={control}
            render={({ field }) => (
              <SearchableCountrySelect
                value={field.value || ""}
                onChange={field.onChange}
                countries={countries}
                placeholder="Search country…"
                compact
              />
            )}
          />
          {errors.countryOfBirth && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.countryOfBirth.message}</p>}
        </div>

        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Country of Residence *</label>
          <Controller
            name="countryOfResidence"
            control={control}
            render={({ field }) => (
              <SearchableCountrySelect
                value={field.value || ""}
                onChange={field.onChange}
                countries={countries}
                placeholder="Search country…"
                compact
              />
            )}
          />
          {errors.countryOfResidence && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.countryOfResidence.message}</p>}
        </div>
      </div>

      {/* License Number */}
      <div>
        <label className="block text-[10px] font-black text-navy uppercase mb-1">Local License Number *</label>
        <input
          {...register("licenseNumber")}
          placeholder="e.g. DL-0420110012345"
          className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
        />
        {errors.licenseNumber && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseNumber.message}</p>}
      </div>

      {/* License Class Category */}
      <div>
        <label className="block text-[10px] font-black text-navy uppercase mb-2">License Class / Vehicle Category *</label>
        <div className="space-y-2">
          {LICENSE_CLASSES.map((cls) => {
            const isChecked = watchLicenseClass.includes(cls.code);
            return (
              <div
                key={cls.code}
                onClick={() => handleClassToggle(cls.code)}
                className={`border rounded-xl p-3 flex items-center justify-between cursor-pointer transition-all bg-white ${
                  isChecked ? "border-blue bg-blue/5 shadow-sm" : "border-border-custom hover:border-blue/50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 border rounded flex items-center justify-center transition-all ${
                    isChecked ? "bg-blue border-blue text-white" : "border-slate-350"
                  }`}>
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-navy">{cls.label}</div>
                    <div className="text-[10px] text-muted">{cls.desc}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        {errors.licenseClass && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseClass.message}</p>}
      </div>

      {/* License Address Section */}
      <div className="border-t border-slate-100 pt-6 mt-6 space-y-4">
        <div className="space-y-1">
          <h3 className="font-sora font-black text-navy text-sm uppercase">🏠 License Address</h3>
          <p className="text-muted text-[10px]">Address printed on your local driver&apos;s license.</p>
        </div>

        <div>
          <label className="block text-[10px] font-black text-navy uppercase mb-1">Street Address *</label>
          <input
            {...register("licenseStreetAddress")}
            placeholder="Enter license street address"
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
          />
          {errors.licenseStreetAddress && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseStreetAddress.message}</p>}
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-navy uppercase mb-1">City *</label>
            <input
              {...register("licenseCity")}
              placeholder="Enter city"
              className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
            />
            {errors.licenseCity && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseCity.message}</p>}
          </div>
          <div>
            <label className="block text-[10px] font-black text-navy uppercase mb-1">State / Province *</label>
            <input
              {...register("licenseState")}
              placeholder="Enter state / province"
              className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
            />
            {errors.licenseState && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseState.message}</p>}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-navy uppercase mb-1">Pin / Zip Code *</label>
            <input
              {...register("licenseZipCode")}
              placeholder="Enter PIN / ZIP Code"
              className="w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue"
            />
            {errors.licenseZipCode && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseZipCode.message}</p>}
          </div>
          <div>
            <label className="block text-[10px] font-black text-navy uppercase mb-1">Country *</label>
            <Controller
              name="licenseCountry"
              control={control}
              render={({ field }) => (
                <SearchableCountrySelect
                  value={field.value || ""}
                  onChange={field.onChange}
                  countries={countries}
                  placeholder="Search country…"
                  compact
                />
              )}
            />
            {errors.licenseCountry && <p className="text-red-500 text-[10px] font-bold mt-1">{errors.licenseCountry.message}</p>}
          </div>
        </div>
      </div>

      {/* Shipping Address Section */}
      {productType === "NFC_KIT" && (
        <div className="border-t border-slate-100 pt-6 mt-6 space-y-4">
          <div className="space-y-1">
            <h3 className="font-sora font-black text-navy text-sm uppercase">📦 Shipping Address</h3>
            <p className="text-muted text-[10px]">Where should we send your physical NFC Smart Kit?</p>
            <label className="flex items-center gap-2 text-[11px] font-bold text-navy cursor-pointer mt-2">
              <input
                type="checkbox"
                checked={sameAsLicense}
                onChange={(e) => setSameAsLicense(e.target.checked)}
                className="rounded border-border-custom text-blue focus:ring-blue h-3.5 w-3.5 cursor-pointer"
              />
              <span>Same as license address</span>
            </label>
          </div>

          <div>
            <label className="block text-[10px] font-black text-navy uppercase mb-1">Street Address *</label>
            <input
              {...register("streetAddress")}
              placeholder="Enter street address"
              readOnly={sameAsLicense}
              className={`w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue ${
                sameAsLicense ? "bg-slate-50 text-slate-500 cursor-not-allowed" : ""
              }`}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black text-navy uppercase mb-1">City *</label>
              <input
                {...register("city")}
                placeholder="Enter city"
                readOnly={sameAsLicense}
                className={`w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue ${
                  sameAsLicense ? "bg-slate-50 text-slate-500 cursor-not-allowed" : ""
                }`}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-navy uppercase mb-1">State / Province *</label>
              <input
                {...register("state")}
                placeholder="Enter state / province"
                readOnly={sameAsLicense}
                className={`w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue ${
                  sameAsLicense ? "bg-slate-50 text-slate-500 cursor-not-allowed" : ""
                }`}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black text-navy uppercase mb-1">Pin / Zip Code *</label>
              <input
                {...register("zipCode")}
                placeholder="Enter PIN / ZIP Code"
                readOnly={sameAsLicense}
                className={`w-full border border-border-custom rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue ${
                  sameAsLicense ? "bg-slate-50 text-slate-500 cursor-not-allowed" : ""
                }`}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-navy uppercase mb-1">Country *</label>
              <Controller
                name="shippingCountry"
                control={control}
                render={({ field }) => (
                  <SearchableCountrySelect
                    value={field.value || ""}
                    onChange={field.onChange}
                    countries={countries}
                    placeholder="Search country…"
                    compact
                    disabled={sameAsLicense}
                  />
                )}
              />
              {errors.shippingCountry && (
                <p className="text-red-500 text-[10px] font-bold mt-1">{errors.shippingCountry.message}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Info notice */}
      <div className="bg-[#f0f4ff] border border-blue/10 rounded-xl p-4 text-[11px] text-slate-700 leading-relaxed font-medium">
        📷 <strong>Document Upload Notice:</strong> Upload your driving license (front & back) and a profile photo after payment via your success portal. No upload needed right now — credentials will be emailed after payment.
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3 pt-4">
        <button
          type="button"
          onClick={onBack}
          className="order-2 sm:order-1 border border-border-custom rounded-xl py-3 px-6 font-bold text-xs text-muted hover:border-blue hover:text-blue transition-all"
        >
          ← Back
        </button>
        <button
          type="submit"
          className="order-1 sm:order-2 flex-1 btn-primary py-3.5 text-xs font-black flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
        >
          Continue to Payment <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </form>
  );
}

function StripePaymentForm({
  clientSecret,
  finalAmount,
  currency,
  paymentLoading,
  setPaymentLoading,
  buildApplicationData,
  onNext,
  setError,
}: {
  clientSecret: string;
  finalAmount: number;
  currency: string;
  paymentLoading: boolean;
  setPaymentLoading: (loading: boolean) => void;
  buildApplicationData: () => any;
  onNext: (appId: string) => void;
  setError: (err: string | null) => void;
}) {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setPaymentLoading(true);
    setError(null);

    try {
      const { error: submitError } = await elements.submit();
      if (submitError) {
        setError(submitError.message || "Payment submission failed");
        setPaymentLoading(false);
        return;
      }

      const result = await stripe.confirmPayment({
        elements,
        redirect: "if_required",
      });

      if (result.error) {
        setError(result.error.message || "Stripe payment failed");
        setPaymentLoading(false);
      } else if (result.paymentIntent && result.paymentIntent.status === "succeeded") {
        const confirmRes = await fetch("/api/payments/stripe/confirm", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            paymentIntentId: result.paymentIntent.id,
            applicationData: buildApplicationData(),
          }),
        });

        const confirmData = await confirmRes.json();
        if (!confirmRes.ok || !confirmData.success) {
          throw new Error(confirmData.error || "Failed to confirm payment on server");
        }

        onNext(confirmData.applicationId);
      } else {
        setError("Payment status unconfirmed");
        setPaymentLoading(false);
      }
    } catch (err: any) {
      setError(err.message || "Payment processing failed");
      setPaymentLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement
        options={{
          layout: "tabs",
          wallets: {
            applePay: "auto",
            googlePay: "auto",
          },
        }}
      />
      <button
        type="submit"
        disabled={!stripe || paymentLoading}
        className="w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60 text-white shadow-md cursor-pointer"
        style={{ background: "linear-gradient(135deg, #635bff 0%, #4b45e4 100%)" }}
      >
        {paymentLoading ? (
          <>
            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            Processing Stripe Payment...
          </>
        ) : (
          <>
            <span>💳</span>
            Pay {currency === "INR" ? "₹" : "$"}{finalAmount} via Stripe (Apple Pay / Card)
          </>
        )}
      </button>
    </form>
  );
}

// ── STEP 3: PAYMENT ────────────────────────────────────────────────────────
function Step3({
  onNext,
  onBack,
  personalData,
  issuingCountry,
  destinationCountry,
  usdPrices,
}: {
  onNext: (applicationId: string) => void;
  onBack: () => void;
  personalData: PersonalForm;
  issuingCountry: string;
  destinationCountry: string;
  usdPrices: {
    DIGITAL: { 1: number; 2: number; 3: number };
    NFC_KIT: { 1: number; 2: number; 3: number };
  };
}) {
  const { productType, validity, finalAmount, baseAmount, discount, couponCode, currency } = useCartStore();
  const { exchangeRates } = useGeoStore();

  const activeProduct = productType || "NFC_KIT";
  const activeValidity = validity || 1;

  const getDynamicPrice = (product: "DIGITAL" | "NFC_KIT", years: 1 | 2 | 3, curr: string) => {
    const usdPrice = usdPrices[product][years];
    if (curr === "USD") return usdPrice;
    if (curr === "INR") {
      if (product === "DIGITAL") {
        if (years === 1) return Math.round(usdPrice * 95.19);
        if (years === 2) return Math.round(usdPrice * 96.11);
        if (years === 3) return Math.round(usdPrice * 93.71);
      } else {
        if (years === 1) return Math.round(usdPrice * 93.71);
        if (years === 2) return Math.round(usdPrice * 94.56);
        if (years === 3) return Math.round(usdPrice * 95.21);
      }
    }
    if (exchangeRates && exchangeRates[curr]) {
      return Math.ceil(usdPrice * exchangeRates[curr]);
    }
    return usdPrice;
  };
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const buildApplicationData = () => {
    // Format license address (residential)
    const licenseAddress = `${personalData.licenseStreetAddress}, ${personalData.licenseCity}, ${personalData.licenseState} ${personalData.licenseZipCode}, ${personalData.licenseCountry}`;

    // Format shipping address if NFC Smart Kit is ordered
    let notes = `Categories: ${personalData.licenseClass.join(", ")} | Parent/Guardian: ${personalData.parentName || "None"}`;
    if (productType === "NFC_KIT" && personalData.streetAddress) {
      const shippingAddress = `${personalData.streetAddress}, ${personalData.city}, ${personalData.state} ${personalData.zipCode}, ${personalData.shippingCountry}`;
      notes += ` | SHIPPING ADDRESS: ${shippingAddress}`;
    }

    const name = `${personalData.firstName} ${personalData.lastName || ""}`.trim();
    const phone = `${personalData.phoneCode}${personalData.phone}`;

    return {
      productType: productType!,
      validity: validity!,
      fullName: name,
      email: personalData.email,
      phone: phone,
      dob: personalData.dob || undefined,
      country: issuingCountry,
      address: licenseAddress,
      destinationCountry: destinationCountry,
      licenseNumber: personalData.licenseNumber || undefined,
      gender: personalData.sex,
      countryOfBirth: personalData.countryOfBirth,
      countryOfResidence: personalData.countryOfResidence,
      licenseClass: personalData.licenseClass.join(", "),
      parentName: personalData.parentName || undefined,
      currency,
      baseAmount,
      finalAmount,
      couponCode: couponCode ?? undefined,
      discountAmount: discount,
      adminNotes: notes,
    };
  };

  const handleRazorpay = async () => {
    setPaymentLoading(true);
    setError(null);
    try {
      const createRes = await fetch("/api/payments/razorpay/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productType, validity, currency, discountAmount: discount }),
      });
      if (!createRes.ok) {
        const errorData = await createRes.json().catch(() => ({}));
        throw new Error(errorData.error || "Payment creation failed");
      }
      const { orderId, amount, keyId, currency: gatewayCurrency } = await createRes.json();

      const options = {
        key: keyId,
        amount: amount * 100,
        currency: gatewayCurrency || currency,
        name: "BookMyGlobal",
        description: `IDP — ${productType === "NFC_KIT" ? "NFC Smart Kit" : "Digital IDP"}`,
        order_id: orderId,
        handler: async (response: { razorpay_payment_id: string; razorpay_order_id: string; razorpay_signature: string }) => {
          setPaymentLoading(true);
          try {
            const verifyRes = await fetch("/api/payments/razorpay/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ ...response, applicationData: buildApplicationData() }),
            });
            const result = await verifyRes.json();
            if (result.success) {
              onNext(result.applicationId);
            } else {
              setError(result.error || "Payment verification failed");
            }
          } catch (err: any) {
            setError(err.message || "Payment verification failed");
          } finally {
            setPaymentLoading(false);
          }
        },
        theme: { color: "#0033CC" },
      };

      const Razorpay = (window as any).Razorpay;
      new Razorpay(options).open();
    } catch (err: any) {
      setError(err.message || "Payment initialization failed");
    } finally {
      setPaymentLoading(false);
    }
  };

  const [stripeClientSecret, setStripeClientSecret] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const stripeCurrency = currency === "INR" ? "USD" : currency;
    const usdBase = getDynamicPrice(activeProduct, activeValidity, "USD");
    const stripeAmount = currency === "INR" ? Math.max(0.5, usdBase - discount) : finalAmount;

    fetch("/api/payments/stripe/create-intent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: stripeAmount,
        currency: stripeCurrency,
        email: personalData.email,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (isMounted && data.clientSecret) {
          setStripeClientSecret(data.clientSecret);
        }
      })
      .catch((err) => {
        console.error("Failed to initialize Stripe PaymentIntent:", err);
      });

    return () => {
      isMounted = false;
    };
  }, [finalAmount, currency, discount, activeProduct, activeValidity, personalData.email]);

  const applicantName = `${personalData.firstName} ${personalData.lastName || ""}`.trim();

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h2 className="font-sora font-black text-navy text-xl">Complete Payment</h2>
        <p className="text-muted text-xs">Review your order and proceed to secure payment.</p>
      </div>

      {/* Review Details Card */}
      <div className="bg-bg-custom rounded-2xl border border-border-custom p-5">
        <h3 className="font-sora font-black text-navy mb-4 text-xs uppercase tracking-wider">Order Summary</h3>
        <div className="space-y-3 text-xs">
          <div className="flex justify-between pb-2 border-b border-dashed border-slate-200">
            <span className="text-muted">Product</span>
            <span className="font-bold text-navy">{productType === "NFC_KIT" ? "NFC Smart Kit — Print + Digital IDP" : "Digital IDP Only"}</span>
          </div>
          <div className="flex justify-between pb-2 border-b border-dashed border-slate-200">
            <span className="text-muted">Validity</span>
            <span className="font-bold text-navy">{validity} Year{validity! > 1 ? "s" : ""}</span>
          </div>
          <div className="flex justify-between pb-2 border-b border-dashed border-slate-200">
            <span className="text-muted">Destination</span>
            <span className="font-bold text-navy">{destinationCountry}</span>
          </div>
          <div className="flex justify-between pb-2 border-b border-dashed border-slate-200">
            <span className="text-muted">Applicant</span>
            <span className="font-bold text-navy">{applicantName}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-green-600 pb-2 border-b border-dashed border-slate-200">
              <span>Discount</span>
              <span>-{currency === "INR" ? "₹" : "$"}{discount}</span>
            </div>
          )}
          <div className="flex justify-between text-base font-black pt-3 text-navy">
            <span>Total</span>
            <span className="text-blue">{currency === "INR" ? "₹" : "$"}{finalAmount} {currency}</span>
          </div>
        </div>
      </div>

      {/* Success banner */}
      <div className="flex items-center gap-2.5 bg-green-50 border border-green-200 rounded-xl p-3 text-[11px] text-green-800 font-bold">
        <Check className="w-4 h-4 text-green-600 shrink-0" />
        <span>Login credentials will be sent to {personalData.email}</span>
      </div>

      {error && <p className="text-red-500 text-xs font-bold bg-red-50 border border-red-200 rounded-xl p-3">{error}</p>}

      {/* Pay buttons — Razorpay & Stripe */}
      <div className="space-y-4 pt-2">

        {/* UPI / Cards label */}
        <p className="text-[10px] font-black text-muted text-center uppercase tracking-widest">Choose Payment Method</p>

        {/* ── Razorpay ── */}
        <div className="border border-border-custom rounded-2xl p-4 space-y-3 bg-white">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-black text-navy uppercase tracking-wider">💳 UPI / Net Banking / India Cards</span>
            <div className="flex gap-1 ml-auto text-[9px] font-bold text-slate-400">
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">UPI</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">GPay</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">NetBanking</span>
            </div>
          </div>
          {currency === "INR" && (
            <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400 bg-slate-50 rounded-lg px-3 py-1.5">
              <span>PhonePe</span><span>·</span><span>Paytm</span><span>·</span><span>Google Pay</span><span>·</span><span>BHIM</span>
            </div>
          )}
          <button
            onClick={handleRazorpay}
            disabled={paymentLoading}
            className="w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60"
            style={{ background: "linear-gradient(135deg, #0d55fb 0%, #1a75ff 100%)", color: "#fff" }}
          >
            {paymentLoading ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <span>🔒</span>
                Pay {currency === "INR" ? "₹" : "$"}{finalAmount} via Razorpay
              </>
            )}
          </button>
          <p className="text-[9px] text-center text-muted">Secured by Razorpay · PCI DSS Certified</p>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-slate-200" />
          <span className="text-[10px] font-black text-muted uppercase">or</span>
          <div className="flex-1 h-px bg-slate-200" />
        </div>

        {/* ── Stripe USA Gateway ── */}
        <div className="border border-border-custom rounded-2xl p-4 space-y-3 bg-white">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
            <span className="text-[10px] font-black text-navy uppercase tracking-wider">🌐 Stripe USA — Apple Pay / Credit & Debit Cards</span>
            <div className="flex flex-wrap gap-1 text-[9px] font-bold text-slate-500">
              <span className="bg-slate-100 px-1.5 py-0.5 rounded font-black text-navy">🍎 Apple Pay</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded font-black text-navy">G Pay</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">Visa</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">MasterCard</span>
              <span className="bg-slate-100 px-1.5 py-0.5 rounded">Amex</span>
            </div>
          </div>
          {stripeClientSecret ? (
            <Elements stripe={stripePromise} options={{ clientSecret: stripeClientSecret, appearance: { theme: 'stripe' } }}>
              <StripePaymentForm
                clientSecret={stripeClientSecret}
                finalAmount={finalAmount}
                currency={currency}
                paymentLoading={paymentLoading}
                setPaymentLoading={setPaymentLoading}
                buildApplicationData={buildApplicationData}
                onNext={onNext}
                setError={setError}
              />
            </Elements>
          ) : (
            <div className="animate-pulse bg-slate-100 rounded-xl h-14 flex items-center justify-center text-[10px] font-bold text-muted">
              Initializing Stripe USA Gateway...
            </div>
          )}
          <p className="text-[9px] text-center text-muted">Secured by Stripe USA · 256-Bit Encrypted</p>
        </div>

      </div>

      {/* Back & Backing */}
      <div className="space-y-4 pt-2 border-t border-slate-100">
        <button
          onClick={onBack}
          className="w-full border border-border-custom rounded-xl py-3 font-bold text-xs text-muted hover:border-blue hover:text-blue transition-colors bg-white"
        >
          ← Back
        </button>

        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600">
          <ShieldCheck className="w-4 h-4 text-green-600 shrink-0" />
          <span className="font-bold">100% Money-Back Guarantee — full refund if not accepted anywhere</span>
        </div>
      </div>
    </div>
  );
}

interface ApplicationFormProps {
  initialApplicationsCount?: number;
  initialMultipleIdpStatus?: string;
  initialUserRole?: string;
}

// ── MAIN APPLICATION FORM ─────────────────────────────────────────────────
export function ApplicationForm({
  initialApplicationsCount = 0,
  initialMultipleIdpStatus = "NONE",
  initialUserRole = "USER",
}: ApplicationFormProps) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [multipleIdpStatus, setMultipleIdpStatus] = useState(initialMultipleIdpStatus);
  const [requestLoading, setRequestLoading] = useState(false);
  const [requestError, setRequestError] = useState<string | null>(null);
  
  // Country & Form selections
  const [countries, setCountries] = useState<any[]>([]);
  const [issuingCountry, setIssuingCountry] = useState("");
  const [destinationCountry, setDestinationCountry] = useState("");

  const [usdPrices, setUsdPrices] = useState({
    DIGITAL: { 1: 21, 2: 26, 3: 32 },
    NFC_KIT: { 1: 32, 2: 37, 3: 42 },
  });

  useEffect(() => {
    fetch("/api/config/pricing")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.prices) {
          setUsdPrices(data.prices);
        }
      })
      .catch((err) => console.error("Error loading dynamic prices:", err));
  }, []);
  const [personalData, setPersonalData] = useState<PersonalForm | null>(null);
  
  const [isLoaded, setIsLoaded] = useState(false);

  // Check if standard user needs permission for multiple IDPs
  const needsPermission =
    initialUserRole === "USER" &&
    initialApplicationsCount >= 1 &&
    multipleIdpStatus !== "APPROVED";

  const handleRequestPermission = async () => {
    setRequestLoading(true);
    setRequestError(null);
    try {
      const res = await fetch("/api/user/request-permission", {
        method: "POST",
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setMultipleIdpStatus("REQUESTED");
      } else {
        throw new Error(data.error || "Failed to submit request");
      }
    } catch (err: any) {
      setRequestError(err.message || "An error occurred while submitting your request.");
    } finally {
      setRequestLoading(false);
    }
  };


  // Load countries list
  useEffect(() => {
    fetch("/api/countries")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setCountries(data);
          
          // Set initial defaults from list if available
          setIssuingCountry((prev) => {
            if (prev) return prev; // Keep loaded draft value
            const detectedName = useGeoStore.getState().countryName || "India";
            const matched = data.find(c => c.name.toLowerCase() === detectedName.toLowerCase());
            return matched ? matched.name : (data.find(c => c.name === "India")?.name || data[0].name);
          });
          setDestinationCountry((prev) => {
            if (prev) return prev;
            const matched = data.find(c => c.name === "Belize");
            return matched ? matched.name : (data[1]?.name || data[0].name);
          });
        } else {
          setCountries(FALLBACK_COUNTRIES);
          setIssuingCountry((prev) => {
            if (prev) return prev;
            const detectedName = useGeoStore.getState().countryName || "India";
            const matched = FALLBACK_COUNTRIES.find(c => c.name.toLowerCase() === detectedName.toLowerCase());
            return matched ? matched.name : "India";
          });
          setDestinationCountry((prev) => prev || "Belize");
        }
      })
      .catch(() => {
        setCountries(FALLBACK_COUNTRIES);
        setIssuingCountry((prev) => {
          if (prev) return prev;
          const detectedName = useGeoStore.getState().countryName || "India";
          const matched = FALLBACK_COUNTRIES.find(c => c.name.toLowerCase() === detectedName.toLowerCase());
          return matched ? matched.name : "India";
        });
        setDestinationCountry((prev) => prev || "Belize");
      });
  }, []);

  // Load draft from localStorage on mount
  useEffect(() => {
    try {
      const savedStep = localStorage.getItem("idp_apply_step");
      const savedData = localStorage.getItem("idp_apply_personal_data");
      const savedIssuing = localStorage.getItem("idp_apply_issuing_country");
      const savedDest = localStorage.getItem("idp_apply_destination_country");

      if (savedStep) setStep(parseInt(savedStep, 10));
      if (savedData) setPersonalData(JSON.parse(savedData));
      if (savedIssuing) setIssuingCountry(savedIssuing);
      if (savedDest) setDestinationCountry(savedDest);
    } catch (e) {
      console.error("Failed to load saved application progress:", e);
    }
    setIsLoaded(true);
  }, []);

  // Save current progress to localStorage as draft on changes
  useEffect(() => {
    if (!isLoaded) return;
    try {
      localStorage.setItem("idp_apply_step", step.toString());
      localStorage.setItem("idp_apply_issuing_country", issuingCountry);
      localStorage.setItem("idp_apply_destination_country", destinationCountry);
      
      if (personalData) {
        localStorage.setItem("idp_apply_personal_data", JSON.stringify(personalData));
      } else {
        localStorage.removeItem("idp_apply_personal_data");
      }
    } catch (e) {
      console.error("Failed to persist application progress:", e);
    }
  }, [step, personalData, issuingCountry, destinationCountry, isLoaded]);

  const clearProgress = () => {
    if (window.confirm("Are you sure you want to clear your current progress and start a new application?")) {
      try {
        localStorage.removeItem("idp_apply_step");
        localStorage.removeItem("idp_apply_personal_data");
        localStorage.removeItem("idp_apply_issuing_country");
        localStorage.removeItem("idp_apply_destination_country");
      } catch (e) {
        console.error(e);
      }
      setStep(0);
      setPersonalData(null);
      setIssuingCountry("India");
      setDestinationCountry("Belize");
    }
  };

  const handlePaymentSuccess = (appId: string) => {
    // Clear draft localStorage upon success
    try {
      localStorage.removeItem("idp_apply_step");
      localStorage.removeItem("idp_apply_personal_data");
      localStorage.removeItem("idp_apply_issuing_country");
      localStorage.removeItem("idp_apply_destination_country");
    } catch (e) {
      console.error(e);
    }
    // Redirect directly to success page with query details
    router.push(`/apply/success?email=${encodeURIComponent(personalData?.email || "")}&applicationId=${appId}`);
  };

  if (!isLoaded) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <span className="eyebrow-pill mb-4">Apply Online</span>
          <h1 className="section-heading mt-3">Get Your IDP in 3 Steps</h1>
          <p className="text-muted mt-2">Fast · Secure · 100% Money-Back Guarantee</p>
        </div>
        <div className="bg-white border border-border-custom rounded-3xl shadow-xl shadow-navy/5 p-6 md:p-8 flex flex-col items-center justify-center min-h-[350px]">
          <div className="w-10 h-10 border-4 border-blue border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-bold text-muted mt-4">Loading your application...</p>
        </div>
      </div>
    );
  }

  if (needsPermission) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="bg-white border border-border-custom rounded-3xl shadow-xl shadow-navy/5 p-6 md:p-8">
          <MiniHeader />
          
          <div className="text-center py-8 space-y-6">
            <div className="w-16 h-16 bg-blue/10 rounded-full flex items-center justify-center mx-auto text-blue text-2xl">
              {multipleIdpStatus === "REQUESTED" ? "⏳" : "🔒"}
            </div>
            
            <div className="space-y-2">
              <h2 className="font-sora font-black text-navy text-xl">
                {multipleIdpStatus === "REQUESTED"
                  ? "Permission Request Under Review"
                  : "Permission Required for Second IDP"}
              </h2>
              <p className="text-muted text-xs max-w-md mx-auto leading-relaxed font-bold">
                {multipleIdpStatus === "REQUESTED"
                  ? "You have already applied for an IDP. Your request for a second IDP is currently under review by our admin team. We will update you here once approved."
                  : multipleIdpStatus === "REJECTED"
                  ? "Your previous request to apply for a second IDP was declined. If you believe this was in error, you can submit a new request below."
                  : "Our system restricts standard accounts to one active International Driving Permit. If you need to apply for a second one, please submit a permission request."}
              </p>
            </div>

            {multipleIdpStatus === "REQUESTED" ? (
              <div className="bg-blue/5 border border-blue/10 rounded-2xl p-4 text-xs font-bold text-navy max-w-md mx-auto">
                🕒 Request submitted. Most reviews are completed within 1 hour.
              </div>
            ) : (
              <div className="max-w-md mx-auto space-y-3">
                {requestError && (
                  <p className="text-red-500 text-xs font-bold bg-red-50 border border-red-200 rounded-xl p-3">
                    {requestError}
                  </p>
                )}
                <button
                  onClick={handleRequestPermission}
                  disabled={requestLoading}
                  className="btn-primary w-full py-4 text-sm font-black flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform disabled:opacity-60"
                >
                  {requestLoading ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Submitting Request...
                    </>
                  ) : (
                    <>Submit Permission Request</>
                  )}
                </button>
              </div>
            )}

            <div className="border-t border-slate-100 pt-6 max-w-md mx-auto flex items-center justify-center gap-4 text-xs text-muted">
              <span>Need help?</span>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noreferrer"
                className="text-blue font-bold hover:underline"
              >
                Chat on WhatsApp →
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      {/* Preload Razorpay checkout script */}
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />

      <div className="bg-white border border-border-custom rounded-3xl shadow-xl shadow-navy/5 p-6 md:p-8">
        <MiniHeader />
        <StepIndicator current={step} />

        {step === 0 && (
          <Step1
            countries={countries}
            issuingCountry={issuingCountry}
            setIssuingCountry={setIssuingCountry}
            destinationCountry={destinationCountry}
            setDestinationCountry={setDestinationCountry}
            onNext={() => setStep(1)}
            usdPrices={usdPrices}
          />
        )}
        {step === 1 && (
          <Step2
            countries={countries}
            onNext={(data) => { setPersonalData(data); setStep(2); }}
            onBack={() => setStep(0)}
            savedData={personalData ?? undefined}
          />
        )}
        {step === 2 && personalData && (
          <Step3
            personalData={personalData}
            issuingCountry={issuingCountry}
            destinationCountry={destinationCountry}
            onNext={handlePaymentSuccess}
            onBack={() => setStep(1)}
            usdPrices={usdPrices}
          />
        )}
      </div>

      {step > 0 && (
        <div className="text-center mt-6">
          <button
            onClick={clearProgress}
            className="text-xs text-muted hover:text-red-500 font-bold transition-colors underline"
          >
            Clear progress and start new application
          </button>
        </div>
      )}
    </div>
  );
}
