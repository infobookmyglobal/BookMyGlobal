import React from "react";
import Image from "next/image";
import { ArrowRight, Award } from "lucide-react";

interface AuthorBoxProps {
  name?: string;
  role?: string;
  bio?: string;
  expertise?: string;
  profileUrl?: string;
  imageSrc?: string;
}

export function AuthorBox({
  name = "BookMyGlobal Editorial Team",
  role = "Travel & Documentation Desk",
  bio = "The BookMyGlobal editorial team researches visas, travel documents, driving permits and destination requirements to help travellers plan confidently.",
  expertise = "Visas • Travel Documents • Destination Guides",
  profileUrl = "/about",
  imageSrc = "/images/bmg-author.png"
}: AuthorBoxProps) {
  return (
    <div className="my-12 pt-8 border-t border-slate-200/80">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-sora font-black text-navy text-xl">
          About the Author
        </h3>
        <div className="flex items-center gap-1.5">
          <a
            href={profileUrl}
            target="_blank"
            rel="noopener noreferrer"
            title="X (Twitter) Profile"
            className="w-7 h-7 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-600 flex items-center justify-center transition-colors"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
          </a>
          <a
            href={profileUrl}
            target="_blank"
            rel="noopener noreferrer"
            title="LinkedIn Profile"
            className="w-7 h-7 rounded-lg bg-blue/10 hover:bg-blue/20 text-blue flex items-center justify-center transition-colors"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v8.37H9.25V10.9H6.46M7.86 6.7a1.63 1.63 0 1 0 0 3.26 1.63 1.63 0 0 0 0-3.26Z" />
            </svg>
          </a>
        </div>
      </div>

      <div className="bg-white border border-slate-200/90 rounded-2xl p-6 md:p-7 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all">
        <div className="flex flex-col md:flex-row items-start gap-5 md:gap-6">
          {/* Author Image */}
          <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-2xl overflow-hidden shrink-0 border border-slate-200 shadow-xs bg-slate-50">
            <Image
              src={imageSrc}
              alt={name}
              fill
              className="object-cover object-top"
              sizes="112px"
            />
          </div>

          {/* Author Content */}
          <div className="flex-1 space-y-3">
            <div>
              <h4 className="font-sora font-black text-navy text-lg md:text-xl">
                {name}
              </h4>
              <p className="text-xs font-bold text-blue tracking-wide uppercase mt-0.5">
                {role}
              </p>
            </div>

            <p className="text-slate-600 text-xs md:text-sm leading-relaxed">
              {bio}
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500">
                <Award className="w-3.5 h-3.5 text-blue shrink-0" />
                <span>
                  <strong className="text-slate-700 font-bold">Expertise:</strong> {expertise}
                </span>
              </div>

              <a
                href={profileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 font-sora font-black text-xs text-blue hover:text-navy transition-colors group shrink-0"
              >
                <span>View Author Profile</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
