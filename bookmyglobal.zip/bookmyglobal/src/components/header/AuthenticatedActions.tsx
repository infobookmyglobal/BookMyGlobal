"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { useAuth, UserButton } from "@/lib/clerk";
import { LayoutDashboard, ChevronDown, UserCircle2, Briefcase } from "lucide-react";

/** Fetches the DB role (USER | PARTNER | ADMIN) for the signed-in user. */
function useRole(userId: string | null | undefined) {
  const [role, setRole] = useState<string | null>(null);
  useEffect(() => {
    if (!userId) {
      setRole(null);
      return;
    }
    let cancelled = false;
    fetch("/api/user/me")
      .then((r) => (r.ok ? r.json() : { role: null }))
      .then((d) => !cancelled && setRole(d.role ?? null))
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [userId]);
  return role;
}

function dashboardFor(role: string | null) {
  if (role === "ADMIN") return { href: "/admin", label: "Admin Panel" };
  if (role === "PARTNER") return { href: "/partner", label: "Partner Dashboard" };
  return { href: "/dashboard", label: "Dashboard" };
}

export function DesktopAuth() {
  const { userId } = useAuth();
  const role = useRole(userId);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  if (!userId) {
    return (
      <div className="relative hidden md:block" ref={ref}>
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex items-center gap-1.5 text-xs font-bold text-white/90 hover:text-white bg-white/10 hover:bg-white/20 transition-all rounded-lg px-3.5 py-2 border border-white/10"
        >
          Sign In
          <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${open ? "rotate-180" : ""}`} />
        </button>
        {open && (
          <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-border-custom overflow-hidden z-50 text-left">
            <div className="px-4 pt-3 pb-2">
              <p className="text-[9px] font-black text-muted-custom uppercase tracking-wider">Sign in as</p>
            </div>
            <Link href="/sign-in" onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-3 hover:bg-bg-custom transition-colors group">
              <div className="w-8 h-8 rounded-xl bg-blue/10 flex items-center justify-center shrink-0">
                <UserCircle2 className="w-4 h-4 text-blue" />
              </div>
              <div>
                <p className="text-xs font-black text-navy">Sign In as Traveller</p>
                <p className="text-[10px] text-muted-custom font-bold">Manage your bookings & applications</p>
              </div>
            </Link>
            <div className="mx-4 border-t border-border-custom" />
            <Link href="/partner" onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-3 hover:bg-bg-custom transition-colors group">
              <div className="w-8 h-8 rounded-xl bg-yellow-500/10 flex items-center justify-center shrink-0">
                <Briefcase className="w-4 h-4 text-yellow-600" />
              </div>
              <div>
                <p className="text-xs font-black text-navy">Sign In as Partner</p>
                <p className="text-[10px] text-muted-custom font-bold">Partner dashboard & earnings</p>
              </div>
            </Link>
          </div>
        )}
      </div>
    );
  }

  const d = dashboardFor(role);
  return (
    <div className="hidden md:flex items-center gap-3">
      <Link
        href={d.href}
        className="flex items-center gap-1.5 text-xs font-bold text-white/90 hover:text-white bg-white/10 hover:bg-white/20 transition-all rounded-lg px-3.5 py-2 border border-white/10"
      >
        <LayoutDashboard className="w-3.5 h-3.5" />
        {d.label}
      </Link>
      <UserButton />
    </div>
  );
}

export function MobileAuth({ onCloseMobile }: { onCloseMobile: () => void }) {
  const { userId } = useAuth();
  const role = useRole(userId);
  const d = dashboardFor(role);

  if (!userId) {
    return (
      <>
        <Link href="/sign-in" onClick={onCloseMobile} className="flex items-center gap-3 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl px-4 py-3 text-left">
          <UserCircle2 className="w-5 h-5 text-blue-300" />
          <span className="text-sm font-black text-white">Sign In</span>
        </Link>
        <Link href="/partner" onClick={onCloseMobile} className="flex items-center gap-3 bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/20 rounded-xl px-4 py-3 text-left">
          <Briefcase className="w-5 h-5 text-yellow-400" />
          <span className="text-sm font-black text-white">Become a Partner</span>
        </Link>
      </>
    );
  }

  return (
    <div className="flex items-center justify-between bg-white/5 rounded-xl p-4 w-full text-left">
      <div className="flex items-center gap-3">
        <UserButton />
        <span className="text-white font-bold text-sm">My Account</span>
      </div>
      <Link href={d.href} onClick={onCloseMobile} className="text-xs font-bold text-white bg-blue rounded-lg px-3 py-2">
        {d.label}
      </Link>
    </div>
  );
}
