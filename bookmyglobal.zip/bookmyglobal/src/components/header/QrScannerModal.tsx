"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  X,
  Camera,
  Upload,
  Search,
  CheckCircle2,
  XCircle,
  QrCode,
} from "lucide-react";
import type { Html5Qrcode } from "html5-qrcode";
import { useTranslation } from "@/hooks/useTranslation";

interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function QrScannerModal({ isOpen, onClose }: QrScannerModalProps) {
  const router = useRouter();
  const { t } = useTranslation();

  // Scanner state
  const [activeTab, setActiveTab] = useState<"camera" | "upload" | "manual">("manual");
  const [scanResult, setScanResult] = useState<{
    success: boolean;
    id?: string;
    fullName?: string;
    idpNumber?: string;
    error?: string;
  } | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [manualQuery, setManualQuery] = useState("");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // QR scanner instance ref
  const html5QrcodeRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Play browser synthesizer beep for a premium scan sound
  const playSuccessSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
      console.warn("Audio Context not supported or allowed", e);
    }
  };

  // Close scanner and cleanup camera
  const closeScanner = async () => {
    onClose();
    setScanResult(null);
    setCameraError(null);
    setManualQuery("");
    
    if (html5QrcodeRef.current) {
      if (html5QrcodeRef.current.isScanning) {
        try {
          await html5QrcodeRef.current.stop();
        } catch (e) {
          console.error("Error stopping scanner", e);
        }
      }
      html5QrcodeRef.current = null;
    }
  };

  // Handle successful QR code decode
  const handleScanSuccess = async (decodedText: string) => {
    playSuccessSound();
    
    // Stop camera immediately
    if (html5QrcodeRef.current && html5QrcodeRef.current.isScanning) {
      try {
        await html5QrcodeRef.current.stop();
      } catch (e) {
        console.error("Error stopping camera on success", e);
      }
    }

    validateIDP(decodedText);
  };

  // Validate ID/IDP number with backend API
  const validateIDP = async (queryStr: string) => {
    setIsValidating(true);
    setScanResult(null);

    try {
      const response = await fetch(`/api/verify?query=${encodeURIComponent(queryStr)}`);
      const data = await response.json();

      if (data.success) {
        setScanResult({
          success: true,
          id: data.id,
          fullName: data.fullName,
          idpNumber: data.idpNumber || "Pending"
        });

        // Trigger redirect to detailed verify page after showing success for 1.8 seconds
        setTimeout(() => {
          closeScanner();
          router.push(`/verify/${data.id}`);
        }, 1800);
      } else {
        setScanResult({
          success: false,
          error: data.error || "This IDP permit could not be verified in our registry."
        });
      }
    } catch (err) {
      setScanResult({
        success: false,
        error: "Network validation error. Please try again."
      });
    } finally {
      setIsValidating(false);
    }
  };

  // Initialize Camera Scanner when scanner modal opens & camera tab is selected
  useEffect(() => {
    let active = true;

    const startCamera = async () => {
      if (!isOpen || activeTab !== "camera") return;

      // Small delay to ensure the div is fully rendered in DOM
      await new Promise((resolve) => setTimeout(resolve, 300));
      if (!active) return;

      const elementId = "bmg-qr-reader";
      const qrReaderDiv = document.getElementById(elementId);
      if (!qrReaderDiv) return;

      try {
        setCameraError(null);
        const { Html5Qrcode: Html5QrcodeClass } = await import("html5-qrcode");
        const html5Qrcode = new Html5QrcodeClass(elementId);
        html5QrcodeRef.current = html5Qrcode;

        await html5Qrcode.start(
          { facingMode: "environment" },
          {
            fps: 10,
            qrbox: (width, height) => {
              const size = Math.min(width, height) * 0.7;
              return { width: size, height: size };
            }
          },
          handleScanSuccess,
          () => {
            // Ignore frame scan failures to avoid noisy logs
          }
        );
      } catch (err: any) {
        console.error("Camera startup failed:", err);
        setCameraError(
          err?.message || "Could not access camera. Please allow camera permissions or upload an image."
        );
      }
    };

    if (isOpen && activeTab === "camera") {
      startCamera();
    }

    return () => {
      active = false;
      if (html5QrcodeRef.current) {
        const scanner = html5QrcodeRef.current;
        if (scanner.isScanning) {
          scanner.stop().catch((e) => console.error("Error stopping scanner in cleanup", e));
        }
        html5QrcodeRef.current = null;
      }
    };
  }, [isOpen, activeTab]);

  // Handle Drag Events for QR File Uploader
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  // Handle QR File Drop/Upload
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processQRImage(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processQRImage(e.target.files[0]);
    }
  };

  const processQRImage = async (file: File) => {
    setIsValidating(true);
    setScanResult(null);

    try {
      const { Html5Qrcode: Html5QrcodeClass } = await import("html5-qrcode");
      const html5Qrcode = new Html5QrcodeClass("bmg-qr-file-detector");
      const decodedText = await html5Qrcode.scanFile(file, true);
      playSuccessSound();
      validateIDP(decodedText);
    } catch (err) {
      setScanResult({
        success: false,
        error: "Failed to read QR Code from this image. Please upload a clear image of the QR Code."
      });
      setIsValidating(false);
    }
  };

  // Handle manual input search
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualQuery.trim()) return;
    validateIDP(manualQuery.trim());
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Dynamic Keyframe Injection for Scanning Lasers */}
      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes scan-line-move {
            0% { top: 4%; }
            50% { top: 96%; }
            100% { top: 4%; }
          }
          .animate-laser {
            animation: scan-line-move 2.2s infinite ease-in-out;
          }
          @keyframes radar-pulse {
            0% { transform: scale(0.95); opacity: 0.3; }
            50% { transform: scale(1.05); opacity: 0.7; }
            100% { transform: scale(0.95); opacity: 0.3; }
          }
          .animate-radar {
            animation: radar-pulse 3s infinite ease-in-out;
          }
          /* Hide HTML5 QR Code's default white box border and gray shading canvas overlay */
          #bmg-qr-reader canvas {
            display: none !important;
          }
          /* Remove default borders and background injected by HTML5 QR Code */
          #bmg-qr-reader {
            border: none !important;
            background: transparent !important;
          }
          #bmg-qr-reader__scan_region {
            background: transparent !important;
          }
        `
      }} />

      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md px-4 py-6">
        <div className="relative w-full max-w-lg overflow-hidden bg-[#0d074b] border border-white/15 rounded-[28px] shadow-2xl animate-scale-up text-white">
          
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/10 bg-[#070233]">
            <div className="flex items-center gap-2.5">
              <QrCode className="w-5.5 h-5.5 text-[#e20074] animate-pulse" />
              <h2 className="font-sora text-lg font-black tracking-wide">IDP REGISTRY VERIFICATION</h2>
            </div>
            <button
              onClick={closeScanner}
              className="p-1.5 text-white/70 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-white/10 bg-[#0a0440]">
            <button
              onClick={() => { setActiveTab("manual"); setScanResult(null); }}
              className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
                activeTab === "manual"
                  ? "border-[#e20074] text-[#e20074] bg-white/5"
                  : "border-transparent text-white/60 hover:text-white"
              }`}
            >
              <Search className="w-4 h-4" />
              Manual Lookup
            </button>
            <button
              onClick={() => { setActiveTab("camera"); setScanResult(null); }}
              className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
                activeTab === "camera"
                  ? "border-[#e20074] text-[#e20074] bg-white/5"
                  : "border-transparent text-white/60 hover:text-white"
              }`}
            >
              <Camera className="w-4 h-4" />
              Live Camera
            </button>
            <button
              onClick={() => { setActiveTab("upload"); setScanResult(null); }}
              className={`flex-1 py-3.5 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
                activeTab === "upload"
                  ? "border-[#e20074] text-[#e20074] bg-white/5"
                  : "border-transparent text-white/60 hover:text-white"
              }`}
            >
              <Upload className="w-4 h-4" />
              Upload Image
            </button>
          </div>

          {/* Content Area */}
          <div className="p-6">
            
            {/* Validation Status Overlay */}
            {isValidating && (
              <div className="flex flex-col items-center justify-center py-14 space-y-4">
                <div className="relative flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full border-4 border-white/10 border-t-[#e20074] animate-spin" />
                  <QrCode className="w-7 h-7 absolute text-[#e20074]" />
                </div>
                <div className="text-center">
                  <p className="font-bold text-base text-white">Validating IDP Credentials...</p>
                  <p className="text-xs text-white/60 mt-1">Checking the international database records...</p>
                </div>
              </div>
            )}

            {/* Validation Result Display */}
            {!isValidating && scanResult && (
              <div className="py-6 flex flex-col items-center text-center space-y-5">
                {scanResult.success ? (
                  <>
                    <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-green-400" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-sora text-xl font-black text-green-400 uppercase">
                        ✅ VERIFIED LEGIT IDP
                      </h3>
                      <p className="text-sm font-bold text-white/95">
                        Authentic document found in BookMyGlobal registry!
                      </p>
                      <div className="bg-[#0f1d40] border border-blue-500/20 rounded-2xl p-4 max-w-sm mx-auto space-y-2 text-left mt-2 shadow-inner">
                        <div className="flex justify-between text-xs">
                          <span className="text-white/60">Permit Holder:</span>
                          <span className="font-bold text-white">{scanResult.fullName}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-white/60">IDP Number:</span>
                          <span className="font-mono font-bold text-blue-400">{scanResult.idpNumber}</span>
                        </div>
                      </div>
                      <p className="text-[11px] text-white/50 animate-pulse mt-4">
                        Redirecting to full credential details page...
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center">
                      <XCircle className="w-10 h-10 text-red-400" />
                    </div>
                    <div className="space-y-3">
                      <h3 className="font-sora text-xl font-black text-red-400 uppercase">
                        ❌ VERIFICATION FAILED
                      </h3>
                      <p className="text-sm text-white/80 max-w-sm leading-relaxed">
                        {scanResult.error}
                      </p>
                      <button
                        onClick={() => setScanResult(null)}
                        className="mt-2 bg-white/10 hover:bg-white/20 text-white border border-white/15 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer"
                      >
                        Try Scanning Again
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* 1. Camera Scanning view */}
            {!isValidating && !scanResult && activeTab === "camera" && (
              <div className="flex flex-col items-center">
                <div className="relative w-full aspect-square max-w-[280px] bg-black/40 rounded-2xl border border-white/10 overflow-hidden flex items-center justify-center group shadow-inner">
                  {/* QR Code element mounted here */}
                  <div id="bmg-qr-reader" className="w-full h-full object-cover [&_video]:object-cover" />
                  
                  {/* Floating Scanner Overlay Effects when scanning */}
                  {!cameraError && (
                    <>
                      {/* Shading surrounding the center target zone */}
                      <div className="absolute inset-0 bg-black/25 pointer-events-none" />
                      
                      {/* Target Scanning Box in the center */}
                      <div className="absolute w-[180px] h-[180px] border border-white/15 rounded-2xl pointer-events-none flex flex-col justify-between p-0 overflow-hidden bg-transparent">
                        {/* Laser Scan line restricted precisely inside the center box */}
                        <div className="absolute left-1 right-1 h-[2px] bg-green-400 shadow-[0_0_8px_2px_rgba(74,222,128,0.85)] animate-laser pointer-events-none" />
                      </div>
                      
                      {/* Scanning target corners around the center box */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="relative w-[186px] h-[186px]">
                          <div className="absolute top-0 left-0 w-5 h-5 border-t-[3px] border-l-[3px] border-[#e20074] rounded-tl-md" />
                          <div className="absolute top-0 right-0 w-5 h-5 border-t-[3px] border-r-[3px] border-[#e20074] rounded-tr-md" />
                          <div className="absolute bottom-0 left-0 w-5 h-5 border-b-[3px] border-l-[3px] border-[#e20074] rounded-bl-md" />
                          <div className="absolute bottom-0 right-0 w-5 h-5 border-b-[3px] border-r-[3px] border-[#e20074] rounded-br-md" />
                        </div>
                      </div>
                      
                      {/* Radar animated grid background */}
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(226,0,116,0.08)_0%,transparent_60%)] pointer-events-none animate-radar" />
                    </>
                  )}

                  {/* Camera Error Message */}
                  {cameraError && (
                    <div className="absolute inset-0 p-4 flex flex-col items-center justify-center text-center bg-slate-950/80 z-10 space-y-3">
                      <XCircle className="w-10 h-10 text-red-500" />
                      <p className="text-xs font-bold text-white/95 leading-relaxed">{cameraError}</p>
                      <button
                        onClick={() => setActiveTab("upload")}
                        className="bg-[#e20074] hover:bg-[#c10063] px-3.5 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors shadow"
                      >
                        Use File Upload
                      </button>
                    </div>
                  )}
                </div>
                
                {!cameraError && (
                  <p className="text-xs text-white/60 mt-4 text-center tracking-wide font-medium">
                    Place the QR code inside the green laser scanning guide.
                  </p>
                )}
              </div>
            )}

            {/* 2. Drag & Drop File QR detector */}
            {!isValidating && !scanResult && activeTab === "upload" && (
              <div className="space-y-4">
                <div
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                    dragActive
                      ? "border-[#e20074] bg-[#e20074]/5"
                      : "border-white/20 hover:border-white/40 bg-white/2"
                  }`}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                  <Upload className="w-10 h-10 text-white/60 mb-3" />
                  <p className="text-sm font-bold">Drag and drop your QR Code image here</p>
                  <p className="text-xs text-white/50 mt-1">or click to browse local files</p>
                  <p className="text-[10px] text-white/40 mt-4">Supports PNG, JPG, JPEG formats</p>
                </div>
                
                {/* Invisible div for html5-qrcode file scanning worker */}
                <div id="bmg-qr-file-detector" className="hidden" />
              </div>
            )}

            {/* 3. Manual ID registry lookup */}
            {!isValidating && !scanResult && activeTab === "manual" && (
              <form onSubmit={handleManualSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-wider text-white/70">
                    IDP PERMIT NUMBER / ID
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="e.g. IDP number or application ID"
                      value={manualQuery}
                      onChange={(e) => setManualQuery(e.target.value)}
                      className="w-full bg-black/30 border border-white/15 focus:border-[#e20074] focus:ring-1 focus:ring-[#e20074] rounded-xl pl-4 pr-11 py-3 text-sm text-white placeholder-white/30 focus:outline-none transition-all"
                      required
                    />
                    <button
                      type="submit"
                      className="absolute right-2 top-2 p-1.5 text-white/60 hover:text-white rounded-lg bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
                    >
                      <Search className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#e20074] hover:bg-[#c10063] text-white py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-colors shadow-lg shadow-[#e20074]/10 cursor-pointer"
                >
                  SEARCH REGISTRY
                </button>
              </form>
            )}

          </div>
        </div>
      </div>
    </>
  );
}
