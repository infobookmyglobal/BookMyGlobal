import Link from "next/link";
import { Logo } from "@/components/Logo";
import { SUPPORT_EMAIL } from "@/lib/contact";

const COLUMNS = [
  {
    title: "Services",
    links: [
      { href: "/idp", label: "International Driving Permit" },
      { href: "/contact?type=FLIGHT", label: "Flights" },
      { href: "/contact?type=HOTEL", label: "Hotels" },
      { href: "/contact?type=TOURS", label: "Tours & Activities" },
      { href: "/contact?type=ATTESTATION", label: "MEA & Embassy Attestation" },
      { href: "/contact?type=VISA", label: "Visa Assistance" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/#yoga", label: "Yoga Tourism" },
      { href: "/#community", label: "Community" },
      { href: "/blog", label: "Blog" },
      { href: "/partner", label: "Partner Program" },
      { href: "/contact", label: "Contact" },
    ],
  },
  {
    title: "Legal",
    links: [
      { href: "/terms", label: "Terms & Conditions" },
      { href: "/privacy", label: "Privacy Policy" },
      { href: "/refunds", label: "Refund Policy" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="bg-navy text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 grid gap-10 md:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div>
          <Logo />
          <p className="mt-4 text-sm text-white/60 max-w-xs leading-relaxed">
            One account for the documents, bookings and people behind every trip.
          </p>
          <a href={`mailto:${SUPPORT_EMAIL}`} className="mt-4 inline-block text-sm font-bold text-gold hover:underline">
            {SUPPORT_EMAIL}
          </a>
        </div>
        {COLUMNS.map((col) => (
          <div key={col.title}>
            <p className="text-[11px] font-black uppercase tracking-widest text-white/40 mb-4">{col.title}</p>
            <ul className="space-y-2.5">
              {col.links.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-white/70 hover:text-white transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-5 text-xs text-white/40 flex flex-col sm:flex-row gap-2 justify-between">
          <p>© {new Date().getFullYear()} BookMyGlobal. All rights reserved.</p>
          <p>BookMyGlobal is a private travel services platform and is not a government body.</p>
        </div>
      </div>
    </footer>
  );
}
