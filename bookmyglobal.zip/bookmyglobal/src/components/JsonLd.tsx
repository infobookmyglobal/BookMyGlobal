// JSON-LD structured data helpers for SEO

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://bookmyglobal.com';

export function OrganizationJsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'BookMyGlobal',
    url: APP_URL,
    logo: `${APP_URL}/logo.png`,
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: process.env.NEXT_PUBLIC_SUPPORT_PHONE || '',
      contactType: 'customer service',
      availableLanguage: ['English', 'Arabic', 'French', 'Spanish'],
    },
    sameAs: [],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function ProductJsonLd() {
  const data = [
    {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'International Driving Permit — Digital',
      description: 'Digital PDF IDP emailed in 2–4 hours. Accepted in 189+ countries.',
      brand: { '@type': 'Brand', name: 'BookMyGlobal' },
      offers: {
        '@type': 'AggregateOffer',
        lowPrice: '21.00',
        highPrice: '32.00',
        priceCurrency: 'USD',
        availability: 'https://schema.org/InStock',
      },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: 'International Driving Permit — NFC Smart Kit',
      description: 'Physical IDP booklet + NFC card shipped worldwide within 24 hours.',
      brand: { '@type': 'Brand', name: 'BookMyGlobal' },
      offers: {
        '@type': 'AggregateOffer',
        lowPrice: '32.00',
        highPrice: '42.00',
        priceCurrency: 'USD',
        availability: 'https://schema.org/InStock',
      },
    },
  ];

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function FaqJsonLd({
  faqs,
}: {
  faqs: { question: string; answer: string }[];
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((f) => ({
      '@type': 'Question',
      name: f.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: f.answer,
      },
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function CountryBreadcrumbJsonLd({
  countryName,
  countrySlug,
}: {
  countryName: string;
  countrySlug: string;
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: APP_URL },
      { '@type': 'ListItem', position: 2, name: 'Countries', item: `${APP_URL}/countries` },
      {
        '@type': 'ListItem',
        position: 3,
        name: `IDP for ${countryName}`,
        item: `${APP_URL}/country/${countrySlug}`,
      },
    ],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function WebPageJsonLd({
  name,
  description,
  urlPath,
  dateModified,
}: {
  name: string;
  description: string;
  urlPath: string;
  dateModified?: string;
}) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name,
    description,
    url: `${APP_URL}${urlPath}`,
    publisher: {
      '@type': 'Organization',
      name: 'BookMyGlobal',
      url: APP_URL,
    },
    ...(dateModified ? { dateModified } : {}),
    inLanguage: 'en-US',
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function CustomStructuredData({ data }: { data: string }) {
  if (!data) return null;

  // Step 1: Strip ALL HTML tags (e.g. <div>, <script>, <p> etc.)
  let cleaned = data
    .replace(/<[^>]+>/gi, "")
    .trim();

  // Step 2: Decode common HTML entities that may have been stored
  cleaned = cleaned
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'");

  // Step 3: Validate that it is parseable JSON before injecting.
  // If not valid JSON, bail out to avoid corrupting the page.
  try {
    const parsed = JSON.parse(cleaned);
    const safe = JSON.stringify(parsed);
    return (
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safe }}
      />
    );
  } catch {
    // Stored value is not valid JSON — skip injection silently.
    return null;
  }
}
