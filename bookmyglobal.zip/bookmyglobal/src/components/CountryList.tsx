"use client";

import { useState } from "react";
import Link from "next/link";
import { SafeImage } from "./SafeImage";

type Country = {
  id: string;
  slug: string;
  name: string;
  flag: string;
  continent: string;
  convention: string;
  requiresPhysical: boolean;
  status: string;
  heroImageUrl: string | null;
};

export function CountryList({ countries }: { countries: Country[] }) {
  const [search, setSearch] = useState("");
  const [activeFilter, setActiveFilter] = useState("All");

  const regions = ["Africa", "Americas", "Asia", "Europe", "Oceania"];
  const icons: Record<string, string> = {
    Africa: "🌍",
    Americas: "🌎",
    Asia: "🌏",
    Europe: "🏛",
    Oceania: "🌊",
  };

  const filteredCountries = countries.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase());
    const matchesRegion = activeFilter === "All" || c.continent === activeFilter;
    return matchesSearch && matchesRegion;
  });

  return (
    <div className="w-full">
      <div className="max-w-4xl mx-auto px-4 mt-8 mb-12">
        <div className="flex flex-col md:flex-row gap-4 items-center bg-white p-2 rounded-2xl shadow-sm border border-border-custom">
          <input
            type="text"
            placeholder="🔍 Search country..."
            className="flex-1 w-full bg-transparent px-4 py-2 outline-none text-text-custom"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-2 flex-wrap justify-center p-2 bg-bg-custom rounded-xl w-full md:w-auto">
            <button
              onClick={() => setActiveFilter("All")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeFilter === "All" ? "bg-navy text-white" : "text-muted hover:bg-white"
              }`}
            >
              All
            </button>
            {regions.map((region) => (
              <button
                key={region}
                onClick={() => setActiveFilter(region)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  activeFilter === region ? "bg-navy text-white" : "text-muted hover:bg-white"
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 pb-20">
        {regions.map((region) => {
          const regionCountries = filteredCountries.filter((c) => c.continent === region);
          if (regionCountries.length === 0) return null;

          return (
            <div key={region} className="mb-12">
              <h2 className="text-sm font-black text-muted uppercase tracking-widest mb-6 pb-2 border-b border-border-custom flex items-center gap-2">
                <span>{icons[region]}</span> {region} <span className="font-normal text-muted/60">({regionCountries.length})</span>
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {regionCountries.map((c) => (
                  <Link href={`/countries/${c.slug}`} key={c.id}>
                    <div className="custom-card h-full group overflow-hidden cursor-pointer flex flex-col">
                      <div className="h-28 w-full bg-blue/10 relative">
                        {c.heroImageUrl ? (
                          <SafeImage src={c.heroImageUrl} alt={c.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-4xl">{c.flag}</div>
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <div className="text-2xl mb-1">{c.flag}</div>
                        <h3 className="font-sora font-black text-navy text-sm mb-2 leading-tight">{c.name}</h3>
                        
                        <div className="mt-auto space-y-1">
                          {c.status === "NOT_ACCEPTED" ? (
                            <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black bg-red-100 text-red-700">
                              Not Accepted
                            </span>
                          ) : c.status === "LIMITED" ? (
                            <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black bg-yellow-100 text-yellow-800">
                              Limited
                            </span>
                          ) : c.requiresPhysical ? (
                            <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black bg-orange-100 text-orange-700">
                              Physical Only
                            </span>
                          ) : (
                            <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-black bg-green-100 text-green-700">
                              Digital + Physical
                            </span>
                          )}
                          <div className="text-[9px] font-bold text-muted flex gap-1 flex-wrap mt-1">
                            {c.convention === "BOTH" ? (
                              <>
                                <span className="bg-blue/10 text-blue px-2 py-0.5 rounded-full">Geneva</span>
                                <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">Vienna</span>
                              </>
                            ) : c.convention === "GENEVA" ? (
                              <span className="bg-blue/10 text-blue px-2 py-0.5 rounded-full">1949 Geneva</span>
                            ) : (
                              <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">1968 Vienna</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
        
        {filteredCountries.length === 0 && (
          <div className="text-center py-20 text-muted">
            <span className="text-4xl block mb-4">🌍</span>
            <p className="font-bold">No countries found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
