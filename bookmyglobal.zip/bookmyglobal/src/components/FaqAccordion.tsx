"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export function FaqAccordion() {
  const [openFaqIdx, setOpenFaqIdx] = useState<number | null>(null);

  const toggleFaq = (idx: number) => {
    setOpenFaqIdx(openFaqIdx === idx ? null : idx);
  };

  const faqs = [
    {
      q: "What is an International Driving Permit (IDP)?",
      a: "An International Driving Permit (IDP) is a legal supplementary document that translates your domestic driver's license into 12 of the most widely spoken international languages. It is established by United Nations conventions to help overcome language barriers with foreign police officers, rental car agents, and traffic authorities."
    },
    {
      q: "Do I need an IDP to rent a car abroad?",
      a: "Yes, in the vast majority of foreign destinations, an IDP is a mandatory legal requirement specified by local laws and car rental company policies. Even in countries where police do not actively check, rental counters (such as Hertz, SIXT, and Avis) will refuse to hand over keys without a valid IDP accompanying your domestic license."
    },
    {
      q: "How quickly will I receive my IDP?",
      a: "Our digital processing is extremely fast. Once you submit your online application, it is reviewed and approved by our documentation specialists within 2 hours. A high-resolution, secure PDF copy is sent immediately to your email. Physical NFC Smart Kits are printed, packaged, and dispatched via express courier within 24 hours."
    },
    {
      q: "Which countries require a physical IDP?",
      a: "While most countries accept digital copies for routine checks, certain high-traffic destinations — such as the United Arab Emirates (Dubai), Thailand, Spain, and Bali (Indonesia) — strictly mandate a physical printed multilingual booklet at the rental counter. We highly recommend our NFC Smart Kit to ensure universal coverage."
    },
    {
      q: "What documents do I need to apply for an IDP?",
      a: "Applying online is simple and requires only three things: 1) A clear photo of the front and back of your valid domestic driver's license, 2) A passport-style headshot photo (which can be taken with your smartphone against a plain wall), and 3) A digital scan of your signature."
    }
  ];

  return (
    <div className="space-y-4">
      {faqs.map((faq, idx) => {
        const isOpen = openFaqIdx === idx;
        return (
          <div
            key={idx}
            className="bg-white border border-slate-200 rounded-2xl overflow-hidden transition-all shadow-sm"
          >
            <button
              onClick={() => toggleFaq(idx)}
              className="w-full text-left p-5 flex items-center justify-between gap-4 font-sora font-black text-sm text-navy hover:text-blue transition-colors cursor-pointer"
            >
              <span>{faq.q}</span>
              <ChevronDown className={`w-5 h-5 shrink-0 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-180 text-blue" : ""}`} />
            </button>
            {isOpen && (
              <div className="p-5 border-t border-slate-100 bg-slate-50/50 text-xs md:text-sm text-slate-500 leading-relaxed">
                {faq.a}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
