import Link from 'next/link';

interface RelatedPage {
  slug: string;
  urlPath: string;
  cityName: string;
  country: string;
  metaTitle: string;
  pageType: string;
}

interface RelatedDestinationsProps {
  pageType: string;
  country: string;
  region: string;
  relatedPages: RelatedPage[];
  hubPage: { slug: string; urlPath: string; cityName: string } | null;
}

export function RelatedDestinations({ pageType, country, region, relatedPages, hubPage }: RelatedDestinationsProps) {
  const title = pageType === 'HUB'
    ? `More IDP Guides for ${country}`
    : `Explore ${region}`;

  const rawLinks: RelatedPage[] = [];
  if (pageType === 'CITY' && hubPage) {
    rawLinks.push({ slug: hubPage.slug, urlPath: hubPage.urlPath, cityName: hubPage.cityName.replace(/\s*[Hh]ub\s*$/, ""), country, metaTitle: `${country} IDP Guide`, pageType: 'HUB' });
  }
  rawLinks.push(...relatedPages);

  // Deduplicate by slug
  const allLinks = rawLinks.filter((item, index, self) =>
    self.findIndex(t => t.slug === item.slug) === index
  );

  if (allLinks.length === 0) return null;

  return (
    <section className="rd-section">
      <div className="rd-inner">
        <div className="rd-header">
          <span className="rd-eyebrow">Related Guides</span>
          <h2 className="rd-title">{title}</h2>
        </div>

        <div className="rd-grid">
          {allLinks.map((page) => (
            <Link key={page.slug} href={`/idp/${page.slug}`} className={`rd-card ${page.pageType === 'HUB' ? 'rd-card--hub' : ''}`}>
              <div className="rd-card__badge">
                {page.pageType === 'HUB' ? '🏛️ Country Guide' : '🏙️ City Guide'}
              </div>
              <h3 className="rd-card__name">{page.cityName.replace(/\s*[Hh]ub\s*$/, "")}</h3>
              <p className="rd-card__meta">{page.pageType === 'HUB' ? page.country : `${page.country} · City Guide`}</p>
              <span className="rd-card__link">View IDP Guide →</span>
            </Link>
          ))}
        </div>
      </div>

      <style>{`
        .rd-section {
          background: #f8faff;
          border-top: 1px solid #e2e8f0;
          padding: 64px 0;
        }
        .rd-inner {
          max-width: 1100px;
          margin: 0 auto;
          padding: 0 24px;
        }
        .rd-header { margin-bottom: 32px; }
        .rd-eyebrow {
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #0033CC;
          display: block;
          margin-bottom: 8px;
        }
        .rd-title {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: #001A66;
          margin: 0;
        }
        .rd-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: 16px;
        }
        .rd-card {
          background: #ffffff;
          border: 1.5px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
          text-decoration: none;
          display: flex;
          flex-direction: column;
          gap: 6px;
          transition: all 0.25s ease;
        }
        .rd-card:hover {
          border-color: #0033CC;
          transform: translateY(-3px);
          box-shadow: 0 10px 30px rgba(0,51,204,0.1);
        }
        .rd-card--hub {
          border-color: #001A66;
          background: linear-gradient(135deg, #f0f4ff 0%, #ffffff 100%);
        }
        .rd-card__badge {
          font-family: var(--font-sora);
          font-size: 10px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #0033CC;
          margin-bottom: 4px;
        }
        .rd-card--hub .rd-card__badge { color: #001A66; }
        .rd-card__name {
          font-family: var(--font-sora);
          font-size: 16px;
          font-weight: 900;
          color: #001A66;
          margin: 0;
        }
        .rd-card__meta {
          font-family: var(--font-dmsans);
          font-size: 12px;
          color: #64748b;
          margin: 0;
        }
        .rd-card__link {
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 800;
          color: #0033CC;
          margin-top: auto;
          padding-top: 8px;
        }
      `}</style>
    </section>
  );
}
