import Link from 'next/link';
import { QuickFactsBar } from './QuickFactsBar';
import { ApplyCTACard } from './ApplyCTACard';
import { InternalLinks } from './InternalLinks';
import { RelatedDestinations } from './RelatedDestinations';

interface DestinationPage {
  id: string;
  slug: string;
  urlPath: string;
  pageType: string;
  region: string;
  country: string;
  cityName: string;
  metaTitle: string;
  metaDescription: string;
  h1: string;
  bodyContent: string;
  insiderTip: string;
  internalLinks: string;
  disclaimer: string;
  isActive: boolean;
}

type CountryData = {
  drivingSide: string;
  requiresPhysical: boolean;
  maxValidity: number;
  convention: string;
} | null;

interface RelatedPage {
  slug: string;
  urlPath: string;
  cityName: string;
  country: string;
  metaTitle: string;
  pageType: string;
}

interface DestinationPageTemplateProps {
  page: DestinationPage;
  relatedPages: RelatedPage[];
  hubPage: { slug: string; urlPath: string; cityName: string } | null;
  countryData: CountryData;
}

/** Returns true if the string contains HTML markup */
function isHtml(str: string): boolean {
  return /<[a-z][\s\S]*>/i.test(str);
}

export function DestinationPageTemplate({ page, relatedPages, hubPage, countryData }: DestinationPageTemplateProps) {
  const bodyIsHtml = isHtml(page.bodyContent);
  // For plain-text legacy content, split into paragraphs
  const paragraphs = bodyIsHtml ? [] : page.bodyContent.split(/\n\n+/).filter(Boolean);
  const cleanCityName = page.cityName.replace(/\s*[Hh]ub\s*$/, "");

  const cd = countryData ?? {
    drivingSide: 'RIGHT',
    requiresPhysical: false,
    maxValidity: 3,
    convention: 'GENEVA',
  };

  return (
    <main>
      {/* ─── HERO ─────────────────────────────────────────────── */}
      <section className="dest-hero">
        <div className="dest-hero__inner">
          {/* Breadcrumb */}
          <nav aria-label="Breadcrumb" className="dest-breadcrumb">
            <Link href="/">Home</Link>
            <span>›</span>
            <Link href="/idp">{page.region}</Link>
            {page.pageType === 'CITY' && hubPage && (
              <>
                <span>›</span>
                <Link href={`/idp/${hubPage.slug}`}>{page.country}</Link>
              </>
            )}
            <span>›</span>
            <span>{cleanCityName}</span>
          </nav>

          {/* Region badge */}
          <div className="glass-pill dest-hero__badge">{page.region}</div>

          {/* H1 */}
          <h1 className="dest-hero__h1">{page.h1}</h1>

          {/* Trust badges */}
          <div className="dest-hero__badges">
            <span className="dest-trust-badge">✅ All Major Car Rental Agencies Accepted</span>
            <span className="dest-trust-badge">⚡ Digital IDP in 2 Hours</span>
          </div>

          {/* CTA */}
          <Link href="/apply" className="dest-hero__cta" id="hero-apply-btn">
            Apply for IDP — {cleanCityName} →
          </Link>
        </div>
      </section>

      {/* ─── QUICK FACTS BAR ─────────────────────────────────── */}
      <QuickFactsBar
        drivingSide={cd.drivingSide}
        requiresPhysical={cd.requiresPhysical}
        maxValidity={cd.maxValidity}
        convention={cd.convention}
      />

      {/* ─── MAIN CONTENT ─────────────────────────────────────── */}
      <section className="dest-content">
        <div className="dest-content__inner">
          {/* LEFT — Body */}
          <article className="dest-body">
            <div className="dest-body__text">
              {bodyIsHtml ? (
                // Render stored HTML markup (headings, lists, bold, etc.)
                <div dangerouslySetInnerHTML={{ __html: page.bodyContent }} />
              ) : (
                // Legacy plain-text: split by double newlines into paragraphs
                paragraphs.map((para, i) => (
                  <p key={i}>{para}</p>
                ))
              )}
            </div>

            {/* Insider Tip */}
            {page.insiderTip && (
              <div className="dest-insider">
                <span className="dest-insider__label">💡 Local Insider Tip</span>
                {isHtml(page.insiderTip) ? (
                  <div className="dest-insider__text" dangerouslySetInnerHTML={{ __html: page.insiderTip }} />
                ) : (
                  <p className="dest-insider__text">{page.insiderTip}</p>
                )}
              </div>
            )}

            {/* Internal Links */}
            <InternalLinks
              pageType={page.pageType}
              country={page.country}
              cityName={page.cityName}
              relatedPages={relatedPages}
              hubPage={hubPage}
            />
          </article>

          {/* RIGHT — Sticky Sidebar */}
          <aside className="dest-sidebar">
            <div className="dest-sidebar__sticky">
              <ApplyCTACard
                cityName={cleanCityName}
                country={page.country}
                requiresPhysical={cd.requiresPhysical}
              />
            </div>
          </aside>
        </div>
      </section>

      {/* ─── DISCLAIMER ───────────────────────────────────────── */}
      {page.disclaimer && (
        <div className="dest-disclaimer">
          <div className="dest-disclaimer__inner">
            <strong>⚠️ Compliance Notice: </strong>
            {page.disclaimer}
          </div>
        </div>
      )}

      {/* ─── RELATED DESTINATIONS ─────────────────────────────── */}
      <RelatedDestinations
        pageType={page.pageType}
        country={page.country}
        region={page.region}
        relatedPages={relatedPages}
        hubPage={hubPage}
      />

      {/* ─── APPLY CTA STRIP ──────────────────────────────────── */}
      <section className="dest-cta-strip">
        <div className="dest-cta-strip__inner">
          <h2 className="dest-cta-strip__title">Ready to Drive in {cleanCityName}?</h2>
          <p className="dest-cta-strip__sub">Apply online in minutes. Digital IDP in 2–4 hours.</p>
          <Link href="/apply" className="dest-cta-strip__btn" id="footer-apply-btn">
            Apply for Your IDP →
          </Link>
          <div className="dest-cta-strip__trust">
            <span>🔒 SSL Secure</span>
            <span>💯 Money-Back</span>
            <span>💳 Razorpay & PayPal</span>
            <span>💬 24/7 Support</span>
          </div>
        </div>
      </section>

      <style>{`
        /* ── Hero ── */
        .dest-hero {
          background: linear-gradient(135deg, #001A66 0%, #0033CC 55%, #1a56e0 100%);
          padding: 64px 24px 100px;
          position: relative;
          clip-path: ellipse(120% 100% at 50% 0%);
        }
        .dest-hero__inner {
          max-width: 860px;
          margin: 0 auto;
          text-align: center;
        }
        .dest-breadcrumb {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-family: var(--font-dmsans);
          font-size: 12px;
          color: rgba(255,255,255,0.6);
          margin-bottom: 20px;
          flex-wrap: wrap;
        }
        .dest-breadcrumb a {
          color: rgba(255,255,255,0.75);
          text-decoration: none;
          transition: color 0.2s;
        }
        .dest-breadcrumb a:hover { color: white; }
        .dest-hero__badge {
          display: inline-flex;
          margin-bottom: 20px;
          padding: 6px 16px;
          border-radius: 9999px;
          color: rgba(255,255,255,0.9);
          letter-spacing: 0.06em;
        }
        .dest-hero__h1 {
          font-family: var(--font-sora);
          font-size: clamp(28px, 5vw, 46px);
          font-weight: 900;
          color: #ffffff;
          line-height: 1.15;
          margin: 0 0 24px;
          text-wrap: balance;
        }
        .dest-hero__badges {
          display: flex;
          gap: 10px;
          justify-content: center;
          flex-wrap: wrap;
          margin-bottom: 28px;
        }
        .dest-trust-badge {
          background: rgba(255,255,255,0.12);
          border: 1px solid rgba(255,255,255,0.2);
          color: rgba(255,255,255,0.95);
          border-radius: 9999px;
          padding: 6px 16px;
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 700;
          backdrop-filter: blur(4px);
        }
        .dest-hero__cta {
          display: inline-block;
          background: #22c55e;
          color: white;
          border-radius: 14px;
          padding: 14px 32px;
          font-family: var(--font-sora);
          font-size: 15px;
          font-weight: 800;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 4px 20px rgba(34,197,94,0.4);
        }
        .dest-hero__cta:hover {
          background: #16a34a;
          transform: translateY(-2px);
          box-shadow: 0 8px 28px rgba(34,197,94,0.5);
        }

        /* ── Main Content ── */
        .dest-content {
          padding: 64px 24px;
          max-width: 1100px;
          margin: 0 auto;
        }
        .dest-content__inner {
          display: grid;
          grid-template-columns: 1fr 340px;
          gap: 48px;
          align-items: start;
        }
        @media (max-width: 900px) {
          .dest-content__inner { grid-template-columns: 1fr; }
          .dest-sidebar__sticky { position: static !important; }
        }

        /* Body text — supports both plain-text paragraphs and rich HTML */
        .dest-body__text {
          font-family: var(--font-dmsans);
          font-size: 16px;
          line-height: 1.85;
          color: #1e293b;
        }
        .dest-body__text p { margin-bottom: 18px; }
        .dest-body__text h2 {
          font-family: var(--font-sora);
          font-size: clamp(18px, 2.5vw, 22px);
          font-weight: 800;
          color: #001A66;
          margin: 32px 0 12px;
          line-height: 1.3;
        }
        .dest-body__text h3 {
          font-family: var(--font-sora);
          font-size: clamp(16px, 2vw, 19px);
          font-weight: 700;
          color: #001A66;
          margin: 24px 0 10px;
          line-height: 1.35;
        }
        .dest-body__text h4 {
          font-family: var(--font-sora);
          font-size: 16px;
          font-weight: 700;
          color: #334155;
          margin: 20px 0 8px;
        }
        .dest-body__text ul,
        .dest-body__text ol {
          padding-left: 24px;
          margin-bottom: 20px;
        }
        .dest-body__text ul { list-style-type: disc; }
        .dest-body__text ol { list-style-type: decimal; }
        .dest-body__text li {
          margin-bottom: 8px;
          line-height: 1.75;
        }
        .dest-body__text strong { font-weight: 700; color: #0f172a; }
        .dest-body__text em { font-style: italic; }
        .dest-body__text a {
          color: #0033CC;
          text-decoration: underline;
          text-underline-offset: 3px;
          transition: color 0.2s;
        }
        .dest-body__text a:hover { color: #001A66; }
        .dest-body__text blockquote {
          border-left: 4px solid #0033CC;
          padding: 12px 20px;
          margin: 24px 0;
          background: #eff6ff;
          border-radius: 0 10px 10px 0;
          font-style: italic;
          color: #334155;
        }
        .dest-body__text img {
          max-width: 100%;
          border-radius: 12px;
          margin: 24px 0;
          border: 1px solid #e2e8f0;
        }
        .dest-body__text hr {
          border: none;
          border-top: 1px solid #e2e8f0;
          margin: 28px 0;
        }

        /* Insider tip */
        .dest-insider {
          background: #eff6ff;
          border-left: 4px solid #001A66;
          border-radius: 0 12px 12px 0;
          padding: 16px 20px;
          margin: 32px 0;
        }
        .dest-insider__label {
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #001A66;
          display: block;
          margin-bottom: 8px;
        }
        .dest-insider__text {
          font-family: var(--font-dmsans);
          font-size: 15px;
          font-style: italic;
          color: #1e293b;
          margin: 0;
        }

        /* Sidebar */
        .dest-sidebar__sticky {
          position: sticky;
          top: 88px;
        }

        /* ── Disclaimer ── */
        .dest-disclaimer {
          background: #fffbeb;
          border-top: 3px solid #fbbf24;
        }
        .dest-disclaimer__inner {
          max-width: 1100px;
          margin: 0 auto;
          padding: 16px 24px;
          font-family: var(--font-dmsans);
          font-size: 12px;
          color: #78350f;
          line-height: 1.6;
        }

        /* ── CTA Strip ── */
        .dest-cta-strip {
          background: linear-gradient(135deg, #001A66 0%, #0033CC 100%);
          padding: 72px 24px;
          text-align: center;
        }
        .dest-cta-strip__inner { max-width: 700px; margin: 0 auto; }
        .dest-cta-strip__title {
          font-family: var(--font-sora);
          font-size: clamp(26px, 4vw, 38px);
          font-weight: 900;
          color: #ffffff;
          margin: 0 0 12px;
        }
        .dest-cta-strip__sub {
          font-family: var(--font-dmsans);
          font-size: 16px;
          color: rgba(255,255,255,0.75);
          margin: 0 0 28px;
        }
        .dest-cta-strip__btn {
          display: inline-block;
          background: #22c55e;
          color: white;
          border-radius: 14px;
          padding: 16px 40px;
          font-family: var(--font-sora);
          font-size: 16px;
          font-weight: 800;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 4px 20px rgba(34,197,94,0.4);
          margin-bottom: 28px;
          display: inline-block;
        }
        .dest-cta-strip__btn:hover {
          background: #16a34a;
          transform: translateY(-2px);
        }
        .dest-cta-strip__trust {
          display: flex;
          gap: 20px;
          justify-content: center;
          flex-wrap: wrap;
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 700;
          color: rgba(255,255,255,0.65);
          letter-spacing: 0.04em;
        }
      `}</style>
    </main>
  );
}
