'use client';
import { WHATSAPP_URL } from "@/lib/contact";

import Link from 'next/link';
import { useCurrency } from '@/hooks/useCurrency';

interface ApplyCTACardProps {
  cityName: string;
  country: string;
  requiresPhysical: boolean;
}

export function ApplyCTACard({ cityName, country, requiresPhysical }: ApplyCTACardProps) {
  const { format } = useCurrency();

  return (
    <div className="cta-cards">
      {/* Primary Apply Card */}
      <div className="apply-card">
        <div className="apply-card__header">
          <span className="apply-card__eyebrow">Get Your IDP</span>
          <h3 className="apply-card__title">Drive in {cityName}</h3>
        </div>

        <div className="apply-card__pricing">
          <span className="apply-card__from">from</span>
          <span className="apply-card__price">{format(21)}</span>
        </div>

        <Link href="/apply" className="apply-card__cta" id="apply-cta-sidebar">
          Apply Online Now →
        </Link>

        <ul className="apply-card__trust">
          <li>🛡️ 100% Money-Back Guarantee</li>
          <li>⚡ Digital: 2–4 hours</li>
          <li>📦 Physical kit: 7–15 days</li>
          <li>✅ All major car rental agencies</li>
        </ul>
      </div>

      {/* Document Type Card */}
      <div className="doc-card">
        <h4 className="doc-card__title">Which IDP do you need?</h4>

        {requiresPhysical && (
          <div className="doc-card__warn">
            ⚠️ Physical IDP required in {country}
          </div>
        )}

        <div className="doc-option">
          <div className="doc-option__info">
            <span className="doc-option__name">Digital IDP</span>
            <span className="doc-option__desc">PDF sent to email in 2hrs</span>
          </div>
          <div className="doc-option__right">
            <span className="doc-option__price">{format(21)}</span>
            <Link href="/apply?type=digital" className="doc-option__btn">Apply →</Link>
          </div>
        </div>

        <div className={`doc-option ${requiresPhysical ? 'doc-option--featured' : ''}`}>
          <div className="doc-option__info">
            <span className="doc-option__name">
              NFC Smart Kit
              {requiresPhysical && <span className="doc-option__rec">Recommended</span>}
            </span>
            <span className="doc-option__desc">Physical booklet + NFC card</span>
          </div>
          <div className="doc-option__right">
            <span className="doc-option__price">{format(32)}</span>
            <Link href="/apply?type=nfc_kit" className="doc-option__btn doc-option__btn--primary">Apply →</Link>
          </div>
        </div>
      </div>

      {/* WhatsApp Card */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="wa-card"
        id="whatsapp-support-link"
      >
        <span className="wa-icon">💬</span>
        <div>
          <span className="wa-title">Need help? Chat on WhatsApp</span>
          <span className="wa-sub">Available 24/7 for IDP queries</span>
        </div>
        <span className="wa-arrow">→</span>
      </a>

      <style>{`
        .cta-cards { display: flex; flex-direction: column; gap: 16px; }

        /* Apply Card */
        .apply-card {
          background: linear-gradient(145deg, #001A66 0%, #0033CC 100%);
          border-radius: 20px;
          padding: 24px;
          color: white;
        }
        .apply-card__eyebrow {
          font-family: var(--font-sora);
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          opacity: 0.6;
          display: block;
          margin-bottom: 4px;
        }
        .apply-card__title {
          font-family: var(--font-sora);
          font-size: 20px;
          font-weight: 900;
          margin: 0 0 16px;
        }
        .apply-card__pricing {
          display: flex;
          align-items: baseline;
          gap: 6px;
          margin-bottom: 16px;
        }
        .apply-card__from {
          font-family: var(--font-dmsans);
          font-size: 12px;
          opacity: 0.7;
        }
        .apply-card__price {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: #FFD700;
        }
        .apply-card__cta {
          display: block;
          text-align: center;
          background: #22c55e;
          color: white;
          border-radius: 12px;
          padding: 14px;
          font-family: var(--font-sora);
          font-size: 14px;
          font-weight: 800;
          text-decoration: none;
          transition: background 0.2s ease;
          margin-bottom: 16px;
        }
        .apply-card__cta:hover { background: #16a34a; }
        .apply-card__trust {
          list-style: none;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .apply-card__trust li {
          font-family: var(--font-dmsans);
          font-size: 12px;
          opacity: 0.85;
        }

        /* Doc Card */
        .doc-card {
          background: #ffffff;
          border: 1.5px solid #e2e8f0;
          border-radius: 16px;
          padding: 20px;
        }
        .doc-card__title {
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          color: #001A66;
          margin: 0 0 12px;
        }
        .doc-card__warn {
          background: #fef2f2;
          border: 1px solid #fca5a5;
          color: #dc2626;
          border-radius: 8px;
          padding: 8px 12px;
          font-family: var(--font-dmsans);
          font-size: 12px;
          font-weight: 600;
          margin-bottom: 12px;
        }
        .doc-option {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          padding: 10px 0;
          border-bottom: 1px solid #f1f5f9;
        }
        .doc-option:last-child { border-bottom: none; }
        .doc-option--featured { background: #eff6ff; border-radius: 8px; padding: 10px 8px; margin: 0 -8px; }
        .doc-option__info { display: flex; flex-direction: column; gap: 2px; }
        .doc-option__name {
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 800;
          color: #001A66;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .doc-option__rec {
          background: #0033CC;
          color: white;
          border-radius: 4px;
          padding: 1px 6px;
          font-size: 9px;
          font-weight: 800;
        }
        .doc-option__desc {
          font-family: var(--font-dmsans);
          font-size: 11px;
          color: #64748b;
        }
        .doc-option__right { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; }
        .doc-option__price {
          font-family: var(--font-sora);
          font-size: 14px;
          font-weight: 900;
          color: #001A66;
        }
        .doc-option__btn {
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 800;
          color: #0033CC;
          text-decoration: none;
          border: 1.5px solid #0033CC;
          border-radius: 6px;
          padding: 3px 10px;
          transition: all 0.2s ease;
        }
        .doc-option__btn:hover { background: #0033CC; color: white; }
        .doc-option__btn--primary { background: #0033CC; color: white; }
        .doc-option__btn--primary:hover { background: #001A66; border-color: #001A66; }

        /* WhatsApp Card */
        .wa-card {
          display: flex;
          align-items: center;
          gap: 12px;
          background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
          border-radius: 14px;
          padding: 16px;
          text-decoration: none;
          color: white;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .wa-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(37,211,102,0.3); }
        .wa-icon { font-size: 24px; flex-shrink: 0; }
        .wa-title {
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          display: block;
        }
        .wa-sub {
          font-family: var(--font-dmsans);
          font-size: 11px;
          opacity: 0.85;
          display: block;
        }
        .wa-arrow { margin-left: auto; font-size: 18px; opacity: 0.7; }
      `}</style>
    </div>
  );
}
