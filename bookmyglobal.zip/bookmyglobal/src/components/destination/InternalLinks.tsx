import Link from 'next/link';

interface LinkedPage {
  slug: string;
  urlPath: string;
  cityName: string;
  country: string;
  pageType: string;
}

interface InternalLinksProps {
  pageType: string;
  country: string;
  cityName: string;
  relatedPages: LinkedPage[];
  hubPage: { slug: string; urlPath: string; cityName: string } | null;
}

export function InternalLinks({ pageType, country, cityName, relatedPages, hubPage }: InternalLinksProps) {
  if (pageType === 'HUB') {
    return (
      <nav aria-label={`Cities in ${country}`} style={{ marginTop: '32px' }}>
        <p className="il-label">Cities in {country}:</p>
        <div className="il-city-grid">
          {relatedPages.map((p) => (
            <Link key={p.slug} href={`/idp/${p.slug}`} className="il-city-card">
              <span className="il-city-name">{p.cityName.replace(/\s*[Hh]ub\s*$/, "")}</span>
              <span className="il-arrow">→</span>
            </Link>
          ))}
        </div>

        <style>{`
          .il-label {
            font-family: var(--font-sora);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: #64748b;
            margin-bottom: 12px;
          }
          .il-city-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
          }
          .il-city-card {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(0,51,204,0.07);
            border: 1.5px solid rgba(0,51,204,0.15);
            border-radius: 10px;
            padding: 8px 14px;
            font-family: var(--font-sora);
            font-size: 12px;
            font-weight: 700;
            color: #0033CC;
            text-decoration: none;
            transition: all 0.2s ease;
          }
          .il-city-card:hover {
            background: #0033CC;
            color: #ffffff;
            border-color: #0033CC;
            transform: translateY(-1px);
          }
          .il-arrow { font-size: 14px; }
        `}</style>
      </nav>
    );
  }

  // CITY page — show hub + siblings
  return (
    <nav aria-label={`Other IDP pages for ${country}`} style={{ marginTop: '32px' }}>
      {hubPage && (
        <Link href={`/idp/${hubPage.slug}`} className="il-hub-back">
          ← {country} IDP Guide
        </Link>
      )}
      {relatedPages.length > 0 && (
        <>
          <p className="il-label" style={{ marginTop: hubPage ? '16px' : '0' }}>
            Other cities:
          </p>
          <div className="il-city-grid">
            {relatedPages.map((p) => (
              <Link key={p.slug} href={`/idp/${p.slug}`} className="il-city-card">
                <span className="il-city-name">{p.cityName.replace(/\s*[Hh]ub\s*$/, "")}</span>
                <span className="il-arrow">→</span>
              </Link>
            ))}
          </div>
        </>
      )}

      <style>{`
        .il-hub-back {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #001A66;
          color: #ffffff;
          border-radius: 10px;
          padding: 8px 16px;
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 800;
          text-decoration: none;
          transition: background 0.2s ease;
        }
        .il-hub-back:hover { background: #0033CC; }
        .il-label {
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #64748b;
          margin-bottom: 10px;
        }
        .il-city-grid { display: flex; flex-wrap: wrap; gap: 8px; }
        .il-city-card {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: rgba(0,51,204,0.07);
          border: 1.5px solid rgba(0,51,204,0.15);
          border-radius: 10px;
          padding: 8px 14px;
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 700;
          color: #0033CC;
          text-decoration: none;
          transition: all 0.2s ease;
        }
        .il-city-card:hover {
          background: #0033CC;
          color: #fff;
          border-color: #0033CC;
          transform: translateY(-1px);
        }
        .il-arrow { font-size: 14px; }
      `}</style>
    </nav>
  );
}
