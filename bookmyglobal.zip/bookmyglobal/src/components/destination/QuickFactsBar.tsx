import React from 'react';

interface QuickFactsBarProps {
  drivingSide: string;    // 'LEFT' | 'RIGHT'
  requiresPhysical: boolean;
  maxValidity: number;
  convention: string;     // 'GENEVA' | 'VIENNA' | 'BOTH'
}

export function QuickFactsBar({ drivingSide, requiresPhysical, maxValidity, convention }: QuickFactsBarProps) {
  const facts = [
    {
      icon: '🚗',
      label: 'Drive Side',
      value: drivingSide === 'LEFT' ? 'Left-hand traffic' : 'Right-hand traffic',
    },
    {
      icon: '⚡',
      label: 'Digital IDP',
      value: requiresPhysical ? 'Physical only' : 'Accepted',
      highlight: !requiresPhysical,
      warn: requiresPhysical,
    },
    {
      icon: '📅',
      label: 'Max Validity',
      value: maxValidity === 1 ? '1 Year' : `${maxValidity} Years`,
    },
    {
      icon: '🌍',
      label: 'Convention',
      value: convention === 'BOTH' ? 'Geneva & Vienna' : convention === 'GENEVA' ? 'Geneva 1949' : 'Vienna 1968',
    },
  ];

  return (
    <div className="qfb-wrapper">
      <div className="qfb-inner">
        {facts.map((fact) => (
          <div key={fact.label} className={`qfb-pill ${fact.warn ? 'qfb-pill--warn' : ''} ${fact.highlight ? 'qfb-pill--ok' : ''}`}>
            <span className="qfb-icon">{fact.icon}</span>
            <div className="qfb-text">
              <span className="qfb-label">{fact.label}</span>
              <span className="qfb-value">{fact.value}</span>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        .qfb-wrapper {
          background: linear-gradient(135deg, rgba(0,26,102,0.06) 0%, rgba(0,51,204,0.08) 100%);
          border-top: 1px solid rgba(0,51,204,0.12);
          border-bottom: 1px solid rgba(0,51,204,0.12);
          padding: 20px 0;
        }
        .qfb-inner {
          max-width: 1100px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
          justify-content: center;
        }
        .qfb-pill {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #ffffff;
          border: 1.5px solid #e2e8f0;
          border-radius: 14px;
          padding: 10px 18px;
          min-width: 190px;
          flex: 1;
          box-shadow: 0 2px 8px rgba(0,0,0,0.04);
          transition: transform 0.2s ease;
        }
        .qfb-pill:hover { transform: translateY(-2px); }
        .qfb-pill--warn { border-color: #f87171; background: #fff5f5; }
        .qfb-pill--ok   { border-color: #4ade80; background: #f0fdf4; }
        .qfb-icon { font-size: 22px; flex-shrink: 0; }
        .qfb-text { display: flex; flex-direction: column; }
        .qfb-label {
          font-family: var(--font-sora);
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #64748b;
        }
        .qfb-value {
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          color: #001A66;
        }
        .qfb-pill--warn .qfb-value { color: #dc2626; }
        .qfb-pill--ok  .qfb-value  { color: #16a34a; }
        @media (max-width: 640px) {
          .qfb-pill { min-width: calc(50% - 6px); flex: none; }
        }
      `}</style>
    </div>
  );
}
