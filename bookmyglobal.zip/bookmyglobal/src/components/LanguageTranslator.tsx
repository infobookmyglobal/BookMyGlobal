"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { useGeoStore } from "@/store/geoStore";

const RESET_GUARD = "idp_en_reset";

/* ─── Cookie helpers ────────────────────────────────────────────────────── */
const setGTCookie = (lang: string) => {
  const h = window.location.hostname;
  const val = `/en/${lang}`;
  const base = `googtrans=${val}; path=/; max-age=31536000`;
  document.cookie = base;
  document.cookie = `${base}; domain=${h}`;
  document.cookie = `${base}; domain=.${h}`;
};

const clearGTCookie = () => {
  // Clear host-only (no domain specified)
  document.cookie = "googtrans=; path=/; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  document.cookie = "googtrans=; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT";
  
  // Clear on all subdomains and parent domains
  const host = window.location.hostname;
  const parts = host.split('.');
  for (let i = 0; i < parts.length; i++) {
    const domain = parts.slice(i).join('.');
    if (domain) {
      document.cookie = `googtrans=; path=/; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=${domain}`;
      document.cookie = `googtrans=; path=/; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=.${domain}`;
      document.cookie = `googtrans=; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=${domain}`;
      document.cookie = `googtrans=; max-age=0; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=.${domain}`;
    }
  }
};

const getGTCookie = () => {
  const match = document.cookie.match(/(?:^|;\s*)googtrans=([^;]*)/);
  return match ? match[1] : null;
};

/* ─── GT helpers ────────────────────────────────────────────────────────── */
function applyGT(lang: string, attempt = 0) {
  if (attempt > 15) return;
  const select = document.querySelector("select.goog-te-combo") as HTMLSelectElement | null;
  if (select) {
    select.value = lang === "en" ? "" : lang;
    select.dispatchEvent(new Event("change"));
    return;
  }
  const w = window as any;
  if (typeof w.doGTranslate === "function") {
    w.doGTranslate(lang === "en" ? "en|en" : `en|${lang}`);
    return;
  }
  setTimeout(() => applyGT(lang, attempt + 1), 400);
}

function isPageTranslated() {
  return (
    document.documentElement.classList.contains("translated-ltr") ||
    document.documentElement.classList.contains("translated-rtl") ||
    document.body.classList.contains("translated-ltr") ||
    document.body.classList.contains("translated-rtl")
  );
}

/* ─── Component ─────────────────────────────────────────────────────────── */
export function LanguageTranslator() {
  const { language } = useGeoStore();
  const [hydrated, setHydrated] = useState(false);
  const gtReady = useRef(false);
  const pathname = usePathname();

  const prevLangRef = useRef<string | null>(null);

  /* Wait for Zustand persist hydration and reset to English on full page load */
  useEffect(() => {
    const handleHydration = () => {
      // Force language to English on full page load / refresh
      useGeoStore.getState().setGeo({ language: "en" });
      clearGTCookie();
      
      // Remove any leftover translated classes from the document
      document.documentElement.classList.remove("translated-ltr", "translated-rtl");
      document.body.classList.remove("translated-ltr", "translated-rtl");
      
      setHydrated(true);
    };

    if (useGeoStore.persist.hasHydrated()) {
      handleHydration();
    } else {
      const unsub = useGeoStore.persist.onFinishHydration(() => handleHydration());
      return unsub;
    }
  }, []);

  /* Inject GT script once, only if non-English language is selected */
  useEffect(() => {
    if (!hydrated || gtReady.current) return;
    if (language === "en") return;
    gtReady.current = true;
    (window as any).googleTranslateElementInit = () => {
      new (window as any).google.translate.TranslateElement(
        { pageLanguage: "en", autoDisplay: false },
        "google_translate_element"
      );
    };
    if (!document.getElementById("gt-script")) {
      const s = document.createElement("script");
      s.id = "gt-script";
      s.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      document.body.appendChild(s);
    }
  }, [hydrated, language]);

  /* Language change handler */
  useEffect(() => {
    if (!hydrated) return;

    const prevLang = prevLangRef.current;
    prevLangRef.current = language;

    if (language && language !== "en") {
      /* ── Switch TO non-English ── */
      setGTCookie(language);
      const t = setTimeout(() => applyGT(language), 200);
      return () => clearTimeout(t);
    }

    /* ── Switch BACK to English ── */
    clearGTCookie();

    // If we just did a reload to reset English, stop here (guard prevents loop)
    if (sessionStorage.getItem(RESET_GUARD)) {
      sessionStorage.removeItem(RESET_GUARD);
      return;
    }

    const wasTranslated = prevLang && prevLang !== "en";
    if (wasTranslated || isPageTranslated() || getGTCookie()) {
      sessionStorage.setItem(RESET_GUARD, "1");
      window.location.reload();
      return;
    }
  }, [language, hydrated]);

  /* Re-apply translation after client-side navigation */
  useEffect(() => {
    if (!hydrated || !language || language === "en") return;
    const t = setTimeout(() => applyGT(language), 700);
    return () => clearTimeout(t);
  }, [pathname, hydrated, language]);

  return (
    <>
      <div id="google_translate_element" style={{ display: "none" }} />
      <style jsx global>{`
        .skiptranslate { display: none !important; }
        body { top: 0px !important; position: static !important; }
        body.translated-ltr, body.translated-rtl {
          top: 0px !important;
          position: static !important;
        }
        #goog-gt-tt { display: none !important; }
        .goog-te-banner-frame { display: none !important; }
        .goog-tooltip, .goog-tooltip:hover { display: none !important; }
        .goog-text-highlight {
          background-color: transparent !important;
          border: none !important;
          box-shadow: none !important;
        }
      `}</style>
    </>
  );
}
