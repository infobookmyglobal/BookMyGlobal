import { NextRequest, NextResponse } from "next/server";
import { checkRoleApi } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const isAdmin = await checkRoleApi("ADMIN");
  if (!isAdmin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(req.url);
  const language = url.searchParams.get("language") || "en";

  const translations = await prisma.translation.findMany({
    where: { language },
    orderBy: { key: "asc" },
  });

  return NextResponse.json(translations);
}

export async function POST(req: NextRequest) {
  const isAdmin = await checkRoleApi("ADMIN");
  if (!isAdmin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { language, key, value } = await req.json();
    if (!language || !key) {
      return NextResponse.json({ error: "Language and key are required" }, { status: 400 });
    }

    const translation = await prisma.translation.upsert({
      where: {
        language_key: { language, key },
      },
      update: { value },
      create: { language, key, value },
    });

    return NextResponse.json(translation);
  } catch (error: any) {
    console.error("Translation upsert failed:", error);
    return NextResponse.json({ error: error.message || "Failed to update translation" }, { status: 500 });
  }
}
