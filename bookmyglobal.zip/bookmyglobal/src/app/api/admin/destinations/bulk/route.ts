import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkRoleApi } from "@/lib/auth";
import { revalidatePath } from 'next/cache';

export async function POST(req: Request) {
  try {
    const isAdmin = await checkRoleApi("ADMIN");
    if (!isAdmin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const items = Array.isArray(body) ? body : [body];

    const results = [];
    for (const item of items) {
      if (!item.country) {
        continue;
      }
      
      const pageType = (item.pageType || 'HUB').toUpperCase() as 'HUB' | 'CITY';
      const cityName = item.cityName || (pageType === 'HUB' ? `${item.country} Hub` : '');
      
      // Auto-generate slug if missing
      const countrySlug = item.country.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      const citySlug = cityName.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      
      let slug = item.slug;
      if (!slug) {
        if (pageType === 'HUB') {
          slug = `idp-${countrySlug}`;
        } else {
          slug = `idp-${countrySlug}-${citySlug}`;
        }
      }
      slug = slug.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

      const urlPath = item.urlPath || `/idp/${slug}`;
      const metaTitle = item.metaTitle || (pageType === 'HUB' ? `IDP for ${item.country} – BookMyGlobal` : `IDP for ${cityName} – Drive in ${item.country} Legally`);
      const metaDescription = item.metaDescription || (pageType === 'HUB' ? `Applying for your International Driving Permit in ${item.country}. Valid in 189+ countries. WhatsApp delivery in 2 hours.` : `Find IDP rules, driving tips, and requirements for ${cityName}, ${item.country}. Apply online now.`);
      const h1 = item.h1 || (pageType === 'HUB' ? `Get Your International Driving Permit for ${item.country}` : `Get Your International Driving Permit in ${cityName}, ${item.country}`);
      const disclaimer = item.disclaimer || 'BookMyGlobal is a private independent travel documentation support platform providing International Driving Permit (IDP) assistance and multilingual translation support services. BookMyGlobal is not affiliated with any government authority, RTO, DMV, or licensing agency. Travelers should verify local regulations independently and always carry a valid domestic driving license.';

      const upserted = await prisma.destinationPage.upsert({
        where: { slug },
        update: {
          urlPath,
          pageType,
          region: item.region || 'Global',
          country: item.country,
          cityName,
          metaTitle,
          metaDescription,
          h1,
          bodyContent: item.bodyContent || '',
          insiderTip: item.insiderTip || '',
          internalLinks: item.internalLinks || '[]',
          disclaimer,
          structuredData: item.structuredData || null,
          canonicalUrl: item.canonicalUrl || null,
          isActive: item.isActive !== undefined ? (String(item.isActive).toLowerCase() === 'false' ? false : true) : true,
        },
        create: {
          slug,
          urlPath,
          pageType,
          region: item.region || 'Global',
          country: item.country,
          cityName,
          metaTitle,
          metaDescription,
          h1,
          bodyContent: item.bodyContent || '',
          insiderTip: item.insiderTip || '',
          internalLinks: item.internalLinks || '[]',
          disclaimer,
          structuredData: item.structuredData || null,
          canonicalUrl: item.canonicalUrl || null,
          isActive: item.isActive !== undefined ? (String(item.isActive).toLowerCase() === 'false' ? false : true) : true,
        },
      });
      // Revalidate page cache
      revalidatePath(`/idp/${upserted.slug}`);
      results.push(upserted);
    }

    return NextResponse.json({ success: true, count: results.length, data: results });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: e.message || 'Failed to bulk import destinations' }, { status: 500 });
  }
}
