import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { checkRoleApi } from "@/lib/auth";
import { revalidatePath } from "next/cache";

const CREATE_FIELDS = [
  "slug", "urlPath", "pageType", "region", "country", "cityName", "metaTitle",
  "metaDescription", "h1", "bodyContent", "insiderTip", "internalLinks",
  "disclaimer", "structuredData", "canonicalUrl", "isActive",
] as const;

export async function GET() {
  try {
    if (!(await checkRoleApi("ADMIN"))) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const pages = await prisma.destinationPage.findMany({
      orderBy: [{ country: "asc" }, { pageType: "desc" }],
    });

    return NextResponse.json(pages);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to fetch destinations" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    if (!(await checkRoleApi("ADMIN"))) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    // Whitelist fields instead of passing the raw request body to Prisma
    const data = Object.fromEntries(
      CREATE_FIELDS.filter((k) => body[k] !== undefined).map((k) => [k, body[k]])
    ) as any;

    const page = await prisma.destinationPage.create({ data });
    revalidatePath(`/idp/${page.slug}`);

    return NextResponse.json(page, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to create destination" }, { status: 500 });
  }
}
