import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { checkRoleApi } from '@/lib/auth';
import { revalidatePath } from 'next/cache';

interface Props {
  params: Promise<{ id: string }>;
}

export async function PATCH(req: Request, { params }: Props) {
  try {
    if (!(await checkRoleApi('ADMIN'))) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { id } = await params;
    const body = await req.json();

    const allowed = ['isActive', 'metaTitle', 'metaDescription', 'h1', 'bodyContent', 'insiderTip', 'structuredData', 'canonicalUrl'];
    const data = Object.fromEntries(
      Object.entries(body).filter(([key]) => allowed.includes(key))
    );

    const updated = await prisma.destinationPage.update({ where: { id }, data });

    // Revalidate live destination page immediately
    revalidatePath(`/idp/${updated.slug}`);

    return NextResponse.json(updated);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Failed to update destination' }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: Props) {
  try {
    if (!(await checkRoleApi('ADMIN'))) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { id } = await params;
    await prisma.destinationPage.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Failed to delete destination' }, { status: 500 });
  }
}

