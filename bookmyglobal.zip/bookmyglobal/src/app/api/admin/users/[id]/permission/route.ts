import { NextRequest, NextResponse } from "next/server";
import { checkRoleApi } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendUserPermissionDecisionEmail } from "@/lib/ses";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkRoleApi("ADMIN"))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const { status } = await req.json().catch(() => ({ status: "" }));

  if (status !== "APPROVED" && status !== "REJECTED") {
    return NextResponse.json({ error: "Status must be APPROVED or REJECTED" }, { status: 400 });
  }

  const target = await prisma.user.findUnique({ where: { id } });
  if (!target) return NextResponse.json({ error: "User not found" }, { status: 404 });

  const user = await prisma.user.update({ where: { id }, data: { multipleIdpStatus: status } });

  try {
    await sendUserPermissionDecisionEmail(user, status === "APPROVED");
  } catch (err) {
    console.error("Permission decision email failed:", err);
  }

  return NextResponse.json({ success: true });
}
