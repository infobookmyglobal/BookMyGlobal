import { NextRequest, NextResponse } from "next/server";
import { checkRoleApi } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ApplicationForPDF } from "@/types";
import { getS3KeyFromUrl } from "@/lib/s3";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const isAdmin = await checkRoleApi("ADMIN");
  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      fullName,
      email,
      phone,
      country,
      dob,
      licenseNumber,
      licenseIssueDate,
      licenseExpiryDate,
      gender,
      countryOfBirth,
      countryOfResidence,
      licenseClass,
      parentName,
      destinationCountry,
      address,
      profilePhotoUrl,
      licenseUrl,
      passportUrl,
      shippingAddress,
    } = body;

    // Check if application exists
    const application = await prisma.application.findUnique({
      where: { id },
    });

    if (!application) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }

    let newAdminNotes = application.adminNotes || "";
    if (shippingAddress !== undefined) {
      const shippingRegex = /([\s|]*SHIPPING ADDRESS:\s*)([^\n|]*)/i;
      if (shippingRegex.test(newAdminNotes)) {
        newAdminNotes = newAdminNotes.replace(shippingRegex, `$1${shippingAddress}`);
      } else if (shippingAddress) {
        newAdminNotes = newAdminNotes ? `${newAdminNotes} | SHIPPING ADDRESS: ${shippingAddress}` : `SHIPPING ADDRESS: ${shippingAddress}`;
      }
    }

    const cleanUrlOrKey = (val: any) => {
      if (typeof val !== "string") return val;
      return getS3KeyFromUrl(val);
    };

    // Update application details
    const updated = await prisma.application.update({
      where: { id },
      data: {
        fullName: fullName !== undefined ? fullName : application.fullName,
        email: email !== undefined ? email : application.email,
        phone: phone !== undefined ? phone : application.phone,
        country: country !== undefined ? country : application.country,
        dob: dob !== undefined ? (dob ? new Date(dob) : null) : application.dob,
        licenseNumber: licenseNumber !== undefined ? licenseNumber : application.licenseNumber,
        licenseIssueDate: licenseIssueDate !== undefined ? (licenseIssueDate ? new Date(licenseIssueDate) : null) : application.licenseIssueDate,
        licenseExpiryDate: licenseExpiryDate !== undefined ? (licenseExpiryDate ? new Date(licenseExpiryDate) : null) : application.licenseExpiryDate,
        gender: gender !== undefined ? gender : application.gender,
        countryOfBirth: countryOfBirth !== undefined ? countryOfBirth : application.countryOfBirth,
        countryOfResidence: countryOfResidence !== undefined ? countryOfResidence : application.countryOfResidence,
        licenseClass: licenseClass !== undefined ? licenseClass : application.licenseClass,
        parentName: parentName !== undefined ? parentName : application.parentName,
        destinationCountry: destinationCountry !== undefined ? destinationCountry : application.destinationCountry,
        address: address !== undefined ? address : application.address,
        adminNotes: newAdminNotes,
        profilePhotoUrl: profilePhotoUrl !== undefined ? cleanUrlOrKey(profilePhotoUrl) : application.profilePhotoUrl,
        licenseUrl: licenseUrl !== undefined ? cleanUrlOrKey(licenseUrl) : application.licenseUrl,
        passportUrl: passportUrl !== undefined ? cleanUrlOrKey(passportUrl) : application.passportUrl,
      },
    });

    // If application was already approved, we must regenerate the PDFs!
    let pdfRegenerated = false;
    if (updated.status === "APPROVED" || updated.status === "COMPLETED") {
      try {
        const { generateQRCode } = await import("@/lib/qr");
        const { generateIDPBooklet, generateIDPCard } = await import("@/lib/pdf");
        const { uploadFile, deleteObject } = await import("@/lib/s3");

        const idpNumber = updated.idpNumber || "";
        const qrBytes = await generateQRCode(updated.id);
        const qrCodeDataUrl = `data:image/png;base64,${qrBytes.toString('base64')}`;

        let profilePhotoBytes: Buffer | null = null;
        if (updated.profilePhotoUrl) {
          const { getPresignedDownloadUrl } = await import("@/lib/s3");
          try {
            const photoDownloadUrl = await getPresignedDownloadUrl(updated.profilePhotoUrl, 300);
            const res = await fetch(photoDownloadUrl);
            if (res.ok) {
              profilePhotoBytes = Buffer.from(await res.arrayBuffer());
            }
          } catch (err) {
            console.error("Failed to fetch profile photo in update-pdf-regeneration:", err);
          }
        }

        const issueDate = updated.createdAt;
        const expiryDate = new Date(updated.createdAt);
        expiryDate.setFullYear(issueDate.getFullYear() + updated.validity);

        const appForPDF: ApplicationForPDF = {
          id: updated.id,
          idpNumber,
          fullName: updated.fullName,
          address: updated.address || '',
          country: updated.country,
          countryOfBirth: updated.countryOfBirth || updated.country,
          countryOfResidence: updated.countryOfResidence || updated.country,
          dob: updated.dob || new Date(),
          gender: updated.gender || 'MALE',
          licenseNumber: updated.licenseNumber || '',
          licenseClass: updated.licenseClass || 'B',
          parentName: updated.parentName || '',
          profilePhotoUrl: updated.profilePhotoUrl || '',
          issueDate,
          expiryDate,
          validity: updated.validity,
          destinationCountry: updated.destinationCountry || '',
        };

        const bookletBuffer = await generateIDPBooklet(appForPDF, qrBytes, profilePhotoBytes);
        const idCardBuffer = await generateIDPCard(appForPDF, qrBytes, profilePhotoBytes);

        // Delete old files from S3 if they exist
        if (updated.pdfBookletUrl) {
          try {
            await deleteObject(updated.pdfBookletUrl);
          } catch (err) {
            console.error("Failed to delete old booklet PDF in update:", err);
          }
        }
        if (updated.pdfIdCardUrl) {
          try {
            await deleteObject(updated.pdfIdCardUrl);
          } catch (err) {
            console.error("Failed to delete old idcard PDF in update:", err);
          }
        }

        // Define unique S3 paths with a timestamp cache-buster
        const timestamp = Date.now();
        const bookletKey = `idps/${updated.id}/booklet_${timestamp}.pdf`;
        const idCardKey = `idps/${updated.id}/idcard_${timestamp}.pdf`;

        await uploadFile(bookletKey, Buffer.from(bookletBuffer), "application/pdf");
        await uploadFile(idCardKey, Buffer.from(idCardBuffer), "application/pdf");

        await prisma.application.update({
          where: { id: updated.id },
          data: {
            qrCode: qrCodeDataUrl,
            pdfBookletUrl: bookletKey,
            pdfIdCardUrl: idCardKey,
            pdfRegeneratedAt: new Date(),
          },
        });
        pdfRegenerated = true;
      } catch (pdfErr) {
        console.error("Failed to regenerate PDFs after application edit:", pdfErr);
      }
    }

    return NextResponse.json({ success: true, pdfRegenerated });
  } catch (error: unknown) {
    console.error("Failed to update application:", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Failed to update application" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const isAdmin = await checkRoleApi("ADMIN");
  if (!isAdmin) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    // 1. Find the payment associated with the application to delete any commissions
    const payment = await prisma.payment.findUnique({
      where: { applicationId: id },
    });

    if (payment) {
      // Delete associated commissions
      await prisma.commission.deleteMany({
        where: { paymentId: payment.id },
      });
    }

    // 2. Delete associated shipment
    await prisma.shipment.deleteMany({
      where: { applicationId: id },
    });

    // 3. Delete associated payment
    await prisma.payment.deleteMany({
      where: { applicationId: id },
    });

    // 4. Delete the application
    await prisma.application.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: "Application deleted successfully" });
  } catch (error: unknown) {
    console.error("Failed to delete application:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to delete application" },
      { status: 500 }
    );
  }
}

