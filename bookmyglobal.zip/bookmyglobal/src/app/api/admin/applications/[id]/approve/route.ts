import { NextRequest, NextResponse } from "next/server";
import { checkRoleApi } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { issuePermitForApplication } from "@/lib/issuePermit";
import { sendApplicationApprovedEmail } from "@/lib/ses";

export const maxDuration = 30;

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkRoleApi("ADMIN"))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;

  const application = await prisma.application.findUnique({ where: { id } });
  if (!application) {
    return NextResponse.json({ error: "Application not found" }, { status: 404 });
  }

  try {
    const issued = await issuePermitForApplication(application);

    const updated = await prisma.application.update({
      where: { id },
      data: {
        status: "APPROVED",
        idpNumber: issued.idpNumber,
        qrCode: issued.qrCodeDataUrl,
        pdfBookletUrl: issued.bookletKey,
        pdfIdCardUrl: issued.idCardKey,
        pdfRegeneratedAt: new Date(),
        rejectionReason: null,
      },
    });

    // Email links go through our own authenticated download routes
    const appUrl = (process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/$/, "");
    try {
      await sendApplicationApprovedEmail(updated, `${appUrl}/card/${id}`, `${appUrl}/booklet/${id}`);
    } catch (emailErr) {
      console.error("Approval email failed (application is still approved):", emailErr);
    }

    return NextResponse.json({ success: true, idpNumber: updated.idpNumber });
  } catch (error: any) {
    console.error("Approval / PDF generation failed:", error);
    return NextResponse.json(
      { error: error?.message || "Approval and PDF generation failed" },
      { status: 500 }
    );
  }
}
