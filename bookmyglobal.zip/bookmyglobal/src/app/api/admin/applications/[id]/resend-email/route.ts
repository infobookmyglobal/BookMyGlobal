import { NextRequest, NextResponse } from "next/server";
import { checkRoleApi } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  sendEmail,
  applicationConfirmationEmail,
  applicationRejectedEmail,
  sendApplicationApprovedEmail,
  shippingDispatchedEmail,
} from "@/lib/ses";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await checkRoleApi("ADMIN"))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const { emailType } = await req.json().catch(() => ({ emailType: "" }));

  const app = await prisma.application.findUnique({ where: { id }, include: { shipment: true } });
  if (!app) return NextResponse.json({ error: "Application not found" }, { status: 404 });

  const base = {
    id: app.id,
    productType: app.productType,
    validity: app.validity,
    finalAmount: app.finalAmount,
    currency: app.currency,
    fullName: app.fullName,
    email: app.email,
    phone: app.phone,
    country: app.country,
    couponCode: app.couponCode,
    idpNumber: app.idpNumber,
    rejectionReason: app.rejectionReason,
  };
  const appUrl = (process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/$/, "");

  try {
    switch (emailType) {
      case "confirmation":
        await sendEmail(app.email, "Your IDP application has been received", applicationConfirmationEmail(base));
        break;
      case "approved":
        if (app.status !== "APPROVED" && app.status !== "COMPLETED") {
          return NextResponse.json({ error: "Application is not approved yet" }, { status: 400 });
        }
        await sendApplicationApprovedEmail(app, `${appUrl}/card/${app.id}`, `${appUrl}/booklet/${app.id}`);
        break;
      case "rejected":
        await sendEmail(app.email, "Update on your IDP application", applicationRejectedEmail(base));
        break;
      case "shipping":
        if (!app.shipment?.awbNumber) {
          return NextResponse.json({ error: "No shipment with an AWB number yet" }, { status: 400 });
        }
        await sendEmail(
          app.email,
          "Your IDP kit is on its way",
          shippingDispatchedEmail(base, {
            awbNumber: app.shipment.awbNumber,
            trackingUrl: app.shipment.trackingUrl,
            recipientName: app.shipment.recipientName,
          })
        );
        break;
      default:
        return NextResponse.json({ error: "Unknown email type" }, { status: 400 });
    }
    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error("Resend email failed:", err);
    return NextResponse.json({ error: err?.message || "Email sending failed" }, { status: 500 });
  }
}
