import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createOrder } from '@/lib/razorpay';
import { getDbPrices } from '@/lib/pricing-server';
import { fetchRates } from '@/lib/currency';

const schema = z.object({
  productType: z.enum(['DIGITAL', 'NFC_KIT']),
  validity: z.union([z.literal(1), z.literal(2), z.literal(3)]),
  currency: z.string().default('USD'),
  couponCode: z.string().optional(),
  discountAmount: z.number().min(0).default(0),
});

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const { productType, validity, currency, discountAmount } = parsed.data;
  const { usdPrices, inrPrices } = await getDbPrices();
  
  let baseAmount = usdPrices[productType][validity];
  if (currency === 'INR') {
    baseAmount = inrPrices[productType][validity];
  } else if (currency !== 'USD') {
    const rates = await fetchRates();
    if (rates && rates[currency]) {
      baseAmount = Math.ceil(baseAmount * rates[currency]);
    }
  }
  
  const finalAmount = Math.max(0, baseAmount - discountAmount);

  // Razorpay test accounts created in India cannot process USD payments.
  // In test mode: we convert USD → INR (approximate rate) so the modal shows
  // a realistic rupee figure. With LIVE keys this block is skipped entirely
  // and the customer is charged the exact USD amount they see on screen.
  const isTestKey = process.env.RAZORPAY_KEY_ID?.startsWith('rzp_test_');
  let gatewayCurrency = currency;
  let gatewayAmount = finalAmount;

  if (currency === 'USD' && isTestKey) {
    gatewayCurrency = 'INR';
    // Use a fixed approximate conversion rate for test only
    const USD_TO_INR = 84;
    gatewayAmount = Math.round(finalAmount * USD_TO_INR);
  }

  let order;
  try {
    order = await createOrder(gatewayAmount, gatewayCurrency, `IDP-${Date.now()}`);
  } catch (err: any) {
    console.error('[Razorpay] order creation failed:', err);
    const message =
      err?.error?.description ||
      err?.message ||
      'Razorpay order creation failed';
    return NextResponse.json({ error: message }, { status: 502 });
  }

  return NextResponse.json({
    orderId: order.id,
    amount: gatewayAmount,
    currency: gatewayCurrency,
    keyId: process.env.RAZORPAY_KEY_ID,
  });
}
