import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createOrder } from '@/lib/paypal';

const schema = z.object({
  amount: z.number().min(1, 'PayPal requires a minimum amount of $1.00 USD'),
  currency: z.string().default('USD'),
});

export async function POST(req: NextRequest) {

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const order = await createOrder(parsed.data.amount, parsed.data.currency);
  return NextResponse.json({ orderId: order.id });
}
