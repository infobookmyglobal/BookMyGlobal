import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { stripe } from '@/lib/stripe';

const ZERO_DECIMAL_CURRENCIES = new Set([
  'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA',
  'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF',
]);

const schema = z.object({
  amount: z.number().min(0.5, 'Minimum amount is $0.50'),
  currency: z.string().default('USD'),
  email: z.string().email().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const { amount, currency, email } = parsed.data;
    const currUpper = currency.toUpperCase();
    const currLower = currency.toLowerCase();

    const amountInUnits = ZERO_DECIMAL_CURRENCIES.has(currUpper)
      ? Math.round(amount)
      : Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInUnits,
      currency: currLower,
      receipt_email: email,
      automatic_payment_methods: {
        enabled: true,
      },
      metadata: {
        service: 'IDP Application',
      },
    });

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });
  } catch (error: any) {
    console.error('Stripe create-intent error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create payment intent' },
      { status: 500 }
    );
  }
}
