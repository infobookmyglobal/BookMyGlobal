import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { z } from 'zod';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/prisma';
import { sendEmail, applicationConfirmationEmail, sendAdminNewApplicationNotificationEmail } from '@/lib/ses';
import { getOrCreateGuestUser } from '@/lib/userCreation';

const schema = z.object({
  paymentIntentId: z.string(),
  applicationData: z.object({
    productType: z.enum(['DIGITAL', 'NFC_KIT']),
    validity: z.union([z.literal(1), z.literal(2), z.literal(3)]),
    fullName: z.string(),
    email: z.string().email(),
    phone: z.string(),
    dob: z.string().optional(),
    country: z.string(),
    address: z.string().optional(),
    destinationCountry: z.string().optional(),
    licenseNumber: z.string().optional(),
    licenseIssueDate: z.string().optional(),
    licenseExpiryDate: z.string().optional(),
    gender: z.string().optional(),
    countryOfBirth: z.string().optional(),
    countryOfResidence: z.string().optional(),
    licenseClass: z.string().optional(),
    parentName: z.string().optional(),
    currency: z.string().default('USD'),
    baseAmount: z.number(),
    finalAmount: z.number(),
    couponCode: z.string().optional(),
    discountAmount: z.number().default(0),
    adminNotes: z.string().optional(),
  }),
});

export async function POST(req: NextRequest) {
  try {
    const { userId } = await auth();

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const { paymentIntentId, applicationData } = parsed.data;

    // Verify PaymentIntent status with Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
    if (paymentIntent.status !== 'succeeded') {
      return NextResponse.json(
        { error: `Payment not completed. Status: ${paymentIntent.status}` },
        { status: 400 }
      );
    }

    // Idempotency check: prevent duplicate application creation for the same payment
    const existingPayment = await prisma.payment.findFirst({
      where: { providerPaymentId: paymentIntentId },
      select: { applicationId: true },
    });

    if (existingPayment) {
      console.log(`Stripe PaymentIntent ${paymentIntentId} already processed. Returning existing application: ${existingPayment.applicationId}`);
      return NextResponse.json({
        success: true,
        applicationId: existingPayment.applicationId,
        message: 'Payment already verified.',
      });
    }

    // Get or create user record
    let userIdToLink = '';
    let plainPassword: string | null = null;
    if (userId) {
      let user = await prisma.user.findUnique({ where: { clerkId: userId } });
      if (!user) {
        user = await prisma.user.create({
          data: {
            clerkId: userId,
            email: applicationData.email,
            name: applicationData.fullName,
            phone: applicationData.phone,
            country: applicationData.country,
          },
        });
      }
      userIdToLink = user.id;
      plainPassword = null;
    } else {
      const guestUser = await getOrCreateGuestUser({
        email: applicationData.email,
        fullName: applicationData.fullName,
        phone: applicationData.phone,
        country: applicationData.country,
      });
      userIdToLink = guestUser.userId;
      plainPassword = guestUser.generatedPassword || null;
    }

    // Create application and payment record
    const application = await prisma.application.create({
      data: {
        userId: userIdToLink,
        productType: applicationData.productType,
        validity: applicationData.validity,
        status: 'PENDING',
        fullName: applicationData.fullName,
        email: applicationData.email,
        phone: applicationData.phone,
        dob: applicationData.dob ? new Date(applicationData.dob) : null,
        country: applicationData.country,
        address: applicationData.address,
        destinationCountry: applicationData.destinationCountry,
        licenseNumber: applicationData.licenseNumber,
        licenseIssueDate: applicationData.licenseIssueDate ? new Date(applicationData.licenseIssueDate) : null,
        licenseExpiryDate: applicationData.licenseExpiryDate ? new Date(applicationData.licenseExpiryDate) : null,
        gender: applicationData.gender,
        countryOfBirth: applicationData.countryOfBirth,
        countryOfResidence: applicationData.countryOfResidence,
        licenseClass: applicationData.licenseClass,
        parentName: applicationData.parentName,
        currency: applicationData.currency,
        baseAmount: applicationData.baseAmount,
        finalAmount: applicationData.finalAmount,
        couponCode: applicationData.couponCode,
        discountAmount: applicationData.discountAmount,
        adminNotes: applicationData.adminNotes,
        payment: {
          create: {
            provider: 'STRIPE',
            amount: applicationData.finalAmount,
            currency: applicationData.currency,
            status: 'COMPLETED',
            providerPaymentId: paymentIntentId,
            providerOrderId: paymentIntentId,
          },
        },
      },
    });

    // Reset multipleIdpStatus to "NONE" if role is USER
    const userObj = await prisma.user.findUnique({ where: { id: userIdToLink } });
    if (userObj && userObj.role === 'USER') {
      await prisma.user.update({
        where: { id: userIdToLink },
        data: { multipleIdpStatus: 'NONE' },
      });
    }

    const payment = await prisma.payment.findUnique({
      where: { applicationId: application.id },
    });

    if (applicationData.couponCode && payment) {
      await prisma.coupon.update({
        where: { code: applicationData.couponCode },
        data: { usedCount: { increment: 1 } },
      });

      try {
        const { processReferralCommission } = await import('@/lib/referrals');
        await processReferralCommission(
          applicationData.couponCode,
          payment.id,
          applicationData.finalAmount
        );
      } catch (refErr) {
        console.error('Referral processing failed:', refErr);
      }
    }

    // Send customer confirmation email
    try {
      await sendEmail(
        applicationData.email,
        `Your IDP Application #${application.id.slice(-8).toUpperCase()} — Payment Confirmed ✅`,
        applicationConfirmationEmail({ ...applicationData, id: application.id, password: plainPassword })
      );
    } catch (err) {
      console.error('Email send failed:', err);
    }

    // Send admin notification email
    try {
      await sendAdminNewApplicationNotificationEmail(
        { ...applicationData, id: application.id },
        'STRIPE'
      );
    } catch (err) {
      console.error('Admin email send failed:', err);
    }

    return NextResponse.json({ applicationId: application.id, success: true });
  } catch (error: any) {
    console.error('Stripe confirm payment error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to confirm Stripe payment' },
      { status: 500 }
    );
  }
}
