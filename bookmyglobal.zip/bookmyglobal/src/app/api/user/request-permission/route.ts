import { NextRequest, NextResponse } from "next/server";
import { auth, currentUser } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { sendAdminPermissionRequestNotificationEmail, sendUserPermissionRequestedEmail } from "@/lib/ses";

export async function POST(req: NextRequest) {
  const { userId } = await auth();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    let user = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    let email = user?.email || "";
    let name = user?.name || "";

    // If user details are missing, fetch them from Clerk
    if (!user || !email || !name) {
      const clerkUser = await currentUser();
      if (clerkUser) {
        if (!email) {
          email = clerkUser.emailAddresses[0]?.emailAddress || "";
        }
        if (!name) {
          name = `${clerkUser.firstName || ""} ${clerkUser.lastName || ""}`.trim() || "User";
        }
      }
    }

    if (!user) {
      // Create user if not exists yet
      user = await prisma.user.create({
        data: {
          clerkId: userId,
          email,
          name,
          role: "USER",
        },
      });
    } else if (user.email !== email || user.name !== name) {
      // Keep local DB user record in sync with Clerk details if they changed or were populated
      user = await prisma.user.update({
        where: { id: user.id },
        data: {
          email,
          name,
        },
      });
    }

    const updatedUser = await prisma.user.update({
      where: { id: user.id },
      data: {
        multipleIdpStatus: "REQUESTED",
      },
    });

    // Notify admin via email
    try {
      await sendAdminPermissionRequestNotificationEmail({
        id: updatedUser.id,
        name: updatedUser.name || "User",
        email: updatedUser.email || "unknown@example.com",
      });
    } catch (emailError) {
      console.error("Failed to send permission request email to admin:", emailError);
    }

    // Notify user via email
    try {
      if (updatedUser.email) {
        await sendUserPermissionRequestedEmail({
          name: updatedUser.name || "User",
          email: updatedUser.email,
        });
      }
    } catch (emailError) {
      console.error("Failed to send permission request confirmation to user:", emailError);
    }

    return NextResponse.json({ success: true, status: updatedUser.multipleIdpStatus });
  } catch (error: any) {
    console.error("Failed to request permission:", error);
    return NextResponse.json(
      { error: error.message || "Failed to submit request" },
      { status: 500 }
    );
  }
}

