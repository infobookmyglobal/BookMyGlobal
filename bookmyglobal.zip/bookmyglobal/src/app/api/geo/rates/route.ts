import { NextResponse } from 'next/server';
import { fetchRates } from '@/lib/currency';

export const dynamic = 'force-dynamic';

export async function GET() {
  const rates = await fetchRates();
  return NextResponse.json({ rates }, {
    headers: { 'Cache-Control': 'public, max-age=3600, stale-while-revalidate=86400' },
  });
}
