import { NextRequest, NextResponse } from 'next/server';
import { detectGeo } from '@/lib/geo';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const cfConnectingIp = req.headers.get('cf-connecting-ip');
  const trueClientIp = req.headers.get('true-client-ip');
  const forwarded = req.headers.get('x-forwarded-for');
  const realIp = req.headers.get('x-real-ip');
  const ip = cfConnectingIp || trueClientIp || forwarded?.split(',')[0]?.trim() || realIp || undefined;

  const headerCountry = req.headers.get('x-vercel-ip-country') || req.headers.get('cf-ipcountry');

  const geo = await detectGeo(ip, headerCountry);

  return NextResponse.json(geo, {
    headers: { 'Cache-Control': 'no-store' },
  });
}
