import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, phone, address } = body;

    if (!name || !email || !phone || !address) {
      return NextResponse.json(
        { error: "All fields (name, email, phone, address) are required." },
        { status: 400 }
      );
    }

    const emailLower = email.toLowerCase().trim();

    // Check if the user already has a partner account
    const existingUser = await prisma.user.findUnique({
      where: { email: emailLower },
    });

    if (existingUser && existingUser.role === "PARTNER") {
      return NextResponse.json(
        { error: "This email is already registered as a partner." },
        { status: 400 }
      );
    }

    // Check if a pending partner request already exists
    const existingRequest = await prisma.partnerRequest.findFirst({
      where: {
        email: emailLower,
        status: "PENDING",
      },
    });

    if (existingRequest) {
      return NextResponse.json(
        { error: "You already have a pending partner request. Please wait for admin approval." },
        { status: 400 }
      );
    }

    // Create a new request (if one was rejected before, they can re-apply)
    await prisma.partnerRequest.upsert({
      where: { email: emailLower },
      update: {
        name,
        phone,
        address,
        status: "PENDING",
      },
      create: {
        name,
        email: emailLower,
        phone,
        address,
        status: "PENDING",
      },
    });

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (error: any) {
    console.error("Partner application error:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error." },
      { status: 500 }
    );
  }
}
