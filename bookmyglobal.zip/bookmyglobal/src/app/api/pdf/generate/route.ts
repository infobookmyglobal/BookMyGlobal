import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { generateQRCode } from '@/lib/qr';
import { generateIDPBooklet, generateIDPCard } from '@/lib/pdf';
import { uploadFile, getPresignedDownloadUrl } from '@/lib/s3';
import { sendApplicationApprovedEmail } from '@/lib/ses';
import { generateIDPNumber } from '@/lib/utils';
import { ApplicationForPDF } from '@/types';

const schema = z.object({
  applicationId: z.string(),
  customBookletKey: z.string().optional(),
  customIdCardKey: z.string().optional(),
});

function getS3KeyFromUrl(urlOrKey: string): string {
  if (urlOrKey.startsWith("http://") || urlOrKey.startsWith("https://")) {
    try {
      const url = new URL(urlOrKey);
      return decodeURIComponent(url.pathname.substring(1));
    } catch (e) {
      console.error("Failed to parse URL, using raw string", e);
    }
  }
  return urlOrKey;
}

export async function POST(req: NextRequest) {
  try {
    // 1. Verify admin session
    const { userId } = await auth();
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const adminUser = await prisma.user.findUnique({ where: { clerkId: userId } });
    if (!adminUser || adminUser.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    // 2. Validate request body
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const { applicationId, customBookletKey, customIdCardKey } = parsed.data;

    // 3. Retrieve application from DB
    const application = await prisma.application.findUnique({
      where: { id: applicationId },
      include: { user: true },
    });

    if (!application) {
      return NextResponse.json({ error: 'Application not found' }, { status: 404 });
    }

    // 4. Auto-generate IDP number or reuse existing
    const idpNumber = application.idpNumber || generateIDPNumber();

    // 5. Generate high-quality QR code returning Buffer
    const qrBytes = await generateQRCode(application.id, req.nextUrl.origin);

    // Convert QR bytes back to base64 data URL for database storage compatibility
    const qrCodeDataUrl = `data:image/png;base64,${qrBytes.toString('base64')}`;

    // 6. Fetch profile photo from S3
    let profilePhotoBytes: Buffer | null = null;
    if (application.profilePhotoUrl) {
      try {
        const photoDownloadUrl = await getPresignedDownloadUrl(application.profilePhotoUrl, 300);
        const res = await fetch(photoDownloadUrl);
        if (res.ok) {
          profilePhotoBytes = Buffer.from(await res.arrayBuffer());
        } else {
          console.warn(`Profile photo S3 fetch failed with status: ${res.status}`);
        }
      } catch (err) {
        console.error('Failed to fetch profile photo from S3:', err);
      }
    }

    // Map application properties to ApplicationForPDF type using stable dates
    const issueDate = application.createdAt;
    const expiryDate = new Date(application.createdAt);
    expiryDate.setFullYear(issueDate.getFullYear() + application.validity);

    const appForPDF: ApplicationForPDF = {
      id: application.id,
      idpNumber,
      fullName: application.fullName,
      address: application.address || '',
      country: application.country,
      countryOfBirth: application.countryOfBirth || application.country,
      countryOfResidence: application.countryOfResidence || application.country,
      dob: application.dob || new Date(),
      gender: application.gender || 'MALE',
      licenseNumber: application.licenseNumber || '',
      licenseClass: application.licenseClass || 'B',
      parentName: application.parentName || '',
      profilePhotoUrl: application.profilePhotoUrl || '',
      issueDate,
      expiryDate,
      validity: application.validity,
      destinationCountry: application.destinationCountry || '',
    };

    let bookletKey = "";
    let idCardKey = "";
    const timestamp = Date.now();

    // 7. Booklet PDF handling: custom key or generate template
    if (customBookletKey) {
      bookletKey = getS3KeyFromUrl(customBookletKey);
      // Delete old booklet S3 file if it exists and is different from the new one
      if (application.pdfBookletUrl && application.pdfBookletUrl !== bookletKey) {
        try {
          const { deleteObject } = await import('@/lib/s3');
          await deleteObject(application.pdfBookletUrl);
        } catch (err) {
          console.error('Failed to delete old booklet PDF:', err);
        }
      }
    } else {
      const bookletBuffer = await generateIDPBooklet(appForPDF, qrBytes, profilePhotoBytes);
      if (application.pdfBookletUrl) {
        try {
          const { deleteObject } = await import('@/lib/s3');
          await deleteObject(application.pdfBookletUrl);
        } catch (err) {
          console.error('Failed to delete old booklet PDF:', err);
        }
      }
      bookletKey = `idps/${application.id}/booklet_${timestamp}.pdf`;
      await uploadFile(bookletKey, Buffer.from(bookletBuffer), 'application/pdf');
    }

    // 8. ID Card PDF handling: custom key or generate template
    if (customIdCardKey) {
      idCardKey = getS3KeyFromUrl(customIdCardKey);
      // Delete old ID Card S3 file if it exists and is different from the new one
      if (application.pdfIdCardUrl && application.pdfIdCardUrl !== idCardKey) {
        try {
          const { deleteObject } = await import('@/lib/s3');
          await deleteObject(application.pdfIdCardUrl);
        } catch (err) {
          console.error('Failed to delete old idcard PDF:', err);
        }
      }
    } else {
      const idCardBuffer = await generateIDPCard(appForPDF, qrBytes, profilePhotoBytes);
      if (application.pdfIdCardUrl) {
        try {
          const { deleteObject } = await import('@/lib/s3');
          await deleteObject(application.pdfIdCardUrl);
        } catch (err) {
          console.error('Failed to delete old idcard PDF:', err);
        }
      }
      idCardKey = `idps/${application.id}/idcard_${timestamp}.pdf`;
      await uploadFile(idCardKey, Buffer.from(idCardBuffer), 'application/pdf');
    }

    // 9. Commit DB updates in a single atomic database operation
    const updatedApplication = await prisma.application.update({
      where: { id: application.id },
      data: {
        idpNumber,
        qrCode: qrCodeDataUrl,
        pdfBookletUrl: bookletKey,
        pdfIdCardUrl: idCardKey,
        status: 'APPROVED',
        pdfRegeneratedAt: new Date(),
      },
    });

    const bookletDownloadUrl = `${process.env.NEXT_PUBLIC_APP_URL}/booklet/${application.id}`;
    const idCardDownloadUrl = `${process.env.NEXT_PUBLIC_APP_URL}/card/${application.id}`;

    // 11. Dispatch notification email (errors here should not fail the API response)
    try {
      await sendApplicationApprovedEmail(
        updatedApplication,
        idCardDownloadUrl,
        bookletDownloadUrl
      );
    } catch (err) {
      console.error('Failed to send approval email:', err);
    }

    // 12. Return success response with download URLs
    return NextResponse.json({
      success: true,
      pdfBookletUrl: bookletDownloadUrl,
      pdfIdCardUrl: idCardDownloadUrl,
    });
  } catch (error: unknown) {
    console.error('Error during PDF generation workflow:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal Server Error' },
      { status: 500 }
    );
  }
}
