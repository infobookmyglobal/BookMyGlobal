import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

export async function GET(req: NextRequest) {
  const { userId } = await auth();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const user = await prisma.user.findUnique({ where: { clerkId: userId } });
  if (!user) return NextResponse.json({ applications: [] });

  const applications = await prisma.application.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: { payment: true, shipment: true },
  });

  return NextResponse.json({ applications });
}

const createSchema = z.object({
  productType: z.enum(['DIGITAL', 'NFC_KIT']),
  validity: z.union([z.literal(1), z.literal(2), z.literal(3)]),
  fullName: z.string().min(3),
  email: z.string().email(),
  phone: z.string().min(7),
  country: z.string(),
  baseAmount: z.number(),
  finalAmount: z.number(),
  currency: z.string(),
});

export async function POST(req: NextRequest) {
  const { userId } = await auth();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  let user = await prisma.user.findUnique({ where: { clerkId: userId } });
  if (!user) {
    user = await prisma.user.create({
      data: {
        clerkId: userId,
        email: parsed.data.email,
        name: parsed.data.fullName,
      },
    });
  }

  // Check if standard user can apply for a second IDP
  if (user.role === "USER") {
    const existingCount = await prisma.application.count({
      where: { userId: user.id },
    });
    if (existingCount >= 1 && user.multipleIdpStatus !== "APPROVED") {
      return NextResponse.json(
        { error: "Permission required to apply for a second IDP." },
        { status: 403 }
      );
    }
  }

  const application = await prisma.application.create({
    data: {
      userId: user.id,
      ...parsed.data,
      status: 'PENDING',
    },
  });

  if (user.role === "USER") {
    await prisma.user.update({
      where: { id: user.id },
      data: { multipleIdpStatus: "NONE" },
    });
  }

  return NextResponse.json({ application }, { status: 201 });
}
