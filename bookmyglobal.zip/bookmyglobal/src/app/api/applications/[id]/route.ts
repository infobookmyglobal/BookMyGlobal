import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { userId } = await auth();
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const user = await prisma.user.findUnique({ where: { clerkId: userId } });
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  const application = await prisma.application.findUnique({
    where: { id: id },
    include: { payment: true, shipment: true },
  });

  if (!application) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (application.userId !== user.id && user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  return NextResponse.json({ application });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { userId } = await auth();

  const application = await prisma.application.findUnique({
    where: { id: id },
  });

  if (!application) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  let authorized = false;
  let userRole = 'USER';

  if (userId) {
    const user = await prisma.user.findUnique({ where: { clerkId: userId } });
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    userRole = user.role;
    if (application.userId === user.id || user.role === 'ADMIN') {
      authorized = true;
    }
  } else {
    // Guest bypass: only allow updates if the application is PENDING
    if (application.status === 'PENDING') {
      authorized = true;
    }
  }

  if (!authorized) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const body = await req.json();

  // Only admins can change status (except allowing users/guests to submit their documents by setting it to 'UNDER_REVIEW')
  if (body.status && body.status !== 'UNDER_REVIEW' && (!userId || userRole !== 'ADMIN')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  // Validate destinationCountry for Digital applications
  if (body.destinationCountry) {
    const dbCountry = await prisma.country.findFirst({
      where: {
        name: {
          equals: body.destinationCountry.trim(),
          mode: 'insensitive',
        },
        isActive: true,
      },
    });

    const isDigital = (body.productType || application.productType) === 'DIGITAL';
    if (dbCountry?.requiresPhysical && isDigital) {
      return NextResponse.json(
        { error: `${dbCountry.name} requires a Physical IDP. You cannot choose it with a Digital-only plan.` },
        { status: 400 }
      );
    }
  }

  const { getS3KeyFromUrl } = await import('@/lib/s3');
  if (body.profilePhotoUrl) body.profilePhotoUrl = getS3KeyFromUrl(body.profilePhotoUrl);
  if (body.licenseUrl) body.licenseUrl = getS3KeyFromUrl(body.licenseUrl);
  if (body.passportUrl) body.passportUrl = getS3KeyFromUrl(body.passportUrl);

  const updatedApplication = await prisma.application.update({
    where: { id: id },
    data: body,
  });

  return NextResponse.json({ application: updatedApplication });
}

