import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get("query")?.trim();

    if (!query) {
      return NextResponse.json({ success: false, error: "Missing query parameter" }, { status: 400 });
    }

    // If query is a URL, parse it to extract the ID
    let parsedQuery = query;
    if (query.startsWith("http://") || query.startsWith("https://")) {
      try {
        const url = new URL(query);
        const pathSegments = url.pathname.split("/").filter(Boolean);
        // Assuming path format /verify/[id]
        if (pathSegments.includes("verify")) {
          const verifyIndex = pathSegments.indexOf("verify");
          if (verifyIndex < pathSegments.length - 1) {
            parsedQuery = pathSegments[verifyIndex + 1];
          }
        } else {
          // Fallback: take the last segment of the path
          parsedQuery = pathSegments[pathSegments.length - 1] || query;
        }
      } catch (e) {
        console.error("Failed to parse query as URL, using raw query", e);
      }
    }

    // Try finding by ID first, then by exact idpNumber, and then case-insensitively
    const application = await prisma.application.findFirst({
      where: {
        OR: [
          { id: parsedQuery },
          { idpNumber: parsedQuery },
          {
            idpNumber: {
              equals: parsedQuery,
              mode: "insensitive",
            },
          },
        ],
      },
      select: {
        id: true,
        fullName: true,
        idpNumber: true,
        status: true,
      },
    });

    if (!application) {
      return NextResponse.json({ success: false, error: "No matching IDP found" });
    }

    return NextResponse.json({
      success: true,
      id: application.id,
      fullName: application.fullName,
      idpNumber: application.idpNumber,
      status: application.status,
    });
  } catch (error) {
    console.error("Verify API error:", error);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}
