import { NextResponse } from "next/server";
import { getDbPrices } from "@/lib/pricing-server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const { usdPrices, inrPrices } = await getDbPrices();
    return NextResponse.json({
      success: true,
      prices: usdPrices,
      inrPrices
    });
  } catch (error) {
    console.error("Failed to generate dynamic pricing response:", error);
    return NextResponse.json({
      success: false,
      prices: {
        DIGITAL: { 1: 21, 2: 26, 3: 32 },
        NFC_KIT: { 1: 32, 2: 37, 3: 42 }
      },
      inrPrices: {
        DIGITAL: { 1: 1999, 2: 2499, 3: 2999 },
        NFC_KIT: { 1: 2999, 2: 3499, 3: 3999 }
      }
    });
  }
}
