import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const countries = await prisma.country.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        slug: true,
        flag: true,
        requiresPhysical: true,
        status: true,
        idpValid: true,
        category: true,
        validityYears: true,
        format: true,
        physicalAccepted: true,
        digitalAccepted: true,
        alertColor: true,
        websiteTitle: true,
        websiteMessage: true,
        dualConventionLine: true,
        showChat: true,
      },
      orderBy: { name: 'asc' },
    });
    return NextResponse.json(countries);
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Failed to fetch countries' }, { status: 500 });
  }
}
