import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import Script from "next/script";
import Image from "next/image";
import { CustomStructuredData } from "@/components/JsonLd";
import { auth } from "@clerk/nextjs/server";
import { AlertTriangle } from "lucide-react";
import { ApplyCTACard } from "@/components/destination/ApplyCTACard";

const APP_URL =
  process.env.NEXT_PUBLIC_APP_URL || "https://bookmyglobal.com";

interface Props {
  params: Promise<{ slug: string }>;
}

function getDestinationName(title: string): string {
  const match = title.match(/^([A-Za-z\s]+?)\s+(?:Complete|International|Driving|IDP|Guide|202\d|:|-|—)/i);
  if (match && match[1] && match[1].trim().length > 2) {
    return match[1].trim();
  }
  return (
    title
      .replace(/&amp;/g, "&")
      .replace(/Complete Driving & IDP Guide: Everything You Need Before You Get Behind the Wheel/gi, "")
      .replace(/International Driving Permit & Complete Driving Guide 202\d/gi, "")
      .replace(/Driving & IDP Guide 202\d: Essential Information for Necessary Travel/gi, "")
      .replace(/Guide: Everything You Need Before You Get Behind the Wheel/gi, "")
      .trim() || "Destination"
  );
}

// ─── Tiptap JSON → clean HTML ─────────────────────────────────────────────
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderNodes(nodes: any[]): string {
  if (!Array.isArray(nodes)) return "";
  return nodes.map(renderNode).join("");
}

function renderNode(node: any): string {
  if (!node) return "";
  if (node.type === "text") {
    let text = escapeHtml(node.text || "");
    if (Array.isArray(node.marks)) {
      for (const mark of node.marks) {
        if (mark.type === "bold") text = `<strong>${text}</strong>`;
        else if (mark.type === "italic") text = `<em>${text}</em>`;
        else if (mark.type === "underline") text = `<u>${text}</u>`;
        else if (mark.type === "strike") text = `<s>${text}</s>`;
        else if (mark.type === "code") text = `<code>${text}</code>`;
        else if (mark.type === "link") {
          const href = mark.attrs?.href || "#";
          const target = mark.attrs?.target || "_blank";
          text = `<a href="${escapeHtml(href)}" target="${escapeHtml(target)}" rel="noopener noreferrer">${text}</a>`;
        }
      }
    }
    return text;
  }

  const childHtml = renderNodes(node.content);
  switch (node.type) {
    case "paragraph": return `<p>${childHtml || "&nbsp;"}</p>`;
    case "heading": {
      const level = node.attrs?.level || 2;
      return `<h${level}>${childHtml}</h${level}>`;
    }
    case "bulletList": return `<ul>${childHtml}</ul>`;
    case "orderedList": return `<ol>${childHtml}</ol>`;
    case "listItem": return `<li>${childHtml}</li>`;
    case "blockquote": return `<blockquote>${childHtml}</blockquote>`;
    case "horizontalRule": return "<hr />";
    case "hardBreak": return "<br />";
    case "image": {
      const src = node.attrs?.src || "";
      const alt = node.attrs?.alt || "";
      return `<img src="${escapeHtml(src)}" alt="${escapeHtml(alt)}" loading="lazy" class="my-6 max-w-full rounded-xl border border-border-custom shadow-md" />`;
    }
    default: return childHtml;
  }
}

function renderTiptapJsonToHtml(jsonString: string): string {
  if (!jsonString) return "";
  if (!jsonString.trim().startsWith("{")) return jsonString;
  try {
    const doc = JSON.parse(jsonString);
    if (!doc || doc.type !== "doc" || !Array.isArray(doc.content)) return jsonString;
    return renderNodes(doc.content);
  } catch {
    return jsonString;
  }
}

// ─── SEO Metadata ─────────────────────────────────────────────────────────
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;

  let isAdmin = false;
  if (process.env.NODE_ENV === "development") {
    isAdmin = true;
  } else {
    const { userId } = await auth();
    if (userId) {
      const dbUser = await prisma.user.findUnique({
        where: { clerkId: userId },
        select: { role: true },
      });
      isAdmin = dbUser?.role === "ADMIN";
    }
  }

  const page = await prisma.page.findUnique({ where: { slug } });

  if (!page || (!page.isActive && !isAdmin)) return { title: "Page Not Found" };

  const seoTitle = page.seoTitle || page.title;
  const seoDesc = page.seoDescription || `${page.title} — BookMyGlobal`;
  const canonical = page.canonicalUrl || `${APP_URL}/${page.slug}`;
  const ogImg = page.ogImage || `${APP_URL}/og-home.jpg`;
  const robotsDirective = page.robots || "index, follow";
  const isNoIndex = robotsDirective.includes("noindex");

  return {
    title: seoTitle,
    description: seoDesc,
    alternates: { canonical },
    robots: {
      index: !isNoIndex,
      follow: !robotsDirective.includes("nofollow"),
      googleBot: { index: !isNoIndex, follow: !robotsDirective.includes("nofollow") },
    },
    openGraph: {
      type: "website",
      title: seoTitle,
      description: seoDesc,
      url: canonical,
      siteName: "BookMyGlobal",
      images: [{ url: ogImg, width: 1200, height: 630, alt: page.title }],
    },
    twitter: {
      card: "summary_large_image",
      title: seoTitle,
      description: seoDesc,
      images: [ogImg],
    },
  };
}

// Static params for known published pages
export async function generateStaticParams() {
  try {
    const pages = await prisma.page.findMany({
      where: { isActive: true },
      select: { slug: true },
    });
    const isCloudBuild = process.env.NETLIFY === 'true' || process.env.VERCEL === 'true';
    if (!isCloudBuild) {
      return pages.slice(0, 5).map((p) => ({ slug: p.slug }));
    }
    return pages.map((p) => ({ slug: p.slug }));
  } catch {
    return [];
  }
}

export const revalidate = 60;
export const dynamic = "force-dynamic";

// ─── Page Renderer ─────────────────────────────────────────────────────────
export default async function CmsPage({ params }: Props) {
  const { slug } = await params;

  let isAdmin = false;
  if (process.env.NODE_ENV === "development") {
    isAdmin = true;
  } else {
    const { userId } = await auth();
    if (userId) {
      const dbUser = await prisma.user.findUnique({
        where: { clerkId: userId },
        select: { role: true },
      });
      isAdmin = dbUser?.role === "ADMIN";
    }
  }

  const page = await prisma.page.findUnique({ where: { slug } });

  // 404 for missing or unpublished pages
  if (!page || (!page.isActive && !isAdmin)) notFound();

  const parsedHtml = renderTiptapJsonToHtml(page.content);
  const destinationName = getDestinationName(page.title);

  let requiresPhysical = false;
  try {
    const countryRecord = await prisma.country.findFirst({
      where: { name: { equals: destinationName, mode: "insensitive" } },
      select: { requiresPhysical: true },
    });
    if (countryRecord) {
      requiresPhysical = countryRecord.requiresPhysical;
    }
  } catch { /* empty */ }

  const webPageJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: page.title,
    description: page.seoDescription || page.title,
    url: page.canonicalUrl || `${APP_URL}/${page.slug}`,
    publisher: {
      "@type": "Organization",
      name: "BookMyGlobal",
      url: APP_URL,
    },
    dateModified: page.updatedAt.toISOString(),
    inLanguage: "en-US",
  };

  return (
    <main className="flex-1 flex flex-col bg-white">
      {page.structuredData ? (
        <CustomStructuredData data={page.structuredData} />
      ) : (
        <Script
          id={`cms-page-jsonld-${page.id}`}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageJsonLd) }}
          strategy="beforeInteractive"
        />
      )}
      <Header />

      {/* Admin Preview Mode Warning Bar */}
      {!page.isActive && (
        <div className="bg-amber-50 border-b border-amber-200 py-3 px-4 flex items-center justify-center gap-2 text-xs font-bold text-amber-800">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>PREVIEW MODE: This is a Draft page. Public visitors will see a 404 page, but you are authorized to view it.</span>
        </div>
      )}

      {/* Hero Bar */}
      <div className="bg-gradient-to-r from-navy to-blue py-10 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="font-sora text-2xl md:text-4xl font-black text-white leading-tight">
            {page.title}
          </h1>
          <p className="text-white/60 text-xs mt-2 font-bold uppercase tracking-wider">
            Last updated: {new Date(page.updatedAt).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
      </div>

      {/* Cover Image */}
      {page.featuredImageUrl && (
        <div className="max-w-6xl mx-auto px-4 mt-10">
          <div className="relative aspect-[21/9] w-full rounded-2xl overflow-hidden shadow-md border border-border-custom bg-bg-custom">
            <Image
              src={page.featuredImageUrl}
              alt={page.title}
              fill
              priority
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 1200px"
              className="object-cover"
            />
          </div>
        </div>
      )}

      {/* Content Layout with Main Article & Sticky Sidebar CTA */}
      <section className="py-12 md:py-16 px-4 max-w-6xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* LEFT: Article Content + End of Travel Guide CTA */}
          <article className="lg:col-span-7 xl:col-span-8 min-w-0">
            <div
              className="rich-text-content leading-relaxed text-text-custom"
              dangerouslySetInnerHTML={{ __html: parsedHtml }}
            />

            {/* CTA at the End of Each Travel Guide */}
            <div className="mt-12 pt-10 border-t border-slate-200">
              <ApplyCTACard
                cityName={destinationName}
                country={destinationName}
                requiresPhysical={requiresPhysical}
              />
            </div>
          </article>

          {/* RIGHT: Sticky Sidebar CTA */}
          <aside className="lg:col-span-5 xl:col-span-4 lg:sticky lg:top-24 w-full">
            <ApplyCTACard
              cityName={destinationName}
              country={destinationName}
              requiresPhysical={requiresPhysical}
            />
          </aside>
        </div>
      </section>

      <Footer />
    </main>
  );
}
