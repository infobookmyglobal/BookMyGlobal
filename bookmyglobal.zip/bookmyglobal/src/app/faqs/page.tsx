import type { Metadata } from "next";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HomeFaq } from "@/components/home/HomeFaq";
import { FaqJsonLd } from "@/components/JsonLd";
import { prisma } from "@/lib/prisma";
import { getSeoMetadata } from "@/lib/seo";

export const revalidate = 300;

export async function generateMetadata(): Promise<Metadata> {
  return getSeoMetadata("faqs");
}

export default async function FaqsPage() {
  const rows = await prisma.fAQ.findMany({ where: { isActive: true }, orderBy: { order: "asc" } }).catch(() => []);
  const items = rows.map((f) => ({ q: f.question, a: f.answer }));
  return (
    <>
      <Header />
      <main className="mx-auto max-w-3xl px-4 sm:px-6 py-16 lg:py-20">
        <h1 className="font-sora font-extrabold text-4xl text-navy text-center">Frequently asked questions</h1>
        <div className="mt-10">
          {items.length ? (
            <>
              <FaqJsonLd faqs={items.map((f) => ({ question: f.q, answer: f.a }))} />
              <HomeFaq items={items} />
            </>
          ) : (
            <p className="text-center text-muted-custom">No FAQs published yet.</p>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
