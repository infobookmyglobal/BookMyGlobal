import type { Metadata } from "next";
import { Mail, MessageCircle } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { EnquiryForm, ENQUIRY_TYPES } from "@/components/home/EnquiryForm";
import { getSeoMetadata } from "@/lib/seo";
import { SUPPORT_EMAIL, WHATSAPP_NUMBER, WHATSAPP_URL } from "@/lib/contact";

export async function generateMetadata(): Promise<Metadata> {
  return getSeoMetadata("contact");
}

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ type?: string }> }) {
  const { type } = await searchParams;
  const defaultType = ENQUIRY_TYPES.some((t) => t.value === type) ? (type as string) : "GENERAL";

  return (
    <>
      <Header />
      <main className="mx-auto max-w-6xl px-4 sm:px-6 py-16 lg:py-20 grid lg:grid-cols-[1fr_1.3fr] gap-12">
        <div>
          <p className="text-[11px] font-black tracking-widest text-blue">GET IN TOUCH</p>
          <h1 className="mt-3 font-sora font-extrabold text-4xl text-navy">Tell us about your trip</h1>
          <p className="mt-4 text-muted-custom leading-relaxed">
            Flights, hotels, visas, attestation, retreats — or just a question. Send us a message and we&apos;ll come back to you.
          </p>
          <div className="mt-8 space-y-4">
            <a href={`mailto:${SUPPORT_EMAIL}`} className="flex items-center gap-3 text-navy font-bold text-sm">
              <span className="w-10 h-10 rounded-xl bg-blue/10 text-blue flex items-center justify-center"><Mail className="w-5 h-5" /></span>
              {SUPPORT_EMAIL}
            </a>
            {WHATSAPP_NUMBER && (
              <a href={WHATSAPP_URL} className="flex items-center gap-3 text-navy font-bold text-sm">
                <span className="w-10 h-10 rounded-xl bg-green/15 text-green flex items-center justify-center"><MessageCircle className="w-5 h-5" /></span>
                Chat on WhatsApp
              </a>
            )}
          </div>
        </div>
        <div className="bg-white border border-border-custom rounded-3xl p-6 sm:p-8 shadow-sm">
          <EnquiryForm defaultType={defaultType} />
        </div>
      </main>
      <Footer />
    </>
  );
}
