export default function CountriesLoading() {
  return (
    <div className="min-h-screen bg-bg-custom animate-pulse">
      <div className="bg-navy py-16 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <div className="h-10 w-80 bg-white/20 rounded-xl mx-auto" />
          <div className="h-5 w-64 bg-white/10 rounded-lg mx-auto" />
        </div>
      </div>
      {/* Search bar skeleton */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="h-12 w-full max-w-md bg-white rounded-xl border border-border-custom mx-auto" />
      </div>
      {/* Country grid skeleton */}
      <div className="max-w-6xl mx-auto px-4 pb-16 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {[...Array(16)].map((_, i) => (
          <div key={i} className="h-48 bg-white rounded-2xl border border-border-custom" />
        ))}
      </div>
    </div>
  );
}
