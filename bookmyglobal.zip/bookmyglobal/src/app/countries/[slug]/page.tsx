import { notFound, redirect } from "next/navigation";
import { SafeImage } from "@/components/SafeImage";
import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { prisma } from "@/lib/prisma";
import { getTravelGuideRedirectUrlForCountry } from "@/lib/countryGuideRedirect";
import { ChevronRight, ShieldAlert, FileWarning, AlertTriangle, ArrowLeft } from "lucide-react";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const country = await prisma.country.findUnique({ where: { slug } });
  if (!country) return { title: 'Not Found' };
  return {
    title: country.seoTitle || `International Driving Permit for ${country.name}`,
    description: country.seoDescription || `Apply for an International Driving Permit in ${country.name}.`,
  };
}

export default async function CountryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const country = await prisma.country.findUnique({ where: { slug } });
  
  if (!country) {
    notFound();
  }

  // Redirect to manual redirect target or matching Know More Travel Guide if it exists
  const redirectUrl = await getTravelGuideRedirectUrlForCountry(slug, country.name);
  if (redirectUrl) {
    redirect(redirectUrl);
  }

  const isNotAccepted = country.status === "NOT_ACCEPTED";
  const isLimited = country.status === "LIMITED";
  const isPhysicalOnly = country.requiresPhysical;

  return (
    <main className="flex-1 flex flex-col bg-white">
      <Header />
      
      {/* Back Bar */}
      <div className="bg-bg-custom border-b border-border-custom py-3 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/" className="inline-flex items-center gap-2 text-blue font-bold text-sm hover:text-navy transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to All Countries
          </Link>
        </div>
      </div>

      {/* Banner if not accepted */}
      {isNotAccepted && (
        <div className="bg-red-600 text-white p-4 text-center">
          <h3 className="font-sora font-black text-lg mb-1">⛔ Standard IDP Not Valid in {country.name}</h3>
          <p className="text-sm opacity-90">{country.notes}</p>
        </div>
      )}

      {/* Hero */}
      <section className="relative min-h-[400px] flex flex-col items-center justify-center text-center py-16 px-4 overflow-hidden">
        {country.heroImageUrl && (
          <SafeImage src={country.heroImageUrl} alt={country.name} fill className="object-cover absolute inset-0 z-0" priority sizes="(max-width: 768px) 100vw, 100vw" />
        )}
        <div className="absolute inset-0 bg-gradient-to-br from-navy/95 to-blue/85 z-10" />
        
        <div className="relative z-20 max-w-3xl mx-auto w-full">
          <div className="text-6xl mb-4">{country.flag}</div>
          <h1 className="font-sora text-3xl md:text-5xl font-black text-white mb-4 leading-tight">
            International Driving Permit for <em className="text-gold not-italic">{country.name}</em>
          </h1>
          <p className="text-white/80 text-lg mb-8 max-w-xl mx-auto">
            {country.notes || `Everything you need to know about driving in ${country.name} as a foreign visitor.`}
          </p>
          
          {!isNotAccepted && (
            <div className="flex flex-col items-center">
              <Link href="/apply" className="btn-primary px-8 py-4 text-lg w-full max-w-sm mb-2 shadow-xl shadow-green-500/20">
                Apply for IDP — Takes 5 Minutes
              </Link>
              <p className="text-white/50 text-xs font-bold uppercase tracking-wider">100% Money-Back Guarantee · Valid Worldwide</p>
            </div>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 mt-12 pt-8 border-t border-white/15">
            <div className="text-center px-4 md:border-r border-white/15 mb-6 md:mb-0">
              <div className="text-gold font-black text-2xl mb-1">{country.drivingSide === "LEFT" ? "Left ←" : "Right →"}</div>
              <div className="text-white/60 text-[10px] font-bold uppercase tracking-wider">Drive Side</div>
            </div>
            <div className="text-center px-4 md:border-r border-white/15 mb-6 md:mb-0">
              <div className="text-gold font-black text-2xl mb-1">{isPhysicalOnly ? "❌ No" : "✅ Yes"}</div>
              <div className="text-white/60 text-[10px] font-bold uppercase tracking-wider">Digital IDP</div>
            </div>
            <div className="text-center px-4 md:border-r border-white/15">
              <div className="text-gold font-black text-2xl mb-1">{country.maxValidity} Years</div>
              <div className="text-white/60 text-[10px] font-bold uppercase tracking-wider">Max Validity</div>
            </div>
            <div className="text-center px-4">
              <div className="text-gold font-black text-xl mb-1 mt-1 leading-tight">{country.convention === "BOTH" ? "Geneva + Vienna" : country.convention === "GENEVA" ? "Geneva 1949" : "Vienna 1968"}</div>
              <div className="text-white/60 text-[10px] font-bold uppercase tracking-wider mt-1.5">Convention</div>
            </div>
          </div>
        </div>
      </section>

      {/* Content Sections */}
      <div className="py-16 px-4">
        <div className="max-w-3xl mx-auto space-y-16">
          
          {/* Quick Answer */}
          <section className="text-center">
            <span className="eyebrow-pill mb-4">Quick Answer</span>
            <h2 className="section-heading mb-8">Do you need an IDP in {country.name}?</h2>
            
            <div className="bg-white border border-border-custom rounded-2xl shadow-sm overflow-hidden text-left mb-6">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-navy text-white">
                    <th className="p-4 font-bold text-left">Requirement</th>
                    <th className="p-4 font-bold text-left">Answer</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-custom">
                  <tr>
                    <td className="p-4 font-medium text-muted">IDP Required</td>
                    <td className={`p-4 font-bold ${isNotAccepted ? "text-red-600" : isLimited ? "text-yellow-600" : "text-green-600"}`}>
                      {isNotAccepted ? "❌ Not accepted" : isLimited ? "⚠️ Limited / Check advisories" : "✅ Yes"}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-muted">Traffic drives on the</td>
                    <td className="p-4 font-bold text-text-custom">{country.drivingSide === "LEFT" ? "Left side" : "Right side"}</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-muted">Speed limit (urban)</td>
                    <td className="p-4 font-bold text-text-custom">{country.citySpeedLimit} km/h</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-muted">Speed limit (highway)</td>
                    <td className="p-4 font-bold text-text-custom">{country.highwaySpeedLimit === 999 ? "No limit (some sections)" : `${country.highwaySpeedLimit} km/h`}</td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-muted">Digital IDP accepted</td>
                    <td className={`p-4 font-bold ${isPhysicalOnly ? "text-red-600" : "text-green-600"}`}>
                      {isPhysicalOnly ? "❌ Physical booklet only" : "✅ Yes"}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-muted">Max validity accepted</td>
                    <td className="p-4 font-bold text-text-custom">Up to {country.maxValidity} years</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {isPhysicalOnly && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex gap-3 text-left items-start">
                <AlertTriangle className="w-5 h-5 text-yellow-700 shrink-0 mt-0.5" />
                <p className="text-sm text-yellow-800 leading-relaxed font-medium">
                  <strong>IMPORTANT:</strong> {country.name} only accepts the PHYSICAL printed IDP booklet. A digital-only IDP will NOT be accepted by car rental companies or law enforcement.
                </p>
              </div>
            )}
          </section>

          {/* Pricing Section inline if accepted */}
          {!isNotAccepted && (
            <section className="bg-bg-custom rounded-3xl p-8 border border-border-custom text-center">
              <span className="eyebrow-pill mb-4">Get Your IDP</span>
              <h2 className="section-heading mb-3">Risk-Free Pricing</h2>
              <p className="text-muted mb-8 max-w-md mx-auto">100% money-back guarantee if not accepted anywhere. No questions asked.</p>
              
              <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto mb-6 text-left">
                <div className="bg-white border border-border-custom rounded-2xl p-6 relative hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-2">📱</div>
                  <h3 className="font-sora font-black text-navy text-lg mb-1">Digital IDP</h3>
                  <div className="font-sora font-black text-blue text-3xl mb-1">$21 <span className="text-sm font-normal text-muted">/ year</span></div>
                  <div className="text-xs text-muted font-bold mb-4">2yr $26 | 3yr $32</div>
                  <Link href="/apply" className="btn-secondary block w-full py-3 text-center">Apply Now →</Link>
                  {isPhysicalOnly && <p className="text-xs text-red-600 font-bold text-center mt-3">⚠️ Not valid in {country.name}</p>}
                </div>

                <div className="bg-[#f0f4ff] border-2 border-blue rounded-2xl p-6 relative hover:shadow-lg transition-shadow">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue text-white text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full whitespace-nowrap">
                    ⭐ Recommended
                  </div>
                  <div className="text-3xl mb-2">📦</div>
                  <h3 className="font-sora font-black text-navy text-lg mb-1">NFC Smart Kit</h3>
                  <div className="font-sora font-black text-blue text-3xl mb-1">$32 <span className="text-sm font-normal text-muted">/ year</span></div>
                  <div className="text-xs text-muted font-bold mb-4">2yr $37 | 3yr $42</div>
                  <Link href="/apply" className="btn-primary block w-full py-3 text-center">Get Smart Kit →</Link>
                </div>
              </div>
              
              <div className="flex items-center justify-center gap-2 text-sm font-bold text-green-700 bg-green-50 border border-green-200 rounded-xl p-3 max-w-md mx-auto">
                <span>🛡️</span> 100% Money-Back Guarantee
              </div>
            </section>
          )}

        </div>
      </div>
      <Footer />
    </main>
  );
}
