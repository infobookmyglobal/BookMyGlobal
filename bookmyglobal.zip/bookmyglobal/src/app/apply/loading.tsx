export default function ApplyLoading() {
  return (
    <div className="min-h-screen bg-bg-custom animate-pulse flex items-center justify-center px-4">
      <div className="w-full max-w-2xl space-y-6">
        {/* Step indicators */}
        <div className="flex justify-center gap-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-8 w-8 rounded-full bg-gray-200" />
          ))}
        </div>
        {/* Card */}
        <div className="bg-white rounded-2xl border border-border-custom p-8 space-y-5">
          <div className="h-8 w-48 bg-gray-200 rounded-lg" />
          <div className="grid grid-cols-2 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-100 rounded-xl" />
            ))}
          </div>
          <div className="h-12 bg-blue/20 rounded-xl mt-4" />
        </div>
      </div>
    </div>
  );
}
