"use client";

import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CheckCircle, Mail, Key, ShieldCheck, ArrowRight, Check } from "lucide-react";
import { Suspense, useState } from "react";
import { DocumentUploader } from "@/components/application/DocumentUploader";

function SuccessContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get("email") || "your email address";
  const applicationId = searchParams.get("applicationId") || "";

  // Track upload states
  const [passportKey, setPassportKey] = useState<string | null>(null);
  const [licenseKey, setLicenseKey] = useState<string | null>(null);
  const [profileKey, setProfileKey] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const allUploaded = !!(passportKey && licenseKey && profileKey);

  const handleSubmitDocuments = async () => {
    if (!applicationId || !allUploaded) return;

    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch(`/api/applications/${applicationId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          passportUrl: passportKey,
          licenseUrl: licenseKey,
          profilePhotoUrl: profileKey,
          status: "UNDER_REVIEW",
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Failed to submit documents");
      }

      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || "An error occurred while submitting your documents.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <div className="bg-white border border-border-custom rounded-3xl shadow-xl p-8 md:p-12 space-y-8">
        
        {/* Success Icon & Header */}
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="w-20 h-20 bg-green-50 text-green rounded-full flex items-center justify-center animate-bounce">
            <CheckCircle className="w-10 h-10 text-[#22c55e]" />
          </div>
          <div className="space-y-2">
            <h1 className="font-sora text-3xl font-black text-navy">
              Payment Successful! 🎉
            </h1>
            <p className="text-slate-500 text-sm max-w-md mx-auto">
              Your application has been initiated. We have generated login details for you so you can track progress.
            </p>
          </div>
        </div>

        {/* Credentials Email Block */}
        <div className="bg-[#f0f4ff] border border-blue/10 rounded-2xl p-6 space-y-4">
          <h3 className="font-sora font-black text-navy text-sm flex items-center gap-2">
            <Key className="w-4 h-4 text-blue" />
            Temporary Password Emailed
          </h3>
          <p className="text-slate-600 text-xs leading-relaxed">
            Your login email is your registered email, and a strong auto-generated password of 8 characters has been sent to:
          </p>
          <div className="bg-white border border-border-custom rounded-xl px-4 py-3 font-bold text-navy text-sm flex items-center gap-2">
            <Mail className="w-4 h-4 text-slate-400" />
            <span>{email}</span>
          </div>
          <p className="text-slate-500 text-[10px] leading-relaxed italic">
            *Please check your spam or promotions folder if you don&apos;t see the email within 2 minutes.
          </p>
        </div>

        {/* Document Upload block */}
        {applicationId && (
          <div className="border-t border-slate-100 pt-8 space-y-6">
            <div className="space-y-1.5 text-center">
              <h2 className="font-sora font-black text-navy text-lg">📷 Upload Your Documents Now</h2>
              <p className="text-muted text-xs max-w-lg mx-auto">
                Upload your files below to complete verification. If you don&apos;t have them right now, you can skip this step and log in later.
              </p>
            </div>

            {submitted ? (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-6 flex items-center gap-4 text-left">
                <Check className="w-8 h-8 text-[#22c55e] shrink-0 bg-white rounded-full p-1 border border-green-200" />
                <div>
                  <p className="font-bold text-green-800">All documents uploaded!</p>
                  <p className="text-xs text-green-600">Your profile is now under review. We will verify everything within 24 hours.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid md:grid-cols-3 gap-4 text-left">
                  <DocumentUploader
                    label="Profile Photo *"
                    fieldName="profile"
                    applicationId={applicationId}
                    folder="profiles"
                    onUploadComplete={(_, key) => setProfileKey(key)}
                  />
                  <DocumentUploader
                    label="Driving License (Front) *"
                    fieldName="license"
                    applicationId={applicationId}
                    folder="licenses"
                    onUploadComplete={(_, key) => setLicenseKey(key)}
                  />
                  <DocumentUploader
                    label="Driving License (Back) *"
                    fieldName="passport"
                    applicationId={applicationId}
                    folder="passports"
                    onUploadComplete={(_, key) => setPassportKey(key)}
                  />
                </div>

                {error && (
                  <p className="text-red-500 text-xs font-bold text-center bg-red-50 border border-red-200 rounded-xl p-3">
                    {error}
                  </p>
                )}

                <button
                  onClick={handleSubmitDocuments}
                  disabled={!allUploaded || submitting}
                  className="btn-primary w-full py-4 text-sm font-black flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {submitting ? "Submitting..." : "Submit Documents for Review →"}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Navigation Action */}
        <div className="space-y-4 pt-4 border-t border-slate-100 text-center">
          <Link
            href="/sign-in"
            className="btn-secondary w-full py-3 text-xs flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform"
          >
            {submitted ? "Go to Dashboard" : "Skip & Sign In to Dashboard"} <ArrowRight className="w-4 h-4" />
          </Link>
          <p className="text-[10px] text-muted font-bold flex items-center justify-center gap-1.5 uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-green-600" />
            Secure verification portal powered by Clerk Identity
          </p>
        </div>

      </div>
    </div>
  );
}

export default function ApplySuccessPage() {
  return (
    <main className="flex-1 flex flex-col bg-bg-custom">
      <Header />
      <div className="flex-1 flex items-center justify-center">
        <Suspense fallback={
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-blue border-t-transparent rounded-full animate-spin" />
            <p className="text-sm font-bold text-muted mt-4">Loading success page...</p>
          </div>
        }>
          <SuccessContent />
        </Suspense>
      </div>
      <Footer />
    </main>
  );
}
