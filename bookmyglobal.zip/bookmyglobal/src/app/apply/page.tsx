import { WHATSAPP_URL } from "@/lib/contact";
import { auth } from "@clerk/nextjs/server";
import { Header } from "@/components/Header";
import { ApplicationForm } from "@/components/application/ApplicationForm";
import { prisma } from "@/lib/prisma";

export const metadata = {
  title: "Apply for IDP — BookMyGlobal",
  description: "Apply for your International Driving Permit online. Takes 5 minutes.",
};

export default async function ApplyPage() {
  const { userId } = await auth();

  let applicationsCount = 0;
  let multipleIdpStatus = "NONE";
  let userRole = "USER";

  if (userId) {
    const user = await prisma.user.findUnique({
      where: { clerkId: userId },
      include: {
        _count: {
          select: { applications: true },
        },
      },
    });
    if (user) {
      applicationsCount = user._count.applications;
      multipleIdpStatus = user.multipleIdpStatus;
      userRole = user.role;
    }
  }

  return (
    <main className="flex-1 flex flex-col bg-bg-custom">
      <Header />
      <ApplicationForm
        initialApplicationsCount={applicationsCount}
        initialMultipleIdpStatus={multipleIdpStatus}
        initialUserRole={userRole}
      />
      {/* WhatsApp float */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-50 bg-[#25D366] text-white text-xs font-black px-4 py-3 rounded-full shadow-lg shadow-green-500/30 flex items-center gap-2 whatsapp-float"
      >
        💬 WhatsApp
      </a>
    </main>
  );
}
