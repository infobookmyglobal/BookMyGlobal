import type { Metadata } from 'next';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import { getAllCountryTravelGuideMap } from '@/lib/countryGuideRedirect';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { IDPListClient } from '@/components/IDPListClient';
import { WebPageJsonLd } from '@/components/JsonLd';

export const revalidate = 86400;

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: 'International Driving Permit by Country | IDP Destination Guide',
    description:
      'Find IDP requirements, driving rules, and local tips for Southeast Asia and 150+ countries. Apply for your International Driving Permit online.',
    openGraph: {
      title: 'International Driving Permit Destination Guide',
      description: 'Country-specific IDP rules, driving tips, and requirements for Southeast Asia.',
      type: 'website',
    },
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_APP_URL || 'https://bookmyglobal.com'}/idp`,
    },
  };
}

interface DestPage {
  slug: string;
  urlPath: string;
  country: string;
  cityName: string;
  metaDescription: string;
  pageType: string;
}

export default async function IDPListingPage() {
  let pages: DestPage[] = [];
  let travelGuideMap: Record<string, string> = {};
  try {
    pages = await prisma.destinationPage.findMany({
      where: { isActive: true },
      orderBy: [{ country: 'asc' }, { pageType: 'desc' }],
      select: {
        slug: true,
        urlPath: true,
        country: true,
        cityName: true,
        metaDescription: true,
        pageType: true,
      },
    });
    travelGuideMap = await getAllCountryTravelGuideMap();
  } catch { /* DB not ready at build */ }

  return (
    <>
      <WebPageJsonLd
        name="International Driving Permit by Country | IDP Destination Guide"
        description="Find IDP requirements, driving rules, and local tips for Southeast Asia and 150+ countries. Apply for your International Driving Permit online."
        urlPath="/idp"
      />
      <Header />
      <main>
        {/* Hero */}
        <section className="idp-list-hero">
          <div className="idp-list-hero__inner">
            <div className="glass-pill idp-list-hero__badge">🌏 Southeast Asia</div>
            <h1 className="idp-list-hero__h1">IDP Destination Guide</h1>
            <p className="idp-list-hero__sub">
              Country-specific IDP rules, driving tips, and requirements.<br />
              Apply in minutes. Digital delivery in 2–4 hours.
            </p>
            <Link href="/apply" className="idp-list-hero__cta" id="listing-apply-btn">
              Apply for Your IDP →
            </Link>
          </div>
        </section>

        {/* Stats bar */}
        <div className="idp-list-stats">
          <div className="idp-list-stats__inner">
            <div className="idp-list-stat">
              <span className="idp-list-stat__num">{pages.filter(p => p.pageType === 'HUB').length}</span>
              <span className="idp-list-stat__label">Countries</span>
            </div>
            <div className="idp-list-stat">
              <span className="idp-list-stat__num">{pages.filter(p => p.pageType === 'CITY').length}</span>
              <span className="idp-list-stat__label">City Guides</span>
            </div>
            <div className="idp-list-stat">
              <span className="idp-list-stat__num">{pages.length}</span>
              <span className="idp-list-stat__label">Total Guides</span>
            </div>
            <div className="idp-list-stat">
              <span className="idp-list-stat__num">189+</span>
              <span className="idp-list-stat__label">Countries IDP Valid In</span>
            </div>
          </div>
        </div>

        {/* Country Sections with Interactive Search */}
        <IDPListClient initialPages={pages} travelGuideMap={travelGuideMap} />

        {/* Bottom CTA */}
        <section className="idp-list-cta">
          <div className="idp-list-cta__inner">
            <h2>Don&apos;t see your destination?</h2>
            <p>We support IDP applications for travelers from 189+ countries worldwide.</p>
            <Link href="/apply" className="idp-list-cta__btn" id="listing-footer-apply">
              Apply for Your IDP Online →
            </Link>
          </div>
        </section>
      </main>
      <Footer />

      <style>{`
        /* Hero */
        .idp-list-hero {
          background: linear-gradient(135deg, #001A66 0%, #0033CC 55%, #1a56e0 100%);
          padding: 80px 24px 100px;
          clip-path: ellipse(120% 100% at 50% 0%);
        }
        .idp-list-hero__inner { max-width: 800px; margin: 0 auto; text-align: center; }
        .idp-list-hero__badge {
          display: inline-flex;
          margin-bottom: 20px;
          padding: 6px 16px;
          border-radius: 9999px;
          color: rgba(255,255,255,0.9);
        }
        .idp-list-hero__h1 {
          font-family: var(--font-sora);
          font-size: clamp(32px, 5vw, 52px);
          font-weight: 900;
          color: white;
          margin: 0 0 16px;
        }
        .idp-list-hero__sub {
          font-family: var(--font-dmsans);
          font-size: 17px;
          color: rgba(255,255,255,0.8);
          line-height: 1.6;
          margin: 0 0 28px;
        }
        .idp-list-hero__cta {
          display: inline-block;
          background: #22c55e;
          color: white;
          border-radius: 14px;
          padding: 14px 32px;
          font-family: var(--font-sora);
          font-size: 15px;
          font-weight: 800;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 4px 20px rgba(34,197,94,0.4);
        }
        .idp-list-hero__cta:hover { background: #16a34a; transform: translateY(-2px); }

        /* Stats */
        .idp-list-stats {
          background: rgba(0,51,204,0.05);
          border-bottom: 1px solid rgba(0,51,204,0.1);
        }
        .idp-list-stats__inner {
          max-width: 900px;
          margin: 0 auto;
          padding: 24px;
          display: flex;
          gap: 0;
          justify-content: center;
        }
        .idp-list-stat {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 2px;
          padding: 0 32px;
          border-right: 1px solid rgba(0,51,204,0.15);
        }
        .idp-list-stat:last-child { border-right: none; }
        .idp-list-stat__num {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: #001A66;
        }
        .idp-list-stat__label {
          font-family: var(--font-dmsans);
          font-size: 12px;
          color: #64748b;
          font-weight: 600;
        }

        /* Content */
        .idp-list-content {
          max-width: 1100px;
          margin: 0 auto;
          padding: 48px 24px 64px;
          display: flex;
          flex-direction: column;
          gap: 48px;
        }

        /* Country section */
        .idp-country-section__inner {}
        .idp-country-section__title {
          font-family: var(--font-sora);
          font-size: 22px;
          font-weight: 900;
          color: #001A66;
          margin: 0 0 16px;
          padding-bottom: 10px;
          border-bottom: 2px solid #e2e8f0;
        }

        /* Hub card */
        .idp-hub-card {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          background: linear-gradient(135deg, #001A66 0%, #0a2a8a 100%);
          border-radius: 16px;
          padding: 20px 24px;
          text-decoration: none;
          margin-bottom: 16px;
          transition: all 0.25s ease;
        }
        .idp-hub-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 32px rgba(0,26,102,0.3);
        }
        .idp-hub-card__left { display: flex; flex-direction: column; gap: 6px; }
        .idp-hub-card__badge {
          font-family: var(--font-sora);
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.6);
        }
        .idp-hub-card__name {
          font-family: var(--font-sora);
          font-size: 18px;
          font-weight: 900;
          color: white;
          margin: 0;
        }
        .idp-hub-card__desc {
          font-family: var(--font-dmsans);
          font-size: 13px;
          color: rgba(255,255,255,0.7);
          margin: 0;
          max-width: 600px;
        }
        .idp-hub-card__link {
          font-family: var(--font-sora);
          font-size: 12px;
          font-weight: 800;
          color: #FFD700;
          white-space: nowrap;
          flex-shrink: 0;
        }

        /* City grid */
        .idp-city-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: 14px;
        }
        .idp-city-card {
          display: flex;
          flex-direction: column;
          gap: 6px;
          background: white;
          border: 1.5px solid #e2e8f0;
          border-radius: 14px;
          padding: 18px;
          text-decoration: none;
          transition: all 0.25s ease;
        }
        .idp-city-card:hover {
          border-color: #0033CC;
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0,51,204,0.1);
        }
        .idp-city-card__type {
          font-family: var(--font-sora);
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #0033CC;
        }
        .idp-city-card__name {
          font-family: var(--font-sora);
          font-size: 15px;
          font-weight: 900;
          color: #001A66;
          margin: 0;
        }
        .idp-city-card__desc {
          font-family: var(--font-dmsans);
          font-size: 12px;
          color: #64748b;
          line-height: 1.5;
          margin: 0;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .idp-city-card__link {
          font-family: var(--font-sora);
          font-size: 11px;
          font-weight: 800;
          color: #0033CC;
          margin-top: auto;
          padding-top: 6px;
        }

        /* Bottom CTA */
        .idp-list-cta {
          background: linear-gradient(135deg, #001A66 0%, #0033CC 100%);
          padding: 64px 24px;
          text-align: center;
        }
        .idp-list-cta__inner { max-width: 600px; margin: 0 auto; }
        .idp-list-cta__inner h2 {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: white;
          margin: 0 0 12px;
        }
        .idp-list-cta__inner p {
          font-family: var(--font-dmsans);
          font-size: 15px;
          color: rgba(255,255,255,0.75);
          margin: 0 0 24px;
        }
        .idp-list-cta__btn {
          display: inline-block;
          background: #22c55e;
          color: white;
          border-radius: 12px;
          padding: 14px 32px;
          font-family: var(--font-sora);
          font-size: 14px;
          font-weight: 800;
          text-decoration: none;
          transition: all 0.2s ease;
        }
        .idp-list-cta__btn:hover { background: #16a34a; transform: translateY(-2px); }

        @media (max-width: 640px) {
          .idp-list-stats__inner { flex-wrap: wrap; gap: 16px; }
          .idp-list-stat { border-right: none; padding: 0 16px; }
          .idp-hub-card { flex-direction: column; align-items: flex-start; }
        }
      `}</style>
    </>
  );
}
