import Link from 'next/link';

export default function DestinationNotFound() {
  return (
    <div className="dest-404">
      <div className="dest-404__inner">
        <span className="dest-404__icon">🗺️</span>
        <h1 className="dest-404__title">Destination Not Found</h1>
        <p className="dest-404__msg">
          We couldn&apos;t find an IDP guide for this destination. Browse all our country and city guides below.
        </p>
        <div className="dest-404__actions">
          <Link href="/idp" className="dest-404__btn dest-404__btn--primary">
            Browse All Destinations →
          </Link>
          <Link href="/apply" className="dest-404__btn">
            Apply for IDP
          </Link>
        </div>
      </div>

      <style>{`
        .dest-404 {
          min-height: 60vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 48px 24px;
        }
        .dest-404__inner { text-align: center; max-width: 480px; }
        .dest-404__icon { font-size: 56px; display: block; margin-bottom: 20px; }
        .dest-404__title {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: #001A66;
          margin: 0 0 12px;
        }
        .dest-404__msg {
          font-family: var(--font-dmsans);
          font-size: 15px;
          color: #64748b;
          line-height: 1.7;
          margin: 0 0 28px;
        }
        .dest-404__actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
        .dest-404__btn {
          display: inline-block;
          padding: 12px 24px;
          border-radius: 10px;
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          text-decoration: none;
          background: #f1f5f9;
          color: #001A66;
          transition: background 0.2s;
        }
        .dest-404__btn:hover { background: #e2e8f0; }
        .dest-404__btn--primary { background: #0033CC; color: white; }
        .dest-404__btn--primary:hover { background: #001A66; }
      `}</style>
    </div>
  );
}
