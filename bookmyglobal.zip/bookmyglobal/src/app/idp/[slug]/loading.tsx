export default function DestinationLoading() {
  return (
    <div className="dest-skeleton">
      {/* Hero skeleton */}
      <div className="skel-hero">
        <div className="skel-bar skel-bar--sm" style={{ width: '200px' }} />
        <div className="skel-bar skel-bar--xl" style={{ width: '80%', maxWidth: '700px' }} />
        <div className="skel-bar" style={{ width: '300px' }} />
      </div>

      {/* Facts bar skeleton */}
      <div className="skel-facts">
        {[1,2,3,4].map(i => (
          <div key={i} className="skel-fact-pill">
            <div className="skel-circle" />
            <div style={{ flex: 1 }}>
              <div className="skel-bar skel-bar--sm" style={{ width: '60%', marginBottom: '6px' }} />
              <div className="skel-bar" style={{ width: '80%' }} />
            </div>
          </div>
        ))}
      </div>

      {/* Content skeleton */}
      <div className="skel-content">
        <div className="skel-main">
          {[1,2,3,4,5].map(i => (
            <div key={i} className="skel-bar" style={{ width: `${70 + Math.random() * 30}%`, marginBottom: '12px' }} />
          ))}
        </div>
        <div className="skel-sidebar">
          <div className="skel-card" />
        </div>
      </div>

      <style>{`
        .dest-skeleton { background: #f2f4f8; min-height: 100vh; }
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .skel-bar {
          height: 14px;
          background: linear-gradient(90deg, #e2e8f0 25%, #f0f4f8 50%, #e2e8f0 75%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
          border-radius: 6px;
        }
        .skel-bar--sm { height: 10px; }
        .skel-bar--xl { height: 36px; }
        .skel-hero {
          background: linear-gradient(135deg, #001A66 0%, #0033CC 100%);
          padding: 80px 24px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
        }
        .skel-hero .skel-bar {
          background: linear-gradient(90deg, rgba(255,255,255,0.1) 25%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.1) 75%);
          background-size: 200% 100%;
        }
        .skel-facts {
          display: flex;
          gap: 12px;
          justify-content: center;
          padding: 20px 24px;
          flex-wrap: wrap;
        }
        .skel-fact-pill {
          display: flex;
          gap: 10px;
          background: white;
          border-radius: 14px;
          padding: 14px 18px;
          min-width: 190px;
          flex: 1;
          align-items: center;
          border: 1.5px solid #e2e8f0;
        }
        .skel-circle {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: linear-gradient(90deg, #e2e8f0 25%, #f0f4f8 50%, #e2e8f0 75%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
          flex-shrink: 0;
        }
        .skel-content {
          max-width: 1100px;
          margin: 48px auto;
          padding: 0 24px;
          display: grid;
          grid-template-columns: 1fr 340px;
          gap: 48px;
        }
        .skel-main { display: flex; flex-direction: column; }
        .skel-sidebar {}
        .skel-card {
          height: 400px;
          background: linear-gradient(90deg, #e2e8f0 25%, #f0f4f8 50%, #e2e8f0 75%);
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
          border-radius: 20px;
        }
        @media (max-width: 900px) {
          .skel-content { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
