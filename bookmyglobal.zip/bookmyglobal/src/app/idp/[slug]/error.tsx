'use client';

import Link from 'next/link';

export default function DestinationError({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="dest-error">
      <div className="dest-error__inner">
        <span className="dest-error__icon">🗺️</span>
        <h1 className="dest-error__title">Destination Not Found</h1>
        <p className="dest-error__msg">{error?.message || 'This destination guide could not be loaded.'}</p>
        <div className="dest-error__actions">
          <button onClick={reset} className="dest-error__btn dest-error__btn--primary">Try Again</button>
          <Link href="/idp" className="dest-error__btn">Browse All Destinations</Link>
        </div>
      </div>

      <style>{`
        .dest-error {
          min-height: 60vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 48px 24px;
        }
        .dest-error__inner { text-align: center; max-width: 480px; }
        .dest-error__icon { font-size: 56px; display: block; margin-bottom: 20px; }
        .dest-error__title {
          font-family: var(--font-sora);
          font-size: 28px;
          font-weight: 900;
          color: #001A66;
          margin: 0 0 12px;
        }
        .dest-error__msg {
          font-family: var(--font-dmsans);
          font-size: 15px;
          color: #64748b;
          margin: 0 0 24px;
        }
        .dest-error__actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
        .dest-error__btn {
          display: inline-block;
          padding: 12px 24px;
          border-radius: 10px;
          font-family: var(--font-sora);
          font-size: 13px;
          font-weight: 800;
          text-decoration: none;
          background: #f1f5f9;
          color: #001A66;
          border: none;
          cursor: pointer;
          transition: background 0.2s;
        }
        .dest-error__btn:hover { background: #e2e8f0; }
        .dest-error__btn--primary { background: #0033CC; color: white; }
        .dest-error__btn--primary:hover { background: #001A66; }
      `}</style>
    </div>
  );
}
