import { notFound, redirect } from 'next/navigation';
import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';
import { getTravelGuideRedirectUrlForCountry } from '@/lib/countryGuideRedirect';
import { DestinationPageTemplate } from '@/components/destination/DestinationPageTemplate';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { CustomStructuredData } from '@/components/JsonLd';

export const revalidate = 86400; // 24 hours ISR

interface Props {
  params: Promise<{ slug: string }>;
}

// Pre-render all 46 pages at build time
export async function generateStaticParams() {
  try {
    const pages = await prisma.destinationPage.findMany({
      where: { isActive: true },
      select: { slug: true },
    });
    const isCloudBuild = process.env.NETLIFY === 'true' || process.env.VERCEL === 'true';
    if (!isCloudBuild) {
      return pages.slice(0, 5).map((p) => ({ slug: p.slug }));
    }
    return pages.map((p) => ({ slug: p.slug }));
  } catch {
    return [];
  }
}

// Per-page dynamic metadata
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://bookmyglobal.com';

  try {
    const page = await prisma.destinationPage.findUnique({ where: { slug } });
    if (!page) return { title: 'IDP Destination Guide | BookMyGlobal' };

    return {
      title: page.metaTitle,
      description: page.metaDescription,
      openGraph: {
        title: page.metaTitle,
        description: page.metaDescription,
        url: page.canonicalUrl || `${APP_URL}/idp/${page.slug}`,
        type: 'article',
        siteName: 'BookMyGlobal',
      },
      twitter: {
        card: 'summary_large_image',
        title: page.metaTitle,
        description: page.metaDescription,
      },
      alternates: {
        canonical: page.canonicalUrl || `${APP_URL}/idp/${page.slug}`,
      },
    };
  } catch {
    return { title: 'IDP Destination Guide | BookMyGlobal' };
  }
}

function generateStructuredData(page: {
  h1: string;
  metaDescription: string;
  slug: string;
}) {
  const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://bookmyglobal.com';
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: page.h1,
    description: page.metaDescription,
    author: {
      '@type': 'Organization',
      name: 'BookMyGlobal',
    },
    publisher: {
      '@type': 'Organization',
      name: 'BookMyGlobal',
      url: APP_URL,
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `${APP_URL}/idp/${page.slug}`,
    },
  };
}

export default async function DestinationPageRoute({ params }: Props) {
  const { slug } = await params;

  const page = await prisma.destinationPage.findUnique({
    where: { slug, isActive: true },
  });

  if (!page) notFound();

  // Redirect to manual target or matching Know More Travel Guide if it exists for this country/slug
  const redirectUrl = await getTravelGuideRedirectUrlForCountry(slug, page.country || page.cityName);
  if (redirectUrl) {
    redirect(redirectUrl);
  }

  // Parse JSON-stored internal links
  let linkSlugs: string[] = [];
  try {
    const parsed = JSON.parse(page.internalLinks || '[]');
    linkSlugs = (parsed as string[]).map((l: string) => l.replace('/', ''));
  } catch { /* empty */ }

  // Fetch related pages
  const relatedPages = linkSlugs.length
    ? await prisma.destinationPage.findMany({
        where: { slug: { in: linkSlugs }, isActive: true },
        select: { slug: true, urlPath: true, cityName: true, country: true, metaTitle: true, pageType: true },
      })
    : [];

  // Fetch hub page for city pages
  const hubPage =
    page.pageType === 'CITY'
      ? await prisma.destinationPage.findFirst({
          where: { country: page.country, pageType: 'HUB', isActive: true },
          select: { slug: true, urlPath: true, cityName: true },
        })
      : null;

  // Fetch country data for Quick Facts Bar
  const countryData = await prisma.country.findFirst({
    where: { name: { contains: page.country } },
    select: { drivingSide: true, requiresPhysical: true, maxValidity: true, convention: true },
  });

  return (
    <>
      {page.structuredData ? (
        <CustomStructuredData data={page.structuredData} />
      ) : (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(generateStructuredData(page)) }}
        />
      )}
      <Header />
      <DestinationPageTemplate
        page={page}
        relatedPages={relatedPages}
        hubPage={hubPage}
        countryData={countryData}
      />
      <Footer />
    </>
  );
}
