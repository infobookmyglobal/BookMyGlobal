import { prisma } from "@/lib/prisma";
import { getS3Object } from "@/lib/s3";
import { NextRequest } from "next/server";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const application = await prisma.application.findUnique({
      where: { id },
      select: { pdfIdCardUrl: true, fullName: true },
    });

    if (!application || !application.pdfIdCardUrl) {
      return new Response("ID Card not found", { status: 404 });
    }

    const s3Response = await getS3Object(application.pdfIdCardUrl);
    if (!s3Response.Body) {
      return new Response("Failed to fetch ID card from storage", { status: 500 });
    }

    const bytes = await s3Response.Body.transformToByteArray();
    const fileName = `IDP_Card_${application.fullName.replace(/[^a-zA-Z0-9]/g, "_")}.pdf`;

    return new Response(bytes as any, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${fileName}"`,
      },
    });
  } catch (err: any) {
    console.error("Error serving ID card PDF:", err);
    return new Response("Internal Server Error", { status: 500 });
  }
}
