export default function BlogLoading() {
  return (
    <div className="min-h-screen bg-bg-custom animate-pulse">
      <div className="bg-navy py-16 px-4">
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="h-10 w-64 bg-white/20 rounded-xl mx-auto" />
          <div className="h-5 w-48 bg-white/10 rounded-lg mx-auto" />
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(9)].map((_, i) => (
          <div key={i} className="bg-white rounded-2xl border border-border-custom overflow-hidden">
            <div className="h-48 bg-gray-200" />
            <div className="p-5 space-y-3">
              <div className="h-4 w-20 bg-gray-100 rounded" />
              <div className="h-6 w-full bg-gray-200 rounded" />
              <div className="h-4 w-3/4 bg-gray-100 rounded" />
              <div className="h-4 w-1/2 bg-gray-100 rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
