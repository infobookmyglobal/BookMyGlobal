import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { prisma } from "@/lib/prisma";
import { Sparkles } from "lucide-react";
import { BlogClientPage } from "@/components/BlogClientPage";
import Link from "next/link";
import { WebPageJsonLd } from "@/components/JsonLd";

// Estimate reading time dynamically
function getReadTime(content: string): string {
  const wordsPerMinute = 225;
  const noOfWords = content.split(/\s+/).length;
  const minutes = Math.ceil(noOfWords / wordsPerMinute);
  return `${minutes} min read`;
}

export const revalidate = 60;

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://bookmyglobal.com";

export const metadata = {
  title: "Official Driving Guides & Travel Blogs | BookMyGlobal",
  description: "Stay updated with global driving regulations, international road rules, travel tips, and permit requirements from local experts.",
  alternates: {
    canonical: `${APP_URL}/blog`,
  },
  openGraph: {
    type: "website" as const,
    title: "International Driving Permit Guides & Blogs",
    description: "Expert advice on global driving laws, car rentals abroad, highway safety, and IDP permit requirements.",
    url: `${APP_URL}/blog`,
    siteName: "BookMyGlobal",
    images: [{ url: `${APP_URL}/og-home.jpg`, width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image" as const,
    title: "International Driving Permit Guides & Blogs",
    description: "Expert advice on global driving laws, car rentals abroad, highway safety and IDP requirements.",
    images: [`${APP_URL}/og-home.jpg`],
  },
  robots: { index: true, follow: true },
};

export default async function BlogFeedPage() {
  // Query all published blogs
  const blogs = await prisma.blog.findMany({
    where: {
      status: "PUBLISHED",
    },
    orderBy: {
      publishedAt: "desc",
    },
  });

  const featuredPost = blogs[0];
  const remainingPosts = blogs.slice(1);

  // Dynamically extract categories
  const categories = ["All", ...Array.from(new Set(blogs.map(b => b.category).filter(Boolean)))];

  return (
    <main className="flex-1 flex flex-col bg-white">
      <WebPageJsonLd
        name="Official Driving Guides & Travel Blogs"
        description="Stay updated with global driving regulations, international road rules, travel tips, and permit requirements from local experts."
        urlPath="/blog"
      />
      <Header />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-navy to-blue py-16 px-4 overflow-hidden text-center">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,215,0,0.1),transparent_40%)]" />
        <div className="relative z-10 max-w-3xl mx-auto">
          <span className="eyebrow-pill mb-4 bg-white/10 text-gold uppercase tracking-wider text-xs font-black">
            <Sparkles className="w-3.5 h-3.5 text-gold mr-1 animate-pulse" /> Official Guide & Knowledge Hub
          </span>
          <h1 className="font-sora text-3xl md:text-5xl font-black text-white mb-4 leading-tight">
            International Driving <em className="text-gold not-italic">Permit Guides</em>
          </h1>
          <p className="text-white/80 text-base md:text-lg max-w-xl mx-auto">
            Get expert advice on global driving laws, car rentals abroad, highway safety, and travel compliance tips.
          </p>
        </div>
      </section>

      <BlogClientPage initialBlogs={JSON.parse(JSON.stringify(blogs))} />

      {/* Dynamic CTA Banner */}
      <section className="bg-bg-custom border-t border-border-custom py-16 px-4 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
          <span className="eyebrow-pill">Ready to drive abroad?</span>
          <h2 className="section-heading mb-2">Get Your International Driving Permit Today</h2>
          <p className="text-muted text-base max-w-lg mx-auto">
            Apply online in just 5 minutes. Valid in over 150+ countries with digital copies sent in 2 hours and rapid physical express shipping.
          </p>
          <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center items-center">
            <Link href="/apply" className="btn-primary px-8 py-4 text-base shadow-lg shadow-green-500/20 w-full sm:w-auto">
              Start Application
            </Link>
            <Link href="/idp" className="btn-secondary px-8 py-4 text-base w-full sm:w-auto">
              View Destinations
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
