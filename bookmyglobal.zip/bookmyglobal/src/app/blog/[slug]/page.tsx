import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Calendar, Clock, ArrowLeft, Tag, BookOpen, ChevronRight, User, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import type { Metadata } from "next";
import { auth } from "@clerk/nextjs/server";
import Script from "next/script";
import { CustomStructuredData } from "@/components/JsonLd";
import { getBlogAuthor } from "@/lib/utils";
import { AuthorBox } from "@/components/blog/AuthorBox";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://bookmyglobal.com";

interface Props {
  params: Promise<{ slug: string }>;
}

// Estimate reading time dynamically
function getReadTime(content: string): string {
  const wordsPerMinute = 225;
  // Fallback if the content is TipTap JSON string
  let textContent = content;
  if (content.trim().startsWith("{")) {
    try {
      const parsed = JSON.parse(content);
      const extractText = (nodes: any[]): string => {
        if (!Array.isArray(nodes)) return "";
        return nodes.map((node) => {
          if (node.type === "text") return node.text || "";
          return extractText(node.content);
        }).join(" ");
      };
      if (parsed && Array.isArray(parsed.content)) {
        textContent = extractText(parsed.content);
      }
    } catch {
      textContent = content;
    }
  }

  const noOfWords = textContent.split(/\s+/).length;
  const minutes = Math.ceil(noOfWords / wordsPerMinute);
  return `${minutes} min read`;
}

// Convert TipTap JSON schema to clean semantic HTML strings
function renderTiptapJsonToHtml(jsonString: string): string {
  if (!jsonString) return "";
  
  if (!jsonString.trim().startsWith("{")) {
    return jsonString; // Fallback if raw HTML/plain-text is saved
  }
  
  try {
    const doc = JSON.parse(jsonString);
    if (!doc || doc.type !== "doc" || !Array.isArray(doc.content)) {
      return jsonString;
    }
    
    return renderNodes(doc.content);
  } catch (e) {
    return jsonString;
  }
}

function renderNodes(nodes: any[]): string {
  if (!Array.isArray(nodes)) return "";
  return nodes.map(renderNode).join("");
}

function renderNode(node: any): string {
  if (!node) return "";
  
  if (node.type === "text") {
    let text = escapeHtml(node.text || "");
    if (Array.isArray(node.marks)) {
      for (const mark of node.marks) {
        if (mark.type === "bold") {
          text = `<strong>${text}</strong>`;
        } else if (mark.type === "italic") {
          text = `<em>${text}</em>`;
        } else if (mark.type === "link") {
          const href = mark.attrs?.href || "#";
          const target = mark.attrs?.target || "_blank";
          text = `<a href="${escapeHtml(href)}" target="${escapeHtml(target)}" rel="noopener noreferrer">${text}</a>`;
        }
      }
    }
    return text;
  }
  
  const childHtml = renderNodes(node.content);
  
  switch (node.type) {
    case "paragraph":
      return `<p>${childHtml || "&nbsp;"}</p>`;
    case "heading": {
      const level = node.attrs?.level || 1;
      return `<h${level}>${childHtml}</h${level}>`;
    }
    case "bulletList":
      return `<ul>${childHtml}</ul>`;
    case "orderedList":
      return `<ol>${childHtml}</ol>`;
    case "listItem":
      return `<li>${childHtml}</li>`;
    case "blockquote":
      return `<blockquote>${childHtml}</blockquote>`;
    case "image": {
      const src = node.attrs?.src || "";
      const alt = node.attrs?.alt || "";
      const title = node.attrs?.title || "";
      return `<img src="${escapeHtml(src)}" alt="${escapeHtml(alt)}" title="${escapeHtml(title)}" loading="lazy" class="my-6 max-w-full rounded-xl border border-border-custom shadow-md" />`;
    }
    case "horizontalRule":
      return "<hr />";
    case "hardBreak":
      return "<br />";
    default:
      return childHtml;
  }
}

function escapeHtml(unsafe: string): string {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Dynamic SEO metadata generation — full OG + Twitter + canonical + robots
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = await prisma.blog.findUnique({ where: { slug } });

  if (!post) return { title: "Article Not Found" };

  const seoTitle = post.seoTitle || post.title;
  const seoDesc = post.seoDescription || post.excerpt || `Read our expert guide about ${post.title}.`;
  const ogImg = post.ogImage || post.featuredImageUrl || `${APP_URL}/og-home.jpg`;
  const canonical = post.canonicalUrl || `${APP_URL}/blog/${post.slug}`;
  const robotsDirective = post.robots || "index, follow";
  const isNoIndex = robotsDirective.includes("noindex");

  return {
    title: seoTitle,
    description: seoDesc,
    alternates: { canonical },
    robots: {
      index: !isNoIndex,
      follow: !robotsDirective.includes("nofollow"),
      googleBot: { index: !isNoIndex, follow: !robotsDirective.includes("nofollow") },
    },
    openGraph: {
      type: "article",
      title: seoTitle,
      description: seoDesc,
      url: canonical,
      siteName: "BookMyGlobal",
      images: [{ url: ogImg, width: 1200, height: 630, alt: post.title }],
      publishedTime: post.publishedAt?.toISOString(),
      modifiedTime: post.updatedAt?.toISOString(),
      section: post.category || "Driving Guides",
      tags: post.tags ? post.tags.split(",").map((t) => t.trim()) : [],
    },
    twitter: {
      card: "summary_large_image",
      title: seoTitle,
      description: seoDesc,
      images: [ogImg],
    },
  };
}

// Static params for ISR — generate slugs for all published posts
export async function generateStaticParams() {
  try {
    const posts = await prisma.blog.findMany({
      where: { status: "PUBLISHED" },
      select: { slug: true },
    });
    const isCloudBuild = process.env.NETLIFY === 'true' || process.env.VERCEL === 'true';
    if (!isCloudBuild) {
      return posts.slice(0, 5).map((p) => ({ slug: p.slug }));
    }
    return posts.map((p) => ({ slug: p.slug }));
  } catch {
    return [];
  }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  // Validate if active viewer is system admin
  let isAdmin = false;
  if (process.env.NODE_ENV === "development") {
    isAdmin = true;
  } else {
    const { userId } = await auth();
    if (userId) {
      const dbUser = await prisma.user.findUnique({
        where: { clerkId: userId },
        select: { role: true },
      });
      isAdmin = dbUser?.role === "ADMIN";
    }
  }

  // Retrieve matching article (admins are authorized to preview draft posts)
  const post = await prisma.blog.findFirst({
    where: {
      slug,
      status: isAdmin ? undefined : "PUBLISHED",
    },
  });

  if (!post) {
    notFound();
  }

  const parsedHtml = renderTiptapJsonToHtml(post.content);

  // Retrieve related articles (same category or recent, excluding current)
  const relatedPosts = await prisma.blog.findMany({
    where: {
      status: "PUBLISHED",
      NOT: {
        id: post.id,
      },
      category: post.category || undefined,
    },
    take: 3,
    orderBy: {
      publishedAt: "desc",
    },
  });

  // If we don't have 3 related posts of the same category, fetch recent ones
  let finalRelated = [...relatedPosts];
  if (finalRelated.length < 3) {
    const extraNeeded = 3 - finalRelated.length;
    const extraPosts = await prisma.blog.findMany({
      where: {
        status: "PUBLISHED",
        NOT: {
          id: post.id,
        },
        id: {
          notIn: finalRelated.map((p) => p.id),
        },
      },
      take: extraNeeded,
      orderBy: {
        publishedAt: "desc",
      },
    });
    finalRelated = [...finalRelated, ...extraPosts];
  }

  const publishDate = post.publishedAt || post.createdAt;
  const tagsList = post.tags ? post.tags.split(",").map((t) => t.trim()) : [];
  const authorName = getBlogAuthor(post.slug);

  // Build Article JSON-LD structured data
  const articleJsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.seoDescription || post.excerpt || "",
    image: post.ogImage || post.featuredImageUrl || `${APP_URL}/og-home.jpg`,
    datePublished: (post.publishedAt || post.createdAt).toISOString(),
    dateModified: post.updatedAt.toISOString(),
    author: {
      "@type": "Person",
      name: authorName,
      url: APP_URL,
    },
    publisher: {
      "@type": "Organization",
      name: "BookMyGlobal",
      url: APP_URL,
      logo: {
        "@type": "ImageObject",
        url: `${APP_URL}/images/logo.png`,
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": post.canonicalUrl || `${APP_URL}/blog/${post.slug}`,
    },
    keywords: post.tags || post.category || "",
    articleSection: post.category || "Driving Guides",
    inLanguage: "en-US",
  };

  return (
    <main className="flex-1 flex flex-col bg-white">
      {post.structuredData ? (
        <CustomStructuredData data={post.structuredData} />
      ) : (
        <Script
          id={`article-jsonld-${post.id}`}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(articleJsonLd) }}
          strategy="beforeInteractive"
        />
      )}
      <Header />

      {/* Admin Preview Mode Warning Bar */}
      {post.status === "DRAFT" && (
        <div className="bg-amber-50 border-b border-amber-200 py-3 px-4 flex items-center justify-center gap-2 text-xs font-bold text-amber-800">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>PREVIEW MODE: This is a Draft post. Public visitors will see a 404 page, but you are authorized to view it.</span>
        </div>
      )}

      {/* Back to Blog Breadcrumb bar */}
      <div className="bg-bg-custom border-b border-border-custom py-4 px-4">
        <div className="container mx-auto max-w-4xl flex items-center gap-2 text-xs font-bold text-muted">
          <Link href="/" className="hover:text-blue transition-colors">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link href="/blog" className="hover:text-blue transition-colors">Blog</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-text-custom truncate max-w-[200px] md:max-w-xs">{post.title}</span>
        </div>
      </div>

      {/* Article Content Container */}
      <article className="py-12 md:py-16 px-4 max-w-4xl mx-auto w-full">
        {/* Header Block */}
        <header className="space-y-6 text-center md:text-left mb-10">
          {post.category && (
            <span className="eyebrow-pill bg-blue/10 text-blue font-black uppercase tracking-wider text-xs">
              {post.category}
            </span>
          )}

          <h1 className="font-sora text-3xl md:text-5xl font-black text-navy leading-tight">
            {post.title}
          </h1>

          <p className="text-muted text-lg leading-relaxed max-w-3xl">
            {post.excerpt}
          </p>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 pt-4 border-t border-border-custom text-sm font-bold text-muted">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-blue/10 flex items-center justify-center text-blue">
                <User className="w-4 h-4" />
              </div>
              <span>By {authorName}</span>
            </div>

            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              {post.status === "DRAFT" ? "Not Published (Draft)" : format(new Date(publishDate), "dd MMMM yyyy")}
            </span>

            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              {getReadTime(post.content)}
            </span>
          </div>
        </header>

        {/* Featured Image */}
        {post.featuredImageUrl && (
          <div className="relative aspect-[21/9] w-full rounded-2xl overflow-hidden shadow-md mb-12 border border-border-custom">
            <Image
              src={post.featuredImageUrl}
              alt={post.title}
              fill
              className="object-cover"
              priority
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 1200px"
            />
          </div>
        )}

        {/* HTML Rich Text Body Rendering */}
        <div className="prose-container mx-auto">
          <div 
            className="rich-text-content leading-relaxed text-text-custom"
            dangerouslySetInnerHTML={{ __html: parsedHtml }} 
          />
        </div>

        {/* Tags Footer */}
        {tagsList.length > 0 && (
          <div className="mt-12 pt-8 border-t border-border-custom flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-muted flex items-center gap-1 mr-2">
              <Tag className="w-3.5 h-3.5" /> Tags:
            </span>
            {tagsList.map((tag) => (
              <span 
                key={tag}
                className="bg-bg-custom border border-border-custom px-3 py-1 rounded-full text-xs font-bold text-muted"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* About the Author Box */}
        <AuthorBox />

        {/* Back Link */}
        <div className="mt-12 pt-6 border-t border-border-custom">
          <Link 
            href="/blog" 
            className="inline-flex items-center gap-2 text-blue font-black hover:text-navy transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Blog Feed
          </Link>
        </div>
      </article>

      {/* Related Posts Section */}
      {finalRelated.length > 0 && (
        <section className="bg-bg-custom border-t border-border-custom py-16 px-4">
          <div className="max-w-6xl mx-auto space-y-8">
            <div className="text-center md:text-left">
              <h3 className="font-sora font-black text-navy text-2xl">
                Keep Reading
              </h3>
              <p className="text-muted text-sm mt-1">
                More helpful international driving guides and tips from our experts.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {finalRelated.map((p) => (
                <article 
                  key={p.id}
                  className="group flex flex-col bg-white border border-border-custom rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300"
                >
                  <div className="relative aspect-video">
                    {p.featuredImageUrl ? (
                      <Image 
                        src={p.featuredImageUrl}
                        alt={p.title}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                      />
                    ) : (
                      <div className="absolute inset-0 bg-navy/10 flex items-center justify-center text-navy">
                        <BookOpen className="w-10 h-10 opacity-30" />
                      </div>
                    )}
                    {p.category && (
                      <span className="absolute top-3 left-3 bg-navy text-white text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded">
                        {p.category}
                      </span>
                    )}
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-[9px] font-bold text-muted uppercase">
                        <Calendar className="w-2.5 h-2.5" />
                        {format(new Date(p.publishedAt || p.createdAt), "dd MMM yyyy")}
                      </div>
                      <h4 className="font-sora font-black text-navy text-base leading-snug group-hover:text-blue transition-colors line-clamp-2">
                        <Link href={`/blog/${p.slug}`}>{p.title}</Link>
                      </h4>
                    </div>

                    <div>
                      <Link 
                        href={`/blog/${p.slug}`}
                        className="text-xs font-black text-blue hover:text-navy transition-colors inline-flex items-center gap-1"
                      >
                        Read Post <ChevronRight className="w-3 h-3" />
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
