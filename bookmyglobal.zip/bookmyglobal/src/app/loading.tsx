export default function Loading() {
  return (
    <div className="min-h-screen bg-bg-custom animate-pulse">
      {/* Hero skeleton */}
      <div className="bg-navy pt-24 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="h-6 w-48 bg-white/20 rounded-full mx-auto" />
          <div className="h-12 w-3/4 bg-white/20 rounded-xl mx-auto" />
          <div className="h-12 w-2/3 bg-white/20 rounded-xl mx-auto" />
          <div className="h-5 w-1/2 bg-white/10 rounded-lg mx-auto" />
          <div className="flex gap-4 justify-center">
            <div className="h-12 w-44 bg-gold/40 rounded-xl" />
            <div className="h-12 w-36 bg-white/20 rounded-xl" />
          </div>
        </div>
      </div>
      {/* Stats skeleton */}
      <div className="bg-white border-b border-border-custom py-8 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="text-center space-y-2">
              <div className="h-8 w-24 bg-gray-200 rounded-lg mx-auto" />
              <div className="h-4 w-32 bg-gray-100 rounded mx-auto" />
            </div>
          ))}
        </div>
      </div>
      {/* Cards skeleton */}
      <div className="max-w-6xl mx-auto px-4 py-16 grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-64 bg-white rounded-2xl border border-border-custom" />
        ))}
      </div>
    </div>
  );
}
