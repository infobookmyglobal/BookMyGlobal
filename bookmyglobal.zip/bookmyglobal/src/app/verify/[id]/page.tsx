import { WHATSAPP_URL } from "@/lib/contact";
import { prisma } from "@/lib/prisma";
import { CheckCircle, AlertTriangle, XCircle, User } from "lucide-react";
import { format } from "date-fns";
import { getPresignedDownloadUrl } from "@/lib/s3";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const app = await prisma.application.findUnique({
    where: { id },
    select: { fullName: true },
  });
  return {
    title: app ? `IDP Verification — ${app.fullName}` : "IDP Verification",
  };
}

export default async function VerifyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const application = await prisma.application.findUnique({
    where: { id },
    include: { user: true },
  });

  let state: "valid" | "expired" | "invalid" = "invalid";

  if (application) {
    if (application.status === "APPROVED" || application.status === "COMPLETED") {
      const expiryDate = new Date(application.createdAt);
      expiryDate.setFullYear(expiryDate.getFullYear() + application.validity);
      state = expiryDate > new Date() ? "valid" : "expired";
    }
  }

  const issueDate = application ? format(application.createdAt, "dd MMM yyyy") : null;
  const expiryDate = application
    ? format(
        new Date(new Date(application.createdAt).setFullYear(new Date(application.createdAt).getFullYear() + (application.validity ?? 1))),
        "dd MMM yyyy"
      )
    : null;
  const dobStr = application?.dob ? format(new Date(application.dob), "dd MMM yyyy") : null;

  let photoUrl: string | null = null;
  if (application?.profilePhotoUrl) {
    if (application.profilePhotoUrl.startsWith("http")) {
      photoUrl = application.profilePhotoUrl;
    } else {
      try {
        photoUrl = await getPresignedDownloadUrl(application.profilePhotoUrl, 3600);
      } catch (err) {
        console.error("Failed to generate presigned URL for profile photo:", err);
      }
    }
  }

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Status Banner */}
        <div
          className={`relative pt-8 pb-14 px-6 text-center ${
            state === "valid" ? "bg-green-50" : state === "expired" ? "bg-yellow-50" : "bg-red-50"
          }`}
        >
          {state === "valid" && <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-3" />}
          {state === "expired" && <AlertTriangle className="w-20 h-20 text-yellow-500 mx-auto mb-3" />}
          {state === "invalid" && <XCircle className="w-20 h-20 text-red-500 mx-auto mb-3" />}

          <h1 className={`font-sora text-2xl font-black ${
            state === "valid" ? "text-green-800" : state === "expired" ? "text-yellow-800" : "text-red-800"
          }`}>
            {state === "valid" ? "✅ VALID IDP" : state === "expired" ? "⚠️ EXPIRED IDP" : "❌ INVALID IDP"}
          </h1>
          <p className={`text-sm mt-1 font-bold ${
            state === "valid" ? "text-green-600" : state === "expired" ? "text-yellow-600" : "text-red-600"
          }`}>
            {state === "valid"
              ? "This permit is authentic and currently valid"
              : state === "expired"
              ? "This permit has expired and is no longer valid"
              : "This permit could not be verified"}
          </p>
        </div>

        {/* Details */}
        {application && (
          <div className="relative p-6 pt-0 space-y-4">
            {/* Overlapping Profile Photo */}
            <div className="relative flex flex-col items-center -mt-12 mb-4">
              <div className="w-24 h-24 rounded-full border-4 border-white bg-slate-100 flex items-center justify-center shadow-lg overflow-hidden text-slate-400 relative">
                {photoUrl ? (
                  <img
                    src={photoUrl}
                    alt={application.fullName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-12 h-12 text-slate-300" />
                )}
              </div>
            </div>

            <div className="space-y-3">
              <Row label="Holder Name" value={application.fullName} />
              {dobStr && <Row label="Date of Birth" value={dobStr} />}
              <Row label="IDP Number" value={application.idpNumber || "Pending"} highlight />
              {application.licenseNumber && (
                <Row label="Domestic License" value={application.licenseNumber} />
              )}
              {application.licenseClass && (
                <Row label="Vehicle Classes" value={application.licenseClass} highlight />
              )}
              <Row label="Issue Date" value={issueDate!} />
              <Row label="Expiry Date" value={expiryDate!} />
              <Row label="Product" value={application.productType === "NFC_KIT" ? "NFC Smart Kit" : "Digital IDP"} />
              <Row label="Nationality" value={application.country} />
            </div>

            <div className="border-t border-border-custom pt-4 text-center">
              <p className="text-xs text-muted">Issued by</p>
              <p className="font-sora font-black text-navy text-sm">BookMyGlobal</p>
              <p className="text-xs text-muted mt-1">bookmyglobal.com</p>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-xs text-yellow-800 font-medium">
              ⚠️ An IDP must always be carried alongside the original domestic driving license.
            </div>
          </div>
        )}

        {!application && (
          <div className="p-6 text-center">
            <p className="text-muted text-sm">No permit found with this ID. Please check the QR code or contact support.</p>
            <a
              href={WHATSAPP_URL}
              className="inline-block mt-4 bg-[#25D366] text-white font-bold px-5 py-2 rounded-xl text-sm"
            >
              💬 Contact Support
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, highlight = false }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-xs text-muted font-bold shrink-0">{label}</span>
      <span className={`text-sm text-right font-bold ${highlight ? "text-blue tracking-wider font-mono" : "text-text-custom"}`}>
        {value}
      </span>
    </div>
  );
}
