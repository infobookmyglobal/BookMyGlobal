"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

interface Country {
  name: string;
  requiresPhysical: boolean;
}

export function EditApplicationClient({
  application,
  countries = [],
}: {
  application: any;
  countries?: Country[];
}) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [fields, setFields] = useState({
    fullName: application.fullName || "",
    email: application.email || "",
    phone: application.phone || "",
    country: application.country || "",
    dob: application.dob ? new Date(application.dob).toISOString().split("T")[0] : "",
    licenseNumber: application.licenseNumber || "",
    gender: application.gender || "",
    countryOfBirth: application.countryOfBirth || "",
    countryOfResidence: application.countryOfResidence || "",
    licenseClass: application.licenseClass || "",
    parentName: application.parentName || "",
    destinationCountry: application.destinationCountry || "",
    address: application.address || "",
  });

  const selectedCountryObj = countries.find(
    (c) => c.name.toLowerCase() === fields.destinationCountry.trim().toLowerCase()
  );
  const isInvalidDestination = application.productType === "DIGITAL" && selectedCountryObj?.requiresPhysical;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFields((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isInvalidDestination) {
      alert(`Error: ${selectedCountryObj?.name} only accepts Physical IDPs. Your application is for a Digital-only IDP.`);
      return;
    }
    setIsSubmitting(true);

    
    try {
      const payload: any = { ...fields, status: "UNDER_REVIEW" };
      
      // Handle date fields
      if (payload.dob) {
        payload.dob = new Date(payload.dob).toISOString();
      } else {
        payload.dob = null;
      }

      const response = await fetch(`/api/applications/${application.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({ error: "Server Error" }));
        throw new Error(errData.error || "Failed to update application");
      }

      alert("Application updated successfully!");
      router.push("/dashboard/applications");
      router.refresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 text-sm">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label className="text-muted block font-bold mb-1.5">Full Name</label>
          <input
            type="text"
            required
            name="fullName"
            value={fields.fullName}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Nationality / Issuing Country</label>
          <input
            type="text"
            required
            name="country"
            value={fields.country}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Email Address</label>
          <input
            type="email"
            required
            name="email"
            value={fields.email}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Phone Number</label>
          <input
            type="text"
            required
            name="phone"
            value={fields.phone}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Date of Birth</label>
          <input
            type="date"
            required
            name="dob"
            value={fields.dob}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">License Number</label>
          <input
            type="text"
            required
            name="licenseNumber"
            value={fields.licenseNumber}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Gender</label>
          <select
            name="gender"
            value={fields.gender}
            onChange={handleChange}
            className="w-full border border-border-custom bg-white rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          >
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Parent/Guardian Name</label>
          <input
            type="text"
            name="parentName"
            value={fields.parentName}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Country of Birth</label>
          <input
            type="text"
            name="countryOfBirth"
            value={fields.countryOfBirth}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div>
          <label className="text-muted block font-bold mb-1.5">Country of Residence</label>
          <input
            type="text"
            name="countryOfResidence"
            value={fields.countryOfResidence}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div className="col-span-1 sm:col-span-2">
          <label className="text-muted block font-bold mb-1.5">License Class / Categories</label>
          <input
            type="text"
            name="licenseClass"
            value={fields.licenseClass}
            onChange={handleChange}
            className="w-full border border-border-custom rounded-xl px-4 py-2.5 outline-none focus:border-blue font-black text-navy"
          />
        </div>
        <div className="col-span-1 sm:col-span-2">
          <label className="text-muted block font-bold mb-1.5">Destination Country</label>
          <input
            type="text"
            required
            name="destinationCountry"
            value={fields.destinationCountry}
            onChange={handleChange}
            className={`w-full border rounded-xl px-4 py-2.5 outline-none font-black text-navy ${
              isInvalidDestination
                ? "border-red-500 focus:border-red-500 bg-red-50/20"
                : "border-border-custom focus:border-blue"
            }`}
          />
          {isInvalidDestination && (
            <p className="text-red-500 text-xs font-bold mt-1.5 flex items-center gap-1">
              <span>⚠️</span> {selectedCountryObj.name} only accepts Physical IDPs. Since you purchased a Digital-only IDP, you cannot select this country. Please change the destination or contact support to upgrade your order.
            </p>
          )}
        </div>
        <div className="col-span-1 sm:col-span-2">
          <label className="text-muted block font-bold mb-1.5">
            {application.productType === "NFC_KIT" ? "Shipping Address" : "License Address"} (Pincode & City details)
          </label>
          <textarea
            name="address"
            required
            value={fields.address}
            onChange={handleChange}
            rows={3}
            className="w-full border border-border-custom rounded-xl p-4 outline-none focus:border-blue font-black text-navy resize-none"
          />
        </div>
      </div>
      <div className="flex justify-end gap-3 pt-4 border-t border-border-custom">
        <button
          type="button"
          onClick={() => router.push("/dashboard/applications")}
          className="px-6 py-2.5 rounded-xl border border-border-custom text-navy font-bold hover:bg-bg-custom transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting || isInvalidDestination}
          className="btn-primary px-8 py-2.5 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          Save Changes
        </button>
      </div>
    </form>
  );
}
