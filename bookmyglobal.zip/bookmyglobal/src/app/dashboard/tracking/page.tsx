import { auth } from "@clerk/nextjs/server";
import { prisma } from "@/lib/prisma";
import { Package, MapPin } from "lucide-react";

export default async function TrackingPage() {
  const { userId } = await auth();
  const user = await prisma.user.findUnique({
    where: { clerkId: userId! },
    include: {
      applications: {
        where: { productType: "NFC_KIT" },
        include: { shipment: true },
        orderBy: { createdAt: "desc" },
      },
    },
  });

  const apps = user?.applications ?? [];

  const statusSteps = ["pending", "dispatched", "in_transit", "out_for_delivery", "delivered"];

  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="font-sora font-black text-navy text-2xl">Track Shipment</h1>

      {apps.length === 0 ? (
        <div className="bg-white border border-border-custom rounded-2xl p-10 text-center">
          <Package className="w-12 h-12 text-muted mx-auto mb-3" />
          <p className="text-muted text-sm">No NFC Smart Kit orders found.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {apps.map((app) => (
            <div key={app.id} className="bg-white border border-border-custom rounded-2xl p-6 space-y-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-sora font-black text-navy">NFC Smart Kit</p>
                  <p className="text-xs text-muted">#{app.idpNumber || app.id.slice(-8).toUpperCase()}</p>
                </div>
                {app.shipment ? (
                  <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-full bg-blue/10 text-blue">
                    {app.shipment.status.replace(/_/g, " ")}
                  </span>
                ) : (
                  <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-full bg-yellow-100 text-yellow-800">
                    Awaiting Dispatch
                  </span>
                )}
              </div>

              {/* Status Timeline */}
              <div className="flex items-center gap-2">
                {statusSteps.map((step, i) => {
                  const currentIdx = app.shipment
                    ? statusSteps.indexOf(app.shipment.status)
                    : 0;
                  const done = i <= currentIdx;
                  return (
                    <div key={step} className="flex items-center flex-1">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-black shrink-0 ${done ? "bg-blue text-white" : "bg-gray-100 text-muted"}`}>
                        {i + 1}
                      </div>
                      {i < statusSteps.length - 1 && (
                        <div className={`flex-1 h-0.5 ${i < currentIdx ? "bg-blue" : "bg-gray-200"}`} />
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-between text-[9px] font-bold text-muted">
                {["Pending", "Dispatched", "In Transit", "Out for Delivery", "Delivered"].map((s) => (
                  <span key={s} className="text-center">{s}</span>
                ))}
              </div>

              {app.shipment && (
                <div className="bg-bg-custom rounded-xl p-4 space-y-2 text-sm">
                  {app.shipment.awbNumber && (
                    <div className="flex justify-between">
                      <span className="text-muted font-bold">AWB Number</span>
                      <span className="font-black font-mono">{app.shipment.awbNumber}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted font-bold">Estimated Delivery</span>
                    <span className="font-bold">7–15 Working Days</span>
                  </div>
                  {app.shipment.trackingUrl && (
                    <a href={app.shipment.trackingUrl} target="_blank" rel="noreferrer"
                      className="flex items-center gap-1 text-blue font-bold text-xs hover:underline">
                      <MapPin className="w-3.5 h-3.5" /> Track on Courier Website
                    </a>
                  )}
                </div>
              )}

              {!app.shipment && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-xs text-yellow-800 font-medium">
                  Your kit will be dispatched after your IDP is approved and generated.
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
