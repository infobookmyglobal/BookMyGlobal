import type { Metadata } from "next";
import { Sora, DM_Sans, Geist_Mono } from "next/font/google";
import { ClerkProvider } from "@/lib/clerk";
import { CMSProvider } from "@/components/CMSProvider";
import { OrganizationJsonLd } from "@/components/JsonLd";
import "./globals.css";

const sora = Sora({ variable: "--font-sora", subsets: ["latin"], weight: ["400", "600", "700", "800"] });
const dmSans = DM_Sans({ variable: "--font-dmsans", subsets: ["latin"], weight: ["400", "500", "700"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://bookmyglobal.com";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: "BookMyGlobal — Visas, Flights, Hotels, Tours & More",
    template: "%s | BookMyGlobal",
  },
  description:
    "BookMyGlobal is your one-stop travel platform: document attestation, visas, flights, hotels, tours, cruises, bus tickets, International Driving Permits and yoga retreats.",
  openGraph: {
    type: "website",
    siteName: "BookMyGlobal",
    url: APP_URL,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sora.variable} ${dmSans.variable} ${geistMono.variable}`}>
      <body className="min-h-screen bg-bg-custom text-text-custom font-sans antialiased">
        <ClerkProvider>
          <CMSProvider>
            <OrganizationJsonLd />
            {children}
          </CMSProvider>
        </ClerkProvider>
      </body>
    </html>
  );
}
