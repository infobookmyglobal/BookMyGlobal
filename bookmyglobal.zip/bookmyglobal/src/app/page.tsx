import type { Metadata } from "next";
import Link from "next/link";
import {
  Car, Plane, Hotel, Compass, Ship, Bus, Stamp, FileCheck2, Users,
  Check, MapPin, CalendarDays, NotebookPen, Leaf,
} from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HomeFaq } from "@/components/home/HomeFaq";
import { getPageCms } from "@/lib/cms";
import { prisma } from "@/lib/prisma";
import { getSeoMetadata } from "@/lib/seo";
import { FaqJsonLd } from "@/components/JsonLd";

export const revalidate = 300;

export async function generateMetadata(): Promise<Metadata> {
  return getSeoMetadata("home");
}

const SERVICES = [
  { icon: Car, title: "International Driving Permit", desc: "Apply for your own IDP — fully self-service, document checks built in, ready before you fly.", href: "/idp", tint: "bg-blue/10 text-blue" },
  { icon: Plane, title: "Flight Booking", desc: "Search and book flights worldwide, with your other travel docs already in the same dashboard.", href: "/contact?type=FLIGHT", tint: "bg-sky-100 text-sky-600" },
  { icon: Hotel, title: "Hotel Booking", desc: "From budget stays to resorts — book your room alongside everything else for the trip.", href: "/contact?type=HOTEL", tint: "bg-violet-100 text-violet-600" },
  { icon: Compass, title: "Tours & Activities", desc: "Day trips, experiences, and things to do at your destination — powered by Viator, booked through us.", href: "/contact?type=TOURS", tint: "bg-orange-100 text-orange-600" },
  { icon: Ship, title: "Cruise Travel", desc: "Cruise itineraries and cabin bookings for travelers who'd rather just float by.", href: "/contact?type=CRUISE", tint: "bg-cyan-100 text-cyan-600" },
  { icon: Bus, title: "International Bus Booking", desc: "Cross-border bus routes for the trips where a flight is overkill and a bus gets you there.", href: "/contact?type=BUS", tint: "bg-rose-100 text-rose-600" },
  { icon: Stamp, title: "MEA & Embassy Attestation", desc: "Document attestation for Indian travelers — handled end to end, no agent running around required.", href: "/contact?type=ATTESTATION", tint: "bg-indigo-100 text-indigo-600", tag: "INDIA ONLY" },
  { icon: FileCheck2, title: "Visa Application Assistance", desc: "We guide you through visa applications from India — paperwork explained, not left to guesswork.", href: "/contact?type=VISA", tint: "bg-teal-100 text-teal-600", tag: "INDIA ONLY" },
  { icon: Users, title: "Traveler Community", desc: "A meetup and social space for people who travel — find who's nearby, swap notes, plan together.", href: "#community", tint: "bg-green/15 text-green", highlight: true },
];

const FAQS = [
  { q: "Do I need an IDP for every country?", a: "No. Requirements depend on the country and on the rental company or local rules. An IDP is recognised in 189+ countries, and our destination guides list the requirement country by country so you can check before you fly." },
  { q: "Is MEA attestation only for Indian citizens?", a: "Our attestation and visa assistance services are built for travellers applying from India, which is why they carry the India-only tag. Tell us your situation through the contact form and we'll confirm what we can help with." },
  { q: "Who runs the yoga retreats?", a: "We do. The Rishikesh retreats are operated directly by BookMyGlobal — they aren't resold from another provider." },
  { q: "What is the traveler community for?", a: "It's a space for people who travel: see who's heading to your destination, join or start meetups, and share trip notes and tips that come from people rather than ads." },
];

export default async function HomePage() {
  const cms = await getPageCms("home");
  const dbFaqs = await prisma.fAQ
    .findMany({ where: { isActive: true }, orderBy: { order: "asc" }, take: 8 })
    .catch(() => []);
  const faqs = dbFaqs.length ? dbFaqs.map((f) => ({ q: f.question, a: f.answer })) : FAQS;
  const t = cms.t;
  const heroLines = t("hero_title", "Every document. Every booking.\nOne trip, sorted.").split("\n");
  const stats = [1, 2, 3].map((n) => ({ num: t(`stat_${n}_num`, ""), label: t(`stat_${n}_label`, "") })).filter((s) => s.num);
  const steps = [
    { title: t("step1_title", "Pick what you need"), desc: t("step1_desc", "Choose a service — an IDP, a flight, a visa, a retreat — and tell us what you're after.") },
    { title: t("step2_title", "Fill in the details"), desc: t("step2_desc", "Share your trip and traveller details once. Upload documents securely where required.") },
    { title: t("step3_title", "Pay and confirm"), desc: t("step3_desc", "Secure checkout in INR or local currency, with an instant confirmation.") },
    { title: "Track everything", desc: "Documents, bookings and status — all in one account." },
  ];

  return (
    <>
      <Header />
      <main>
        <FaqJsonLd faqs={faqs.map((f) => ({ question: f.q, answer: f.a }))} />

        {/* Hero */}
        {cms.show("hero") && (
          <section className="relative overflow-hidden bg-gradient-to-b from-white via-[#eaf0ff] to-bg-custom">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-16 pb-14 lg:pt-24 grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
              <div>
                <span className="inline-block rounded-full bg-green/15 text-green text-[11px] font-black tracking-widest px-4 py-1.5">
                  {t("hero_eyebrow", "ONE PLATFORM. NINE WAYS TO GO PLACES")}
                </span>
                <h1 className="mt-6 font-sora font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-[1.08] text-navy">
                  {heroLines.map((line, i) => (
                    <span key={i} className={`block ${i > 0 ? "text-blue" : ""}`}>{line}</span>
                  ))}
                </h1>
                <p className="mt-6 max-w-xl text-base sm:text-lg text-muted-custom leading-relaxed">
                  {t("hero_subtitle", "From your International Driving Permit to the flight, the hotel, the visa paperwork and the people you'll meet there — BookMyGlobal handles the parts of travel that usually take eleven different tabs.")}
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link href="#services" className="bg-green hover:bg-green/90 text-white font-black text-sm rounded-full px-7 py-3.5 shadow-lg shadow-green/20 transition-colors">
                    {t("hero_btn_primary", "Explore services")}
                  </Link>
                  <Link href="#yoga" className="bg-white border border-border-custom hover:border-blue text-navy font-black text-sm rounded-full px-7 py-3.5 transition-colors">
                    {t("hero_btn_secondary", "See yoga retreats")}
                  </Link>
                </div>
              </div>

              {/* Decorative orbit */}
              <div className="hidden lg:flex items-center justify-center" aria-hidden>
                <div className="relative w-[380px] h-[380px]">
                  <div className="absolute inset-0 rounded-full border border-blue/15" />
                  <div className="absolute inset-10 rounded-full border border-blue/20" />
                  <div className="absolute inset-24 rounded-full border border-blue/25" />
                  <div className="absolute inset-[150px] rounded-full bg-navy flex items-center justify-center font-sora font-black text-gold text-sm">BMG</div>
                  {[
                    "top-2 left-1/2", "top-[22%] right-[6%]", "bottom-[18%] right-[10%]", "bottom-2 left-[42%]", "bottom-[26%] left-[6%]", "top-[20%] left-[10%]",
                  ].map((pos, i) => (
                    <span key={i} className={`absolute ${pos} w-3 h-3 rounded-full ${i % 2 ? "bg-green" : "bg-blue"}`} />
                  ))}
                </div>
              </div>
            </div>

            {cms.show("stats") && stats.length > 0 && (
              <div className="mx-auto max-w-7xl px-4 sm:px-6 pb-14">
                <dl className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
                  {stats.map((s) => (
                    <div key={s.label} className="bg-white/80 border border-border-custom rounded-2xl px-5 py-4">
                      <dt className="font-sora font-extrabold text-3xl text-navy">{s.num}</dt>
                      <dd className="text-xs font-bold text-muted-custom mt-1">{s.label}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            )}
          </section>
        )}

        {/* Services */}
        <section id="services" className="scroll-mt-20 mx-auto max-w-7xl px-4 sm:px-6 py-16 lg:py-24">
          <p className="text-[11px] font-black tracking-widest text-blue">WHAT WE HANDLE</p>
          <h2 className="mt-3 font-sora font-extrabold text-3xl sm:text-4xl text-navy max-w-2xl">The paperwork and the bookings — done in one place</h2>
          <p className="mt-4 max-w-2xl text-muted-custom">
            Some of this we run ourselves. Some we connect you to, through partners like Viator. Either way, it&apos;s one account and one trip plan.
          </p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((s) => (
              <Link
                key={s.title}
                href={s.href}
                className={`group relative rounded-3xl border p-6 transition-all hover:-translate-y-1 hover:shadow-xl ${s.highlight ? "bg-green/5 border-green/30" : "bg-white border-border-custom"}`}
              >
                {s.tag && (
                  <span className="absolute top-5 right-5 rounded-full bg-amber-100 text-amber-700 text-[9px] font-black tracking-wider px-2.5 py-1">{s.tag}</span>
                )}
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${s.tint}`}>
                  <s.icon className="w-6 h-6" />
                </div>
                <h3 className="mt-5 font-sora font-bold text-navy text-lg">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-custom leading-relaxed">{s.desc}</p>
              </Link>
            ))}
          </div>
        </section>

        {/* Steps */}
        {cms.show("steps") && (
          <section id="how-it-works" className="scroll-mt-20 bg-white border-y border-border-custom">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 lg:py-24">
              <p className="text-[11px] font-black tracking-widest text-blue">{t("steps_eyebrow", "HOW IT WORKS")}</p>
              <h2 className="mt-3 font-sora font-extrabold text-3xl sm:text-4xl text-navy">{t("steps_title", "Four steps, start to landing")}</h2>
              <p className="mt-4 max-w-2xl text-muted-custom">{t("steps_subtitle", "Whether it's an IDP or a full trip with flights, hotels, and a yoga retreat — the process stays the same.")}</p>
              <ol className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {steps.map((s, i) => (
                  <li key={s.title} className="relative">
                    <span className="flex w-11 h-11 rounded-full bg-navy text-gold font-sora font-black items-center justify-center">{i + 1}</span>
                    <h3 className="mt-4 font-sora font-bold text-navy">{s.title}</h3>
                    <p className="mt-2 text-sm text-muted-custom leading-relaxed">{s.desc}</p>
                  </li>
                ))}
              </ol>
            </div>
          </section>
        )}

        {/* Yoga */}
        <section id="yoga" className="scroll-mt-20 mx-auto max-w-7xl px-4 sm:px-6 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-[11px] font-black tracking-widest text-amber-600">OUR OWN RETREATS</p>
            <h2 className="mt-3 font-sora font-extrabold text-3xl sm:text-4xl text-navy">Yoga tourism, run by us — not resold</h2>
            <p className="mt-4 text-muted-custom leading-relaxed">
              Our retreats in Rishikesh are operated directly by BookMyGlobal. That means one team from your first question to your last session on the Ganges — no middlemen, no surprises.
            </p>
            <Link href="/contact?type=RETREAT" className="mt-6 inline-block font-black text-sm text-blue hover:underline">Ask about a retreat →</Link>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <div className="bg-white border border-border-custom rounded-3xl p-6">
              <Leaf className="w-6 h-6 text-green" />
              <h3 className="mt-4 font-sora font-bold text-navy text-lg">Foundation</h3>
              <ul className="mt-3 space-y-2 text-sm text-muted-custom">
                {["Guided daily practice", "Accommodation", "Vegetarian meals"].map((x) => (
                  <li key={x} className="flex gap-2"><Check className="w-4 h-4 text-green shrink-0 mt-0.5" />{x}</li>
                ))}
              </ul>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-3xl p-6">
              <Leaf className="w-6 h-6 text-amber-600" />
              <h3 className="mt-4 font-sora font-bold text-navy text-lg">Immersion</h3>
              <ul className="mt-3 space-y-2 text-sm text-slate-600">
                {["Extended teacher-led programme", "7 sessions included", "Excursions along the Ganges"].map((x) => (
                  <li key={x} className="flex gap-2"><Check className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />{x}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* Community */}
        <section id="community" className="scroll-mt-20 bg-white border-y border-border-custom">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 lg:py-24 grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 space-y-3 max-w-md">
              {[
                { icon: MapPin, title: "Traveler nearby", sub: "Someone is landing in your city next week" },
                { icon: CalendarDays, title: "Meetup this weekend", sub: "Coffee and trip stories, open to all" },
                { icon: NotebookPen, title: "New trip plan shared", sub: "A 5-day route, with notes from people who went" },
              ].map((r) => (
                <div key={r.title} className="flex items-center gap-4 bg-bg-custom border border-border-custom rounded-2xl p-4">
                  <div className="w-11 h-11 rounded-full bg-navy text-gold flex items-center justify-center shrink-0"><r.icon className="w-5 h-5" /></div>
                  <div>
                    <p className="font-sora font-bold text-navy text-sm">{r.title}</p>
                    <p className="text-xs text-muted-custom">{r.sub}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="order-1 lg:order-2">
              <span className="inline-block rounded-full bg-green/15 text-green text-[11px] font-black tracking-widest px-4 py-1.5">BUILT FOR TRAVELERS, NOT PERKS</span>
              <h2 className="mt-4 font-sora font-extrabold text-3xl sm:text-4xl text-navy">Find your people, wherever you land</h2>
              <ul className="mt-6 space-y-3">
                {[
                  "See travelers near your destination before you land",
                  "Join meetups or start your own",
                  "Trip notes and tips from people, not ads",
                ].map((x) => (
                  <li key={x} className="flex gap-3 text-navy font-bold text-sm"><Check className="w-5 h-5 text-green shrink-0" />{x}</li>
                ))}
              </ul>
              <Link href="/contact?type=COMMUNITY" className="mt-8 inline-block bg-navy hover:bg-blue text-white font-black text-sm rounded-full px-7 py-3.5 transition-colors">Join the waitlist</Link>
            </div>
          </div>
        </section>

        {/* FAQ */}
        {cms.show("faqs") && (
          <section id="faq" className="scroll-mt-20 mx-auto max-w-3xl px-4 sm:px-6 py-16 lg:py-24">
            <p className="text-[11px] font-black tracking-widest text-blue text-center">{t("faq_eyebrow", "GOT QUESTIONS?")}</p>
            <h2 className="mt-3 font-sora font-extrabold text-3xl sm:text-4xl text-navy text-center">{t("faq_title", "Frequently asked questions")}</h2>
            <p className="mt-4 text-muted-custom text-center">{t("faq_subtitle", "Quick answers about our services, attestation, retreats and community.")}</p>
            <div className="mt-10"><HomeFaq items={faqs} /></div>
          </section>
        )}

        {/* CTA */}
        {cms.show("prefooter") && (
          <section className="px-4 sm:px-6 pb-20">
            <div className="mx-auto max-w-5xl rounded-[2rem] bg-gradient-to-br from-navy to-blue text-center px-6 py-14 sm:py-16">
              <h2 className="font-sora font-extrabold text-2xl sm:text-4xl text-white max-w-2xl mx-auto leading-tight">
                {t("cta_title", "We're building the trip-planning tab you won't have to close")}
              </h2>
              <p className="mt-4 text-white/70 max-w-xl mx-auto">{t("cta_subtitle", "Tell us where you're headed and we'll help with the documents and bookings.")}</p>
              <Link href="/contact" className="mt-8 inline-block bg-green hover:bg-green/90 text-white font-black rounded-full px-8 py-3.5 text-sm transition-colors">
                {t("cta_btn", "Get in touch →")}
              </Link>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
