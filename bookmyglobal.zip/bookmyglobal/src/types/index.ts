export type ApplicationForPDF = {
  id: string
  idpNumber: string           // IDP/26/DL/P1003
  fullName: string            // "JOHN WATSON" — uppercase
  address: string             // "380 BIRCH BARK DR BRICK, NEW JERSEY(NJ), 08723"
  country: string             // "UNITED STATES"
  dob: Date
  gender: string              // "MALE" or "FEMALE"
  licenseNumber: string       // "A5491 02837 46519"
  profilePhotoUrl: string     // S3 key
  issueDate: Date
  expiryDate: Date
  validity: number            // 1, 2, or 3
  destinationCountry: string
  countryOfBirth?: string
  countryOfResidence?: string
  licenseClass?: string
  parentName?: string
}
