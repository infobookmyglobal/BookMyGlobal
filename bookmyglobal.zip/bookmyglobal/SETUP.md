# BookMyGlobal — Setup guide

Same stack as the IDP platform (Next.js 16, React 19, TypeScript, Tailwind v4, Prisma 6 + PostgreSQL, Clerk, AWS S3 + CloudFront, Resend, Stripe/Razorpay/PayPal, ShipGlobal) with a **new** AWS account, Clerk application and database. Nothing here shares credentials with IDP.

## 1. Install

```bash
pnpm install
cp .env.example .env      # then fill it in (steps below)
pnpm prisma generate
pnpm prisma migrate dev --name init   # creates the tables (or `pnpm prisma db push` for a quick start)
pnpm dev
```

## 2. PostgreSQL
Any Postgres 14+ (Neon, Supabase, RDS, local). Put the connection string in `DATABASE_URL`.

## 3. Clerk (new application)
1. https://dashboard.clerk.com → **Create application** → "BookMyGlobal". Enable Email + Google (or what you want).
2. Copy the publishable and secret keys into `.env`.
3. **Webhooks → Add endpoint**: `https://YOUR_DOMAIN/api/webhooks/clerk`, subscribe to `email.created`. Copy the *Signing secret* into `CLERK_WEBHOOK_SECRET`. (In Clerk → Customization → Emails, switch "Delivered by Clerk" off for the emails you want sent through Resend.)
4. Set `ADMIN_EMAIL` to your email. The first time you sign in with it you are auto-promoted to **ADMIN**. Backup route: `pnpm tsx scripts/make-admin.ts you@example.com`.

## 4. AWS (new account)
1. **S3**: create bucket `bookmyglobal-uploads` (region `ap-south-1`), *Block all public access* ON.
2. **CORS** on the bucket (needed for browser uploads via presigned URLs):
   ```json
   [{ "AllowedHeaders": ["*"], "AllowedMethods": ["PUT", "GET", "HEAD"],
      "AllowedOrigins": ["http://localhost:3000", "https://bookmyglobal.com", "https://www.bookmyglobal.com"],
      "ExposeHeaders": ["ETag"], "MaxAgeSeconds": 3000 }]
   ```
3. **CloudFront**: create a distribution with the bucket as origin using **Origin Access Control**; let CloudFront add the bucket-policy statement. Put the `xxxx.cloudfront.net` domain in `AWS_CLOUDFRONT_DOMAIN` and `NEXT_PUBLIC_CLOUDFRONT_DOMAIN`.
4. **IAM**: create a user with a policy limited to this bucket:
   ```json
   { "Version": "2012-10-17", "Statement": [{
     "Effect": "Allow",
     "Action": ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
     "Resource": "arn:aws:s3:::bookmyglobal-uploads/*" }] }
   ```
   Create an access key → `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`. Never reuse IDP's keys.

## 5. Email (Resend)
IDP sends mail through **Resend** (not SES, despite the `lib/ses.ts` filename). Verify your sending domain at resend.com, create an API key, set `RESEND_API_KEY` and `EMAIL_FROM`.

## 6. Payments and shipping
Fill only the providers you will use. Webhook endpoints (all fail closed without their secret):
- Stripe → `/api/webhooks/stripe` (`STRIPE_WEBHOOK_SECRET`)
- Razorpay → `/api/webhooks/razorpay` (`RAZORPAY_WEBHOOK_SECRET`)
- PayPal → `/api/webhooks/paypal` (`PAYPAL_WEBHOOK_ID`)
- ShipGlobal → `/api/webhooks/shipglobal` (`SHIPGLOBAL_WEBHOOK_SECRET`)

## 7. Assets you must supply (deliberately NOT copied from IDP)
The IDP booklet/card generator needs your own artwork:
- `booklet-template-blank.pdf` in the project root
- `public/images/card-front-template.jpeg` and `public/images/card-back-template.jpeg` (1016 × 638 px)
- optional `public/images/stamp.png` and `public/images/signature.png`
- `public/logo.png` (used in JSON-LD) and `public/og-home.jpg`

Until these exist, approving an IDP application will fail at PDF generation. Everything else works.

## 8. Admin panel
Visit `/admin`. It is the IDP admin (Dashboard, Applications, Payments, Shipments, **Enquiries** (new), Blogs, Pages, FAQs, Destinations, Site Edit, Redirects, Users, Partners, Coupons, Translations, SEO, Sitemap, Media, Settings). Sensitive sections stay locked until you enter `ADMIN_UNLOCK_PASSWORD` (verified server-side, 12 h cookie).

Public legal pages (`/terms`, `/privacy`, `/refunds`, `/about`) are created in **Admin → Pages**.

## Security changes vs. the IDP codebase
- Unlock password is verified on the server and stored in env (IDP hard-coded it in client JS).
- User passwords are no longer stored in plaintext or shown to admins.
- `/api/admin/destinations*` now requires the ADMIN role and whitelists fields (IDP only checked "logged in").
- No dev-mode auth bypass anywhere; no hard-coded admin email.
- Webhooks (Clerk, Stripe, PayPal, ShipGlobal) reject unsigned requests; PayPal commissions are idempotent.
